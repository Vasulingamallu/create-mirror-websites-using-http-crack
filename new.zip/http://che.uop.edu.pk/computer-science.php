<!DOCTYPE html>
<html lang="en">
<head>
<title>Computer Science - College of Home Economics, University of Peshawar</title>
<meta charset="utf-8">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
<meta name = "format-detection" content = "telephone=no" />
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<!--CSS-->
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/camera.css">
<!--JS-->
<script src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery.vticker-min.js"></script>
<script src="js/jquery-migrate-1.1.1.js"></script>
<script src="js/superfish.js"></script>
<script src="js/jquery.mobilemenu.js"></script>
<script src="js/jquery.cookie.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.ui.totop.js"></script>
<script>	
	$(function(){
	$('#news-container').vTicker({ 
		speed: 500,
		pause: 5000,
		animation: 'fade',
		mousePause: true,
		showItems: 3
		});
	});
	
	$(function(){
	$('#news-container2').vTicker({ 
		speed: 500,
		pause: 5000,
		animation: 'fade',
		mousePause: true,
		showItems: 2
		});
	});
</script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
<script src="//code.jquery.com/ui/1.11.2/jquery-ui.js"></script>
<script>
$(function() {
$( "#accordion" ).accordion({
collapsible: true,
active: false,
heightStyle: "content"
});
});
</script>
<!--[if lt IE 8]>
		<div style='text-align:center'><a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/img/upgrade.jpg"border="0"alt=""/></a></div>  
<![endif]-->
<!--[if lt IE 9]>
  <link rel="stylesheet" href="css/ie.css">
  <link rel="stylesheet" href="css/docs.css">
  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body>
<div class="global">
<!--header-->
<header>
    <div class="main">
        <div class="gradient">
        <div class="container">
             <article>
                <div class="navbar navbar_ clearfix">
                    <div class="navbar-inner">      
                          <div class="clearfix">
                                <div class="nav-collapse nav-collapse_">
                                	<ul class="nav sf-menu clearfix">
                                	  <li><a href="index.php">Home</a></li>
                                      <li class="sub-menu"><a href="#">About</a>
                                        <ul>
                                            <li><a href="che-history.php">Brief History</a></li>
                                            <li><a href="leadership.php">Leadership</a></li>
                                            <li><a href="foundation-faculty.php">Foundation Faculty</a></li>
                                            <li><a href="contact-us.php">Contact Us</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Programs</a>
                                        <ul>
                                            <li><a href="art-design-introduction.php">Art & Design</a></li>
                                            <li><a href="food-nutrition-sciences-introduction.php">Food & Nutrition Sciences</a></li>
                                            <li><a href="human-development-family-studies-introduction.php">Human Development &amp; Family Studies</a></li>
                                            <li><a href="resource-facility-management-introduction.php">Resource &amp; Facility Management</a></li>
                                            <li><a href="textile-clothing-introduction.php">Textile & Clothing</a></li>
                                            <li><a href="#">Mandatory Supportive<span></span></a>
                                              <ul>
                                             <li><a href="computer-science-introduction.php">Computer Science</a></li>
                                              <li><a href="english-introduction.php">English</a></li>
                                              <li><a href="pak-studies-introduction.php">Pak. Studies</a></li>

                                              <li><a href="science-introduction.php">Science Department</a></li>
                                              <li><a href="urdu-islamiyat-introduction.php">Urdu / Islamiyat</a></li>
                                              </ul>
                                            </li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Admissions</a>
                                        <ul>
                                          <li><a href="bsc.php">BS Public Health<span></span></a>
                                        	<ul>
                                              <li><a href="bsc-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="bsc-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="bsc-uniform.php">Uniform</a></li>
                                              <li><a href="bsc-merit-list.php">Merit List</a></li>
                                              <li><a href="bsc-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="fsc.php">F.A/ F.Sc.<span></span></a>
                                        	<ul>
                                              <li><a href="fsc-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="fsc-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="fsc-uniform.php">Uniform</a></li>
                                              <li><a href="fsc-merit-list.php">Merit List</a></li>
                                              <li><a href="fsc-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="bs-hons.php">B.S Home Economics<span></span></a>
                                        	<ul>
                                              <li><a href="bs-hons-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="bs-hons-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="bs-hons-uniform.php">Uniform</a></li>
                                              <li><a href="bs-hons-merit-list.php">Merit List</a></li>
                                              <li><a href="bs-hons-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="msc.php">BS Human Nutrition & Dietetics<span></span></a>
                                        	<ul>
                                              <li><a href="msc-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="msc-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="msc-uniform.php">Uniform</a></li>
                                              <li><a href="msc-merit-list.php">Merit List</a></li>
                                              <li><a href="msc-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="mphil.php">M.Phil<span></span></a>
                                        	<ul>
                                              <li><a href="mphil-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="mphil-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="mphil-uniform.php">Uniform</a></li>
                                              <li><a href="mphil-merit-list.php">Merit List</a></li>
                                              <li><a href="mphil-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="phd.php">Ph.D<span></span></a>
                                        	<ul>
                                              <li><a href="phd-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="phd-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="phd-uniform.php">Uniform</a></li>
                                              <li><a href="phd-merit-list.php">Merit List</a></li>
                                              <li><a href="phd-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Examination</a>
                                        <ul>
                                          <li><a href="examination-rules.php">Rules</a></li>
                                          <li><a href="datesheet.php">Date Sheet</a></li>
                                          <li><a href="results.php">Results</a></li>
                                          <li><a href="convocation.php">Convocation</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="college-faculty.php">Faculty</a>
                                        <ul>
                                          <li><a href="faculty-art-and-design.php">Art & Design</a></li>
                                          <li><a href="faculty-food-and-nutrition-sciences.php">Food & Nutrition Sciences</a></li>
                                          <li><a href="faculty-human-development-and-family-studies.php">Human Development and Family Studies</a></li>
                                          <li><a href="faculty-resource-and-facility-management.php">Resource and Facility Management</a></li>
                                          <li><a href="faculty-textile-and-clothing.php">Textile & Clothing</a></li>
                                          <li><a href="faculty-science.php">Science</a></li>
                                          <li><a href="faculty-computer-studies.php">Computer Studies</a></li>
                                          <li><a href="faculty-english.php">English</a></li>
                                          <li><a href="faculty-pak-studies.php">Pak. Studies</a></li>
                                          <li><a href="faculty-urdu.php">Urdu</a></li>
                                          <li><a href="faculty-islamiyat.php">Islamiyat</a></li>
                                          <li><a href="faculty-login.php">Faculty Login</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Student's Life</a>
                                        <ul>
                                          <li><a href="students-societies.php">Student Societies</a></li>
                                          <li><a href="students-society-members.php">Society Members</a></li>
                                          <li><a href="students-academic-visits.php">Academic Visits</a></li>
                                          <li><a href="students-recreational-trips.php">Recreational Trips</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Facilities</a>
                                        <ul>
                                  <li><a href="facilities-bookshop.php">Bookshop</a></li>                                          <li><a href="facilities-canteen.php">Canteen</a></li>

                                          <li><a href="facilities-daycare.php">Day Care</a></li>                                          <li><a href="facilities-first-aid-room.php">First Aid Room</a></li>

                                          <li><a href="facilities-generators.php">Generators</a></li>
                                                                                                                   <li><a href="facilities-home-management-residence.php">Home Management Residence</a></li>
        <li><a href="facilities-hostel.php">Hostel</a></li>
   <li><a href="facilities-internet.php">Internet</a></li>

                                          <li><a href="facilities-library.php">Library</a></li>
                                                                              <li><a href="facilities-mosque.php">Mosque</a></li>
                                          <li><a href="facilities-nursery.php">Nursery</a></li>
                                        <li><a href="facilities-photocopier.php">Photocopier</a></li>

                                          <li><a href="facilities-playgroup.php">Play Group</a></li>
                                            <li><a href="facilities-preplaygroup.php">Pre Play Group</a></li>      
                                          <li><a href="facilities-transport.php">Transport</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="alumni-list.php">PFHE</a>
                                        <ul>
                                          <li><a href="pfhe.php">Introduction</a></li>
                                          <li><a href="alumni-profile.php">Members Profile</a></li>
                                          <li><a href="alumni-list.php">Federation & Alumni Members</a></li>
                                        </ul>
  </li>
                                      <li class="sub-menu"><a href="#">JHEBS</a>
                                        <ul><li><a href="jhebs-call-for-papers.php">Call for Papers</a></li>
                                          <li><a href="jhebs-published-versions.php">Published Versions</a></li>
                                          <li><a href="jhebs-research.php">Research</a></li>
                                          <li><a href="jhebs-rules.php">Rules</a></li>
                                                                                    <li><a href="jhebs-updates.php">Updates</a></li>

                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Conference</a>
                                        <ul>
                                          <li><a href="conference-call-for-papers.php">Call For Papers</a></li>
										  <li><a href="conference-accepted-papers.php">Accepted Papers</a></li>
										  <li><a href="conference-registration-and-payment.php">Registration and Payment</a></li>
										  <li><a href="conference-important-dates.php">Important Dates</a></li>
										  <li><a href="conference-keynote-speaker.php">Keynote Speaker</a></li>
										  <li><a href="conference-committee.php">Committee</a></li>
										  <li><a href="conference-abstract-submission.php">Abstract Submission</a></li>
										  <li><a href="conference-topics.php">Conference Topics</a></li>
										  <li><a href="conference-presentation-instructions.php">Presentation Instructions</a></li>
										  <li><a href="conference-who-should-attend.php">Who should Attend</a></li>
										  <li><a href="conference-tentative-programme.php">Tentative Programme</a></li>
										  <li><a href="conference-venue.php">Venue</a></li>
										  <li><a href="conference-final-paper-submission.php">Final Paper Submission</a></li>
										  <li><a href="conference-paper-templates.php">Paper Templates</a></li>
										  <li><a href="conference-accommodation-and-travel.php">Accommodation & Travel</a></li>
										  <li><a href="conference-conference-poster.php">Conference Poster</a></li>
										  <li><a href="contact-us.php">Contact Us</a></li>
                                        </ul>
                                      </li>
									  <li class="sub-menu"><a href="#">Activities</a>
                                        <ul>                                          <li><a href="college-magazine.php">College Magazine</a></li>
                                          <li><a href="activities-exhibitions.php">Exhibitions</a></li>
                                          <li><a href="activities-internships.php">Internships</a></li>
                                          <li><a href="activities-lectures.php">Lectures</a></li>
                                          <li><a href="newsletter.php">Newsletter</a></li>                                          <li><a href="activities-seminars.php">Seminars</a></li>

                                          <li><a href="activities-sports.php">Sports</a></li>
                                                                                 <li><a href="activities-tutorials.php">Tutorials</a></li>
   <li><a href="activities-workshops.php">Workshops</a></li>
                                        </ul>
                                      </li>
                                    </ul>
                                 </div>
                                 <ul class="follow_icon">
                                    <li><a href="https://www.facebook.com/CHEUOP/"><img src="img/follow_icon2.png" alt=""></a></li>                                                                    </ul>                          </div>
                    </div>
                </div>
                <h1 class="brand"><a href="index.php"><img src="img/logo.png" alt=""></a></h1>
                <form id="search" class="search" action="search-results.php" method="GET" accept-charset="utf-8">
                	 <input type="text" onFocus="if(this.value =='Search for...' ) this.value=''" onBlur="if(this.value=='') this.value='Search for...'" value="Search for..." name="q">
                     <a href="#" onClick="document.getElementById('search').submit()"><img src="img/magnify.png" alt=""></a>
                </form>             </article>
        </div>
        </div>
    </div>
</header>

<div class="main">
    <div class="gradient1">
        <section class="container">
            <div class="row">
                <article class="span12 margBot6">
                    <div class="row">
                        <div class="span3 support-box">
                            <h3>Program Links</h3>
                            <ul class="list3">
                                <li><em></em><p><a href="computer-science-introduction.php">Introduction</a></p></li>
                                <li><em></em><p><a href="computer-science.php">Department Highlights</a></p></li>
                                <li><em></em><p><a href="computer-science-faculty.php">Faculty</a></p></li>
                                <li><em></em><p><a href="computer-science-department-pictures.php">Department Pictures</a></p></li>
                                <li><em></em><p><a href="computer-science-scheme-of-study.php">Scheme of Study</a></p></li>
                                <li><em></em><p><a href="computer-science-research-publications.php">Research Publications</a></p></li>
                                
                            </ul>
                        </div>
                        <div class="span6 support-box">
                            <h3>Computer Science > Department Highlights</h3>

                            <div id="accordion">
							
                                <h3>Workshops</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>&nbsp;</p>
<ol style="margin-top: 0cm;" type="1" start="1">
<li class="MsoNormal" style="margin-top: 0cm; margin-bottom: 8pt; text-align: left; background: #fcfcfc;">Attended four days workshop on &ldquo;Project management and Proposal writing&rdquo; from 28th October to 31st&nbsp; October, 2013 , organized by Center for Human Resource and Career development, University of Peshawar and Higher Education Commission.</li>
<li class="MsoNormal" style="margin-top: 0cm; margin-bottom: 8pt; text-align: left; background: #fcfcfc;">Attended four days workshop on &ldquo;Statistical Data Handling&rdquo;, from 4th July to 8th July, 2005, organized by Department of Statistics, University of Peshawar.</li>
<li class="MsoNormal" style="margin-top: 0cm; margin-bottom: 8pt; text-align: left; background: #fcfcfc;">Attended two days workshop on &ldquo;Computer Training for College Lecturers&rdquo;, from 8th March to 9th March, 2003, organized by Frontier Education Foundation.</li>
</ol>
<div id="__if72ru4sdfsdfrkjahiuyi_once" style="display: none;">&nbsp;</div>
<div id="__if72ru4sdfsdfruh7fewui_once" style="display: none;">&nbsp;</div>
<div id="__hggasdgjhsagd_once" style="display: none;">&nbsp;</div></p><p align="right">,,,Attended by: <a href="profile.php?id=18" class="text-info"><span class="text-info">Dr. Neelam Mukhtar</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Workshop on sunsolaris Administration in&nbsp;2004 at&nbsp;Depatment of Computer Science,University of Peshawar<br /><br /></p>
<p>Workshop on office Automation in&nbsp;2006 at&nbsp;Frontier Information Technology &amp; Science Institute,Peshawar</p>
<p>&nbsp;</p>
<p class="margbot" style="margin: 0in 0in 7.5pt; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial;">Attended two days<strong> workshop </strong>on Emerging Technology &amp; Information Technologyfrom 26th August to 28th August, 2013, organized by Department of Computer Science, University of Peshawar at Baragali campus</p>
<p>&nbsp;</p>
<p>&nbsp;</p></p><p align="right">,Participated,, by: <a href="profile.php?id=37" class="text-info"><span class="text-info">Dr. Kanwal Imran</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Arranged a workshop on " installation of computer and networking hardware" for students of F.A (Computer Science) in November 2018.</p></p><p align="right">,,Organized, by: <a href="profile.php?id=50" class="text-info"><span class="text-info">Ms. Abeera Ilyas</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Title: Research methodology, Accounting and auditing<br /> Date:&nbsp; 14-16&nbsp;December 2014, 13-15 January 2015<br /> Venue: Centre of Human Resource and Career Development<br /> Organization: University Of Peshawar</p></p><p align="right">,,,Attended by: <a href="profile.php?id=50" class="text-info"><span class="text-info">Ms. Abeera Ilyas</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Conferences</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>&nbsp;</p>
<ol style="margin-top: 0in;" type="1" start="1">
<li class="MsoNormal" style="color: black; margin-top: 0in; mso-list: l0 level1 lfo1;">Invited national speaker in 1st International Conference on Software Engineering and Computing Disciplines (ICSECD-2019), University of Swabi, on 12th November, 2019. The title of the Talk was &ldquo;Urdu Sentiment Analysis using Lexicon-based approach&rdquo;.</li>
</ol>
<div id="__if72ru4sdfsdfrkjahiuyi_once" style="display: none;">&nbsp;</div>
<div id="__if72ru4sdfsdfruh7fewui_once" style="display: none;">&nbsp;</div>
<div id="__hggasdgjhsagd_once" style="display: none;">&nbsp;</div></p><p align="right">,Participated,, by: <a href="profile.php?id=18" class="text-info"><span class="text-info">Dr. Neelam Mukhtar</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Inernational Conference on Computer Emerging Technologies in 12-18 july 2011 at Bara Gali campus.<br /><br /></p></p><p align="right">,Participated,, by: <a href="profile.php?id=37" class="text-info"><span class="text-info">Dr. Kanwal Imran</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Seminars</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p></p>
<ol style="margin-top: 0in;" type="1" start="1">
<li class="MsoNormal" style="color: black; margin-top: 0in; margin-bottom: 8.0pt; text-align: left; mso-list: l0 level1 lfo1; background: #FCFCFC;">Participated in one day seminar on &ldquo;Wireless communication&rdquo; at Edwards College Peshawar on 20th Jan, 2007. </li>
</ol>
<p>&nbsp; </p>
<div id="__if72ru4sdfsdfrkjahiuyi_once" style="display: none;">&nbsp;</div>
<div id="__if72ru4sdfsdfruh7fewui_once" style="display: none;">&nbsp;</div>
<div id="__hggasdgjhsagd_once" style="display: none;">&nbsp;</div></p><p align="right">,Participated,, by: <a href="profile.php?id=18" class="text-info"><span class="text-info">Dr. Neelam Mukhtar</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Extension Lectures</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><div>&nbsp;</div>
<div>
<p class="MsoListParagraphCxSpFirst" style="margin-top: 0in; margin-right: 0in; margin-bottom: 10.0pt; margin-left: .75in; mso-add-space: auto; text-indent: -.25in; line-height: 115%; mso-list: l0 level1 lfo1;">1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Arranged two days workshop on &ldquo;Sampling and Data Analysis using SPSS&rdquo; on 28th and 30th November, 2023.</p>
<p class="MsoListParagraphCxSpMiddle" style="margin-top: 0in; margin-right: 0in; margin-bottom: 10.0pt; margin-left: .75in; mso-add-space: auto; text-indent: -.25in; line-height: 115%; mso-list: l0 level1 lfo1;">2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Arranged three days workshop on &ldquo;Basic Computer Skills&rdquo; for College Laboratory staff from 19th Sept 2023 to 21st Sept 2023. </p>
<p class="MsoListParagraphCxSpMiddle" style="margin-top: 0in; margin-right: 0in; margin-bottom: .0001pt; margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1;">3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Arranged a work shop on &ldquo;Data Analysis&rdquo; at College of Home Economics, University of Peshawar on 2nd June, 2022.</p>
<p class="MsoListParagraphCxSpMiddle" style="margin-top: 0in; margin-right: 0in; margin-bottom: .0001pt; margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1;">4.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Arranged Lecture on &ldquo;Linear Programming&rdquo; at College of Home Economics, University of Peshawar on 11th March, 2022.</p>
<p class="MsoListParagraphCxSpMiddle" style="margin-top: 0in; margin-right: 0in; margin-bottom: .0001pt; margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1;">5.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Resource person for Seminar on &ldquo;Statistics in Research&rdquo;, on 28th Jan, 2021, arranged for M.Phil/MS students by Department of Science, College of Home Economics, University of Peshawar.</p>
<p class="MsoListParagraphCxSpMiddle" style="margin-top: 0in; margin-right: 0in; margin-bottom: .0001pt; margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1;">6.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Invited national speaker in 1st International Conference on Software Engineering and Computing Disciplines (ICSECD-2019), University of Swabi, on 12th November, 2019. The title of the Talk was &ldquo;Urdu Sentiment Analysis using Lexicon-based approach&rdquo;. </p>
<p class="MsoListParagraphCxSpMiddle" style="margin-top: 0in; margin-right: 0in; margin-bottom: .0001pt; margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1;">7.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Arranged Workshop in collaboration with Career Development Center, University of Peshawar on &ldquo;New Digital Media Production and its Scope for the students&rdquo; on 31st October, 2019.</p>
<p class="MsoListParagraphCxSpMiddle" style="margin-top: 0in; margin-right: 0in; margin-bottom: .0001pt; margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1;">8.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Supervised students as incharge for participation in &ldquo;Science Journalism Society of Pakistan (SJSP) Science Expo 2019&rdquo;on 14th March, 2019.</p>
<p class="MsoListParagraphCxSpMiddle" style="margin-top: 0in; margin-right: 0in; margin-bottom: .0001pt; margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1;">9.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Co-organized Mega Home Science Event, 2019, College of Home Economics, University of Peshawar on 24th January, 2019.</p>
<p class="MsoListParagraphCxSpMiddle" style="margin-top: 0in; margin-right: 0in; margin-bottom: .0001pt; margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1;">10.&nbsp; Organized Workshop on &ldquo;Computer based software applications in research&rdquo;, the Second Workshop of &ldquo;Modern Computer Technologies: Their Applications&rdquo; at College of Home Economics, University of Peshawar, on 21st December, 2017.</p>
<p class="MsoListParagraphCxSpMiddle" style="margin-top: 0in; margin-right: 0in; margin-bottom: .0001pt; margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1;">11.&nbsp; Organized Workshop on &ldquo;Modern Computer Technology: Its Hardware and Software&rdquo;, the first Workshop of &ldquo;Modern Computer Technologies: Their Applications&rdquo; at College of Home Economics, University of Peshawar, on 29th November, 2017.</p>
<p class="MsoListParagraphCxSpMiddle" style="margin-top: 0in; margin-right: 0in; margin-bottom: .0001pt; margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1;">12.&nbsp; Arranged Lecture on &ldquo;Latex&rdquo; at College of Home Economics, University of Peshawar, on 12th October 2015.</p>
<p class="MsoListParagraphCxSpLast" style="margin-top: 0in; margin-right: 0in; margin-bottom: .0001pt; margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1;">13.Organized workshop on &ldquo;Referencing with End Note&rdquo; and &ldquo;Plagiarism&rdquo; at College of Home Economics, University of Peshawar, on 26th November, 2013.</p>
</div>
<p>&nbsp;</p>
<div id="__if72ru4sdfsdfrkjahiuyi_once" style="display: none;">&nbsp;</div>
<div id="__if72ru4sdfsdfruh7fewui_once" style="display: none;">&nbsp;</div>
<div id="__hggasdgjhsagd_once" style="display: none;">&nbsp;</div></p><p align="right">,,Organized, by: <a href="profile.php?id=18" class="text-info"><span class="text-info">Dr. Neelam Mukhtar</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Trainings</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                           <p style="color:#333333;font-weight:normal;"><p>&nbsp;<strong style="font-size: 10px;">&nbsp;</strong></p>
<p class="MsoNormal" style="margin: 0cm 0cm 0.0001pt 40.5pt; text-indent: -18pt;" align="left">1.&nbsp;&nbsp; Resource person at &ldquo;School teachers training course&rdquo;, held at College of Home Economics, University of Peshawar, on 15th June, 2007.</p>
<p class="MsoNormal" style="margin: 0cm 0cm 0.0001pt 40.5pt; text-indent: -18pt;" align="left">2.&nbsp; &nbsp;Completed two months training course on &ldquo;E Commerce&rdquo;, at Brains Post Graduate College of Information Technology Peshawar, from 22nd July to 22nd August, 2001.</p>
<p class="MsoNormal" style="margin: 0cm 0cm 0.0001pt 40.5pt; text-indent: -18pt;" align="left">3.&nbsp;&nbsp; Completed one week training course in Computer Science at Department of Computer Science, University of Peshawar, organized by University Grants Commission from 26th Feb to 3rd March 2001.</p>
<div id="__if72ru4sdfsdfrkjahiuyi_once" style="display: none;">&nbsp;</div>
<div id="__if72ru4sdfsdfruh7fewui_once" style="display: none;">&nbsp;</div>
<div id="__hggasdgjhsagd_once" style="display: none;">&nbsp;</div></p><p align="right">,,, by: <a href="profile.php?id=18" class="text-info"><span class="text-info">Dr. Neelam Mukhtar</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                           <p style="color:#333333;font-weight:normal;"><p>Managing References &amp;Citations using End Note in&nbsp;6th june 2009 at&nbsp;Quaid-e-Azam college of commerce,University of Peshawar</p></p><p align="right">,Participated,, by: <a href="profile.php?id=37" class="text-info"><span class="text-info">Dr. Kanwal Imran</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                           <p style="color:#333333;font-weight:normal;"><p>Title: Effective Communication Skills<br />&nbsp;Date: 11-13 March 2015</p>
<p>Venue: Centre of Human Resource and Career Development<br /> Organization: University of Peshawar</p></p><p align="right">,Participated,, by: <a href="profile.php?id=50" class="text-info"><span class="text-info">Ms. Abeera Ilyas</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Exhibitions</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>&nbsp;</p>
<ol style="margin-top: 0in;" type="1" start="1">
<li class="MsoNormal" style="color: black; margin-top: 0in; text-align: left; mso-list: l0 level1 lfo1;">Supervised students as incharge for participation in &ldquo;Science Journalism Society of Pakistan (SJSP) Science Expo 2019&rdquo;on 14th March 2019.</li>
<li class="MsoNormal" style="color: black; margin-top: 0in; text-align: left; mso-list: l0 level1 lfo1;">Co-organized Mega Home Science Event, 2019, College of Home Economics, University of Peshawar on 24th January 2019.</li>
</ol>
<p>&nbsp;</p>
<div id="__if72ru4sdfsdfrkjahiuyi_once" style="display: none;">&nbsp;</div>
<div id="__if72ru4sdfsdfruh7fewui_once" style="display: none;">&nbsp;</div>
<div id="__hggasdgjhsagd_once" style="display: none;">&nbsp;</div></p><p align="right">,,, by: <a href="profile.php?id=18" class="text-info"><span class="text-info">Dr. Neelam Mukhtar</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Title: 3rd Disaster Management Exhibition&nbsp;<br /> Date: 20th November 2013&nbsp;<br /> Venue: University&nbsp;of Peshawar<br /> Organization: Department of Disaster preparedness and management, UoP</p></p><p align="right">,Participated,, by: <a href="profile.php?id=50" class="text-info"><span class="text-info">Ms. Abeera Ilyas</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Competitions</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>&nbsp;</p>
<div id="__if72ru4sdfsdfrkjahiuyi_once" style="display: none;">&nbsp;</div>
<div id="__if72ru4sdfsdfruh7fewui_once" style="display: none;">&nbsp;</div>
<div id="__hggasdgjhsagd_once" style="display: none;">&nbsp;</div></p><p align="right">,,, by: <a href="profile.php?id=18" class="text-info"><span class="text-info">Dr. Neelam Mukhtar</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Animated presentation/video making competition</p>
<p>on 18/02/2017</p></p><p align="right">,,,Attended by: <a href="profile.php?id=37" class="text-info"><span class="text-info">Dr. Kanwal Imran</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Editorships</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>&nbsp;</p>
<div id="__if72ru4sdfsdfrkjahiuyi_once" style="display: none;">&nbsp;</div>
<div id="__if72ru4sdfsdfruh7fewui_once" style="display: none;">&nbsp;</div>
<div id="__hggasdgjhsagd_once" style="display: none;">&nbsp;</div></p><p align="right"> by: <a href="profile.php?id=18" class="text-info"><span class="text-info">Dr. Neelam Mukhtar</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Research Publications</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>&nbsp;</p>
<p class="MsoNormal" style="margin-top: 0in; margin-right: 0in; margin-bottom: .0001pt; margin-left: .75in; text-indent: .25in;"><strong>Category &ldquo;W&rdquo; Papers (having Impact Factor of ISI JCR)</strong></p>
<p class="MsoNormal" style="margin-top: 0in; margin-right: 0in; margin-bottom: .0001pt; margin-left: .5in; line-height: normal; mso-layout-grid-align: none; text-autospace: none;"><strong>&nbsp;</strong></p>
<p class="MsoListParagraphCxSpFirst" style="margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1;">1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong>Neelam Mukhtar</strong>, Mohammad Abid Khan, Nadia Chiragh, Shah Nazir,&nbsp; and Asim Ullah Jan, &ldquo;An Intelligent Unsupervised Approach for Handling Context-Dependent Words in Urdu Sentiment Analysis&rdquo; 21(5), Article 92, 2022, pp. 1-15, doi.acm.org?doi=3510830, (<strong>IF 1.413, based on JCR, &nbsp;2020).</strong></p>
<p class="MsoListParagraphCxSpMiddle" style="margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1;">2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Guangping Zhuo,&nbsp; Shah Nazir,&nbsp; Habib Ullah Khan,&nbsp; <strong>Neelam Mukhtar, </strong>&ldquo;An Efficient Multifeature Model for Improving the Performance of Critical Energy Infrastructure&rdquo;, Journal of Advanced Transportation, 2021, 12 pages, pp 1-12, https://doi.org/10.1155/2021/8411379, (<strong>IF 2.419</strong>, <strong>based on JCR, 2020</strong>).</p>
<p class="MsoListParagraphCxSpMiddle" style="margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1;">3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Zhen Ying, Iftikhar Ahmad,&nbsp; Saima Mateen,&nbsp; Asad Zia, Ambreen, Shah Nazir, <strong>Neelam Mukhtar</strong>, &ldquo;An Overview of Computational Models for Industrial Internet of Things to Enhance Usability&rdquo;, Complexity, 2021, 11 pages, pp 1-11, https://doi.org/10.1155/2021/5554685, <strong>(IF 2.833, based on JCR, 2020</strong>).</p>
<p class="MsoListParagraphCxSpMiddle" style="margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1;">4.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Xin Yang, Shah Nazir, Habib Ullah Khan, Muhammad Shafiq, <strong>Neelam Mukhtar, &ldquo;</strong>Parallel Computing for Efficient and Intelligent Industrial&nbsp; Internet of Health Things: An Overview&rdquo;, Complexity, 2021, 11 pages, pp 1-11, https://doi.org/10.1155/2021/6636898, (<strong>IF 2.462, based on JCR 2019</strong>).</p>
<p class="MsoListParagraphCxSpMiddle" style="margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1;">5.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Banghua Wu, Shah Nazir, &nbsp;<strong>Neelam Mukhtar, </strong>&ldquo;Identification of Attack on Data Packets Using Rough Set Approach to Secure End to End Communication&rdquo;, Complexity, 2020, 12 pages, pp 1-12, https://doi.org/10.1155/2020/6690569 (<strong>IF 2.462, based on JCR 2019</strong>).</p>
<p class="MsoListParagraphCxSpMiddle" style="margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1;">6.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong style="mso-bidi-font-weight: normal;">Neelam Mukhtar</strong>, Mohammad Abid Khan, &ldquo;Effective lexicon-based approach for Urdu sentiment analysis&rdquo;, Artificial Intelligence Review, 2020, 53(4), pp 2521&ndash;2548, https://doi.org/10.1007/s10462-019-09740-5. <strong>(IF 5.095, based on JCR 2018</strong>).</p>
<p class="MsoListParagraphCxSpMiddle" style="margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1;">7.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Madeeha Aman, Saeed Mahfooz, Muhammad Zubair, <strong>Neelam Mukhtar</strong>, Kanwal Imran, Shah Khusro &ldquo;Tunnel-Free Distributed Mobility Management (DMM) Support Protocol for Future Mobile Networks&rdquo;, <em>Electronics</em> 2019, <em>8</em>(12), 1519; https://doi.org/10.3390/electronics8121519. (<strong style="mso-bidi-font-weight: normal;">IF 1.764</strong>, <strong>based on JCR 2018)</strong></p>
<p class="MsoListParagraphCxSpMiddle" style="margin-top: 0in; margin-right: 0in; margin-bottom: .0001pt; margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1; mso-layout-grid-align: none; text-autospace: none;">8.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Shah Nazir, Sara Shahzad, Rahmita Wirza, Rohul Amin, Muhammad Ahsan, <strong style="mso-bidi-font-weight: normal;">Neelam Mukhtar</strong>, Ivan Garcia-Magarino, Jaime Lloret. &ldquo;Birthmark based identification of software piracy using Haar wavelet&rdquo;, Mathematics and Computers in Simulation 2019, https://doi.org/10.1016/j.matcom.2019.04.010, 166 (2019), pp 144-154. (<strong style="mso-bidi-font-weight: normal;">IF 1.476, based on JCR 2017). </strong></p>
<p class="MsoListParagraphCxSpMiddle" style="margin-top: 0in; margin-right: 0in; margin-bottom: .0001pt; margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1; mso-layout-grid-align: none; text-autospace: none;">9.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Shah Nazir, Sara Shahzad and <strong style="mso-bidi-font-weight: normal;">Neelam Mukhtar</strong>. &ldquo;Software Birthmark Design and Estimation: A Systematic Literature Review&rdquo;, Arabian Journal for Science and Engineering. https://doi.org/10.1007/s13369-019-03718-9, 44 (4), 2019, pp 3905-3927. (<strong style="mso-bidi-font-weight: normal;">IF 1.092, based on JCR 2017).</strong></p>
<p class="MsoListParagraphCxSpMiddle" style="margin-top: 0in; margin-right: 0in; margin-bottom: .0001pt; margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1; mso-layout-grid-align: none; text-autospace: none;">10.&nbsp; <strong style="mso-bidi-font-weight: normal;">Neelam Mukhtar</strong>, Mohammad Abid Khan, Nadia Chiragh and Shah Nazir.&nbsp; &ldquo;Identification and handling of intensifiers for enhancing accuracy of Urdu sentiment analysis&rdquo;, <em style="mso-bidi-font-style: normal;">Expert Systems</em>. https://doi.org/10.1111/exsy.12317, 35(6), 2018, pp 1-12. (<strong>IF 1.43, based on JCR 2017).</strong></p>
<p class="MsoListParagraphCxSpMiddle" style="margin-top: 0in; margin-right: 0in; margin-bottom: .0001pt; margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-outline-level: 1; mso-list: l0 level1 lfo1;">11.&nbsp; <strong style="mso-bidi-font-weight: normal;">Neelam Mukhtar</strong>, Mohammad Abid Khan, Nadia Chiragh. &ldquo;Lexicon-based approach outperforms supervised machine learning approach for Urdu Sentiment Analysis in multiple domains&rdquo;, <em style="mso-bidi-font-style: normal;">Telematics and Informatics.</em> https://doi.org/10.1016/j.tele.2018.08.003, 35(8), 2018, pp. 2173-2183. (<strong>IF 3.789, based on JCR 2017).</strong></p>
<p class="MsoListParagraphCxSpMiddle" style="margin-top: 0in; margin-right: 0in; margin-bottom: .0001pt; margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1; background: #FCFCFC;">12.&nbsp; <strong style="mso-bidi-font-weight: normal;">Neelam Mukhtar</strong>&nbsp;and&nbsp;Mohammad Abid Khan. &ldquo;Urdu Sentiment Analysis using supervised machine learning approach&rdquo;, <em>Int. J. Patt. Recogn. Artif.Intell.</em>&nbsp;https://doi.org/10.1142/S0218001418510011, 32(2), 2018.pp.1851001-1-1851001-15. <strong>(IF 0.9, based on JCR 2016).&nbsp; </strong></p>
<p class="MsoListParagraphCxSpMiddle" style="margin-top: 0in; margin-right: 0in; margin-bottom: 8.0pt; margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1; background: #FCFCFC;">13.&nbsp; <strong style="mso-bidi-font-weight: normal;">Neelam Mukhtar</strong>, Mohammad Abid Khan and Nadia Chiragh. &ldquo;Effective Use of Evaluation Measures for the Validation of Best Classifier in Urdu Sentiment Analysis&rdquo;,<em style="mso-bidi-font-style: normal;">Cogn Comput</em>. doi:10.1007/s12559-017-9481-5,9(4),2017, pp. 446-456. <strong>(</strong><strong>IF 3.441, based on JCR 2016).</strong></p>
<p class="MsoListParagraphCxSpLast" style="margin-top: 0in; margin-right: 0in; margin-bottom: .0001pt; margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1; background: #FCFCFC;">14.&nbsp; Shah Nazir, Sara Shahzad, <strong style="mso-bidi-font-weight: normal;">Neelam Mukhtar</strong>, Humaira Khan, Islam Zada, Muhammad Nazir, and Rohul Amin, "Test case prioritization for components using FANP," Life Science Journal, 11(6s), 2014, pp. 504-511, <strong>(IF 0.16, based on JCR 2012).</strong></p>
<p class="MsoNormal" style="margin-top: 6.0pt; margin-right: 0in; margin-bottom: 12.0pt; margin-left: 2.25in;"><strong>&nbsp;</strong></p>
<p class="MsoNormal" style="margin-top: 6.0pt; margin-right: 0in; margin-bottom: 12.0pt; margin-left: 2.25in;"><strong>HEC recognized Journal Papers</strong></p>
<p class="MsoListParagraphCxSpFirst" style="margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1;">15.&nbsp; <strong>Neelam Mukhtar</strong>, Mohammad Abid Khan, Nadia Chiragh, Asim Ullah Jan , Shah Nazir,&ldquo;Recognition and Effective Handling of Negations in Enhancing the Accuracy of Urdu Sentiment Analyzer&rdquo;, Mehran University Research Journal of Engineering and Technology, DOI: 10.22581/muet1982.2004.08, 39(4), 2020, pp 759-770 (HEC recognized (HJRS), Y category journal).</p>
<p class="MsoListParagraphCxSpMiddle" style="margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1;">16.&nbsp; Asim Ullah Jan, Mohammad Abid Khan, <strong style="mso-bidi-font-weight: normal;">Neelam Mukhtar, </strong>&ldquo;Opinion Mining and Summarization: A comprehensive Review&rdquo;, Journal of Information Communication Technologies and Robotic Applications (JICTRA), 11 (1), 2020, pp 76-96 (HEC recognized, <strong style="mso-bidi-font-weight: normal;">X</strong> category journal).</p>
<p class="MsoListParagraphCxSpLast" style="margin-top: 0in; margin-right: 0in; margin-bottom: .0001pt; margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1;">17.&nbsp; Mussarat Anwar, Ayesha Anwar and <strong style="mso-bidi-font-weight: normal;">Neelam Mukhtar</strong> &ldquo;Effects of Birth order on Child&rsquo;s Personality&rdquo;, Journal of Independent studies and research (JISR), 7(1), January, 2009.</p>
<p class="MsoNormal" style="margin-top: 6.0pt; margin-right: 0in; margin-bottom: 12.0pt; margin-left: 207.0pt;"><strong>Other Journal Papers</strong></p>
<p class="MsoListParagraphCxSpFirst" style="margin-top: 0in; margin-right: 0in; margin-bottom: .0001pt; margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1;">18.&nbsp; <strong style="mso-bidi-font-weight: normal;">Neelam Mukhtar</strong>, Mohammad Abid Khan, Fatima Tuz Zuhra and Nadia Chiragh<strong style="mso-bidi-font-weight: normal;"> &ldquo;</strong>Implementation of Urdu Probabilistic Parser&rdquo;, International Journal of Computational Linguistics (IJCL), 3(1), 2012. pp 12-20.</p>
<p class="MsoListParagraphCxSpMiddle" style="margin-top: 0in; margin-right: 0in; margin-bottom: .0001pt; margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1;">19.&nbsp; <strong style="mso-bidi-font-weight: normal;">Neelam Mukhtar</strong>, Mohammad Abid Khan and Fatima Tuz Zuhra &ldquo;Algorithm for developing Urdu Probabilistic Parser&rdquo;, International Journal of Electrical and Computer Sciences (IJJECS-IJENS), 12(3),&nbsp; 2012. pp 57-66. </p>
<p class="MsoListParagraphCxSpLast" style="margin-top: 0in; margin-right: 0in; margin-bottom: .0001pt; margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1;">20.&nbsp; <strong style="mso-bidi-font-weight: normal;">Neelam Mukhtar</strong>, Mohammad Abid Khan and Fatima Tuz Zuhra &ldquo;Probabilistic Context Free Grammar for Urdu&rdquo;, Linguistics and Literature Review (LLR), 2(2), 2016. pp. 106-113.</p>
<p class="MsoNormal" style="margin-left: 207.0pt;"><strong>Conference Papers</strong></p>
<p class="Default">&nbsp;</p>
<p class="MsoListParagraphCxSpFirst" style="margin-top: 0in; margin-right: 0in; margin-bottom: .0001pt; margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1;">21.&nbsp; &nbsp;Muhammad Aamir, Asim Ullah Jan, <strong style="mso-bidi-font-weight: normal;">Neelam Mukhtar</strong>, Mohammad Abid Khan, Zafar Ali, Waheed Ahmed Abro, Guan Yurong, &ldquo;An Unsupervised Graph-Based Hybrid Approach For Opinion Summarization&rdquo;, in 2021 18th International Computer Conference on Wavelet Active Media Technology and Information Processing (ICCWAMTIP)&copy;2021,IEEE, pp 83-88</p>
<p class="MsoListParagraphCxSpMiddle" style="margin-top: 0in; margin-right: 0in; margin-bottom: .0001pt; margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1;">22.&nbsp; <strong style="mso-bidi-font-weight: normal;">Neelam Mukhtar</strong>, Sara Shahzad, Mohammad Abid Khan and Shah Nazir &ldquo;Ontology for Feature Based Selection of Web&nbsp; Development Tools&rdquo; in Proceedings of the 8th International Conference of &nbsp;&nbsp;Digital Information Management IEEE ICDIM 2013, 10th -12th September, Islamabad.</p>
<p class="MsoListParagraphCxSpMiddle" style="margin-left: .75in; mso-add-space: auto; text-indent: -.25in; mso-list: l0 level1 lfo1;">23.Shah Nazir, Sara Shahzad, <strong style="mso-bidi-font-weight: normal;">Neelam Mukhtar</strong>, and Muhammad Nazir, "Ontology for efficient text/criteria based search functionality in website", in 2nd&nbsp; Abasyn International Conference on the Technology and Business Management (AiCTM), Pakistan, 2014.</p>
<p class="MsoListParagraphCxSpLast" style="margin-top: 0in; margin-right: 0in; margin-bottom: .0001pt; margin-left: .75in; mso-add-space: auto;">&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<div id="__if72ru4sdfsdfrkjahiuyi_once" style="display: none;">&nbsp;</div>
<div id="__if72ru4sdfsdfruh7fewui_once" style="display: none;">&nbsp;</div>
<div id="__hggasdgjhsagd_once" style="display: none;">&nbsp;</div></p><p align="right">,National,International,Conference Paper by: <a href="profile.php?id=18" class="text-info"><span class="text-info">Dr. Neelam Mukhtar</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p><strong>1.K.Imran,</strong>N.Anjum,S.Mahfooz,,&ldquo;ASecureandEfficientCluster-BasedAuthenticationScheme forIoTs&rdquo;,Computers,Materials&amp;Continua,vol.70,no.1,pp.1033-1052,2022.(IF&ndash;4.89)</p>
<p><strong>2.K.Imran,</strong>N.Anjum,S.Mahfooz,M.Zubair,Y.Zhahouietal.,&ldquo;Cluster-BasedGroupMobility SupportforSmartIoT&rdquo;,Computers,Materials&amp;Continua,vol.68,no.2,pp.2329--2347,2021. (IF&ndash;4.89)</p>
<p><strong>3.K.Imran,</strong>S.Mahfooz,A.RaufandS.Khusro,"EnhancedAuthenticationSchemeforProxy MobileIPv6",LifeScienceJournal,pp.12-18,2014.(IF&ndash;0.683)</p>
<p>4.M.Aman,S.Mahfooz,M.Zubair,N.Mukhtar,<strong>K.Imran</strong>,&ldquo;Tunnel-FreeDistributedMobility Management(DMM)SupportProtocolforFutureMobileNetworks&rdquo;,Electronics,Articleno. 1519,8(12),2019.(IF&ndash;1.764)</p>
<p><strong>5.K.Imran</strong>,&ldquo;SurveyonProxyMobileIPv6&rdquo;InternationalConferenceonComputerNetworksand InformationTechnology(ICCNIT),BaraGali,Pakistan.2011.</p></p><p align="right">,National,International, by: <a href="profile.php?id=37" class="text-info"><span class="text-info">Dr. Kanwal Imran</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Abeera Ilyas, Madeeha Aman, Nasir Saeed, " Delay analysis of an improved WiMAX MacroFemto handover technique and cell selection algorithm", Wireless Personal Communications, Springer, pp 1-12, 21-07-2015, doi: 10.1007/s11277-015-2897-x, print ISSN:0929-6212</p></p><p align="right">,,International, by: <a href="profile.php?id=50" class="text-info"><span class="text-info">Ms. Abeera Ilyas</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Title: Algorithm for an improved MacroFemto handover decision in mobile WiMAX.<br /> Date: 23-25 June 2014<br /> Journal Name: Proceedings of 15th Annual postgraduate symposium on the convergence of telecommunications, networking and broadcasting.<br />&nbsp;ISBN: 978-1-902560-27-4 &copy; 2014 PGNet.</p></p><p align="right">,,,Conference Paper by: <a href="profile.php?id=50" class="text-info"><span class="text-info">Ms. Abeera Ilyas</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Memberships</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>&nbsp;</p>
<p></p>
<ol style="margin-top: 0in;" type="1" start="1">
<li class="MsoNormal" style="color: black; margin-top: 0in; mso-list: l0 level1 lfo1;">Member, HEC funded project under the title &ldquo;Establishment of Computer Based Learning Laboratories at College of Home Economics, University of Peshawar&rdquo;, 2002-2003.</li>
</ol>
<div id="__if72ru4sdfsdfrkjahiuyi_once" style="display: none;">&nbsp;</div>
<div id="__if72ru4sdfsdfruh7fewui_once" style="display: none;">&nbsp;</div>
<div id="__hggasdgjhsagd_once" style="display: none;">&nbsp;</div></p><p align="right"> by: <a href="profile.php?id=18" class="text-info"><span class="text-info">Dr. Neelam Mukhtar</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>HEC recognized supervisors</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>&nbsp;</p>
<div id="__if72ru4sdfsdfrkjahiuyi_once" style="display: none;">&nbsp;</div>
<div id="__if72ru4sdfsdfruh7fewui_once" style="display: none;">&nbsp;</div>
<div id="__hggasdgjhsagd_once" style="display: none;">&nbsp;</div></p><p align="right"> by: <a href="profile.php?id=18" class="text-info"><span class="text-info">Dr. Neelam Mukhtar</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Visits organized</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>&nbsp;</p>
<div id="__if72ru4sdfsdfrkjahiuyi_once" style="display: none;">&nbsp;</div>
<div id="__if72ru4sdfsdfruh7fewui_once" style="display: none;">&nbsp;</div>
<div id="__hggasdgjhsagd_once" style="display: none;">&nbsp;</div></p><p align="right">,, by: <a href="profile.php?id=18" class="text-info"><span class="text-info">Dr. Neelam Mukhtar</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Achievements</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>&nbsp;</p>
<div id="__if72ru4sdfsdfrkjahiuyi_once" style="display: none;">&nbsp;</div>
<div id="__if72ru4sdfsdfruh7fewui_once" style="display: none;">&nbsp;</div>
<div id="__hggasdgjhsagd_once" style="display: none;">&nbsp;</div></p><p align="right">,, by: <a href="profile.php?id=18" class="text-info"><span class="text-info">Dr. Neelam Mukhtar</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Certificate courses offered</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>&nbsp;</p>
<div id="__if72ru4sdfsdfrkjahiuyi_once" style="display: none;">&nbsp;</div>
<div id="__if72ru4sdfsdfruh7fewui_once" style="display: none;">&nbsp;</div>
<div id="__hggasdgjhsagd_once" style="display: none;">&nbsp;</div></p><p align="right"> by: <a href="profile.php?id=18" class="text-info"><span class="text-info">Dr. Neelam Mukhtar</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Social events</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>&nbsp;Organized Farewell paries for M.Sc final from 2001 to 2003.</p>
<div id="__if72ru4sdfsdfrkjahiuyi_once" style="display: none;">&nbsp;</div>
<div id="__if72ru4sdfsdfruh7fewui_once" style="display: none;">&nbsp;</div>
<div id="__hggasdgjhsagd_once" style="display: none;">&nbsp;</div></p><p align="right">,,,Attended by: <a href="profile.php?id=18" class="text-info"><span class="text-info">Dr. Neelam Mukhtar</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Title: The changing role of social media in Muslim countries- Reviewing curricular trends of communication studies in Pakistan<br /> Date: 20th-21st March, 2013<br /> Description: a group discussion arranged by Young Women writer&rsquo;s forum Pakistan.</p></p><p align="right">,Participated,, by: <a href="profile.php?id=50" class="text-info"><span class="text-info">Ms. Abeera Ilyas</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Educational trips</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>&nbsp;</p>
<div id="__if72ru4sdfsdfrkjahiuyi_once" style="display: none;">&nbsp;</div>
<div id="__if72ru4sdfsdfruh7fewui_once" style="display: none;">&nbsp;</div>
<div id="__hggasdgjhsagd_once" style="display: none;">&nbsp;</div></p><p align="right"> by: <a href="profile.php?id=18" class="text-info"><span class="text-info">Dr. Neelam Mukhtar</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Awards</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>&nbsp;</p>
<div id="__if72ru4sdfsdfrkjahiuyi_once" style="display: none;">&nbsp;</div>
<div id="__if72ru4sdfsdfruh7fewui_once" style="display: none;">&nbsp;</div>
<div id="__hggasdgjhsagd_once" style="display: none;">&nbsp;</div></p><p align="right"> by: <a href="profile.php?id=18" class="text-info"><span class="text-info">Dr. Neelam Mukhtar</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Talks</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>&nbsp;</p>
<div id="__if72ru4sdfsdfrkjahiuyi_once" style="display: none;">&nbsp;</div>
<div id="__if72ru4sdfsdfruh7fewui_once" style="display: none;">&nbsp;</div>
<div id="__hggasdgjhsagd_once" style="display: none;">&nbsp;</div></p><p align="right"> by: <a href="profile.php?id=18" class="text-info"><span class="text-info">Dr. Neelam Mukhtar</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Book reviews</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>&nbsp;</p>
<div id="__if72ru4sdfsdfrkjahiuyi_once" style="display: none;">&nbsp;</div>
<div id="__if72ru4sdfsdfruh7fewui_once" style="display: none;">&nbsp;</div>
<div id="__hggasdgjhsagd_once" style="display: none;">&nbsp;</div></p><p align="right"> by: <a href="profile.php?id=18" class="text-info"><span class="text-info">Dr. Neelam Mukhtar</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Promotions</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>&nbsp;1.&nbsp; Promoted as Assistant Professor in 2013.</p>
<div id="__if72ru4sdfsdfrkjahiuyi_once" style="display: none;">&nbsp;</div>
<div id="__if72ru4sdfsdfruh7fewui_once" style="display: none;">&nbsp;</div>
<div id="__hggasdgjhsagd_once" style="display: none;">&nbsp;</div></p><p align="right"> by: <a href="profile.php?id=18" class="text-info"><span class="text-info">Dr. Neelam Mukhtar</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Study Leaves</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>&nbsp;</p>
<div id="__if72ru4sdfsdfrkjahiuyi_once" style="display: none;">&nbsp;</div>
<div id="__if72ru4sdfsdfruh7fewui_once" style="display: none;">&nbsp;</div>
<div id="__hggasdgjhsagd_once" style="display: none;">&nbsp;</div></p><p align="right"> by: <a href="profile.php?id=18" class="text-info"><span class="text-info">Dr. Neelam Mukhtar</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Higher qualifications</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>&nbsp;Awarded Ph.D Computer Science Degree in June 2018</p>
<div id="__if72ru4sdfsdfrkjahiuyi_once" style="display: none;">&nbsp;</div>
<div id="__if72ru4sdfsdfruh7fewui_once" style="display: none;">&nbsp;</div>
<div id="__hggasdgjhsagd_once" style="display: none;">&nbsp;</div></p><p align="right"> by: <a href="profile.php?id=18" class="text-info"><span class="text-info">Dr. Neelam Mukhtar</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Got&nbsp; Ph.D degree in computer science from Department of Computer Science, University of Peshawar in aug,2022</p></p><p align="right"> by: <a href="profile.php?id=37" class="text-info"><span class="text-info">Dr. Kanwal Imran</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Enrolled in Ph.D computer science at Department of Computer Science, University of Peshawar in Oct 2016</p></p><p align="right"> by: <a href="profile.php?id=50" class="text-info"><span class="text-info">Ms. Abeera Ilyas</span></a>
                                </p>
                                </div>
                                                                </div>
                                
                            </div>

                        </div>
                        <div class="span3">
                            <h3>Announcements <a href="announcements.php" style="font-size:12px;">View All</a></h3>
                            <div id="news-container">
                            <ul class="list4 support-box">
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=209"><time datetime="2024-10-30">October 30, 2024</time></a>
                                        <div>Science Department, College of Home Econ...</div>
                                        <div><a href="show-event.php?id=209" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=208"><time datetime="2024-10-06">October 06, 2024</time></a>
                                        <div>Ms. Sidra Ali defended her research unde...</div>
                                        <div><a href="show-event.php?id=208" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=207"><time datetime="2024-09-11">September 11, 2024</time></a>
                                        <div>The entry test for MPhil/PhD programs in...</div>
                                        <div><a href="show-event.php?id=207" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                            </ul>
                            </div>
                            <h3>Upcoming Events <a href="upcoming-events.php" style="font-size:12px;">View All</a></h3>
                            <div id="news-container2">
                            <ul class="list4 support-box">
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=202"><time datetime="2024-03-03">March 03, 2024</time></a>
                                        <div>SPRING FIESTA, TUESDAY 5TH MARCH 2024....</div>
                                        <div><a href="show-event.php?id=202" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=201"><time datetime="2024-02-21">February 21, 2024</time></a>
                                        <div>A two day book fair was organized in col...</div>
                                        <div><a href="show-event.php?id=201" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=193"><time datetime="2023-10-04">October 04, 2023</time></a>
                                        <div>Newly admitted FSc students Orientation ...</div>
                                        <div><a href="show-event.php?id=193" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                            </ul>
                            </div>
                            
                        </div>                    </div>
                 </article>
            </div>
        </section>
    </div>
</div>
</div>
<!--footer-->
<footer>
    <div class="main">
        <div class="container">
            <div class="row">
                <article class="span12">
                    <p style="margin-top:20px;">College of Home Economics &copy; 2024. <a href="privacy-policy.php" title="Learn how we use your information">Privacy Policy</a></p>
                    <p align="right"><a style="display:none;" target="_blank" title="Site designed by SuperWebz.com" href="http://www.superwebz.com"><img src="img/superwebz_logo.jpg" alt="SuperWebz.com" /></a></p>
                </article>
            </div>
            <!-- {%FOOTER_LINK} -->
        </div>  
    </div> 
</footer><script type="text/javascript" src="js/bootstrap.js"></script>
<script>
    $('.list3 li a').hover(function(){
        $(this).stop().css({color:'#fc6f22'});	
        $(this).stop().parent().siblings('em').css({'background-position':'0 bottom'});	 
            }, function(){
        $(this).stop().css({color:'#1295d4'});	
        $(this).stop().parent().siblings('em').css({'background-position':'0 top'});						 
    })
    $('#search a').hover(function(){
        $(this).stop().animate({opacity:'0.5'});	
            }, function(){
       $(this).stop().animate({opacity:'1'});						 
    })
</script>

</body>
</html>
