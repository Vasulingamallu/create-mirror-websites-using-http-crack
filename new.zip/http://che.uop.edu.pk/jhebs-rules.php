<!DOCTYPE html>
<html lang="en">
<head>
<title>Rules > Journal of Home Economics and Behavioral Sciences (JHEBS) - College of Home Economics, University of Peshawar</title>
<meta charset="utf-8">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
<meta name = "format-detection" content = "telephone=no" />
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<!--CSS-->
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/camera.css">
<!--JS-->
<script src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery.vticker-min.js"></script>
<script src="js/jquery-migrate-1.1.1.js"></script>
<script src="js/superfish.js"></script>
<script src="js/jquery.mobilemenu.js"></script>
<script src="js/jquery.cookie.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.ui.totop.js"></script>
<script>	
	$(function(){
	$('#news-container').vTicker({ 
		speed: 500,
		pause: 5000,
		animation: 'fade',
		mousePause: true,
		showItems: 3
		});
	});
	
	$(function(){
	$('#news-container2').vTicker({ 
		speed: 500,
		pause: 5000,
		animation: 'fade',
		mousePause: true,
		showItems: 2
		});
	});
</script>
<!--[if (gt IE 9)|!(IE)]><!-->
      <script type="text/javascript" src="js/jquery.mobile.customized.min.js"></script>
<!--<![endif]-->    
<!--[if lt IE 8]>
		<div style='text-align:center'><a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/img/upgrade.jpg"border="0"alt=""/></a></div>  
<![endif]-->
<!--[if lt IE 9]>
  <link rel="stylesheet" href="css/ie.css">
  <link rel="stylesheet" href="css/docs.css">
  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body>
<div class="global">
<!--header-->
<header>
    <div class="main">
        <div class="gradient">
        <div class="container">
             <article>
                <div class="navbar navbar_ clearfix">
                    <div class="navbar-inner">      
                          <div class="clearfix">
                                <div class="nav-collapse nav-collapse_">
                                	<ul class="nav sf-menu clearfix">
                                	  <li><a href="index.php">Home</a></li>
                                      <li class="sub-menu"><a href="#">About</a>
                                        <ul>
                                            <li><a href="che-history.php">Brief History</a></li>
                                            <li><a href="leadership.php">Leadership</a></li>
                                            <li><a href="foundation-faculty.php">Foundation Faculty</a></li>
                                            <li><a href="contact-us.php">Contact Us</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Programs</a>
                                        <ul>
                                            <li><a href="art-design-introduction.php">Art & Design</a></li>
                                            <li><a href="food-nutrition-sciences-introduction.php">Food & Nutrition Sciences</a></li>
                                            <li><a href="human-development-family-studies-introduction.php">Human Development &amp; Family Studies</a></li>
                                            <li><a href="resource-facility-management-introduction.php">Resource &amp; Facility Management</a></li>
                                            <li><a href="textile-clothing-introduction.php">Textile & Clothing</a></li>
                                            <li><a href="#">Mandatory Supportive<span></span></a>
                                              <ul>
                                             <li><a href="computer-science-introduction.php">Computer Science</a></li>
                                              <li><a href="english-introduction.php">English</a></li>
                                              <li><a href="pak-studies-introduction.php">Pak. Studies</a></li>

                                              <li><a href="science-introduction.php">Science Department</a></li>
                                              <li><a href="urdu-islamiyat-introduction.php">Urdu / Islamiyat</a></li>
                                              </ul>
                                            </li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Admissions</a>
                                        <ul>
                                          <li><a href="bsc.php">BS Public Health<span></span></a>
                                        	<ul>
                                              <li><a href="bsc-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="bsc-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="bsc-uniform.php">Uniform</a></li>
                                              <li><a href="bsc-merit-list.php">Merit List</a></li>
                                              <li><a href="bsc-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="fsc.php">F.A/ F.Sc.<span></span></a>
                                        	<ul>
                                              <li><a href="fsc-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="fsc-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="fsc-uniform.php">Uniform</a></li>
                                              <li><a href="fsc-merit-list.php">Merit List</a></li>
                                              <li><a href="fsc-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="bs-hons.php">B.S Home Economics<span></span></a>
                                        	<ul>
                                              <li><a href="bs-hons-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="bs-hons-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="bs-hons-uniform.php">Uniform</a></li>
                                              <li><a href="bs-hons-merit-list.php">Merit List</a></li>
                                              <li><a href="bs-hons-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="msc.php">BS Human Nutrition & Dietetics<span></span></a>
                                        	<ul>
                                              <li><a href="msc-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="msc-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="msc-uniform.php">Uniform</a></li>
                                              <li><a href="msc-merit-list.php">Merit List</a></li>
                                              <li><a href="msc-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="mphil.php">M.Phil<span></span></a>
                                        	<ul>
                                              <li><a href="mphil-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="mphil-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="mphil-uniform.php">Uniform</a></li>
                                              <li><a href="mphil-merit-list.php">Merit List</a></li>
                                              <li><a href="mphil-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="phd.php">Ph.D<span></span></a>
                                        	<ul>
                                              <li><a href="phd-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="phd-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="phd-uniform.php">Uniform</a></li>
                                              <li><a href="phd-merit-list.php">Merit List</a></li>
                                              <li><a href="phd-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Examination</a>
                                        <ul>
                                          <li><a href="examination-rules.php">Rules</a></li>
                                          <li><a href="datesheet.php">Date Sheet</a></li>
                                          <li><a href="results.php">Results</a></li>
                                          <li><a href="convocation.php">Convocation</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="college-faculty.php">Faculty</a>
                                        <ul>
                                          <li><a href="faculty-art-and-design.php">Art & Design</a></li>
                                          <li><a href="faculty-food-and-nutrition-sciences.php">Food & Nutrition Sciences</a></li>
                                          <li><a href="faculty-human-development-and-family-studies.php">Human Development and Family Studies</a></li>
                                          <li><a href="faculty-resource-and-facility-management.php">Resource and Facility Management</a></li>
                                          <li><a href="faculty-textile-and-clothing.php">Textile & Clothing</a></li>
                                          <li><a href="faculty-science.php">Science</a></li>
                                          <li><a href="faculty-computer-studies.php">Computer Studies</a></li>
                                          <li><a href="faculty-english.php">English</a></li>
                                          <li><a href="faculty-pak-studies.php">Pak. Studies</a></li>
                                          <li><a href="faculty-urdu.php">Urdu</a></li>
                                          <li><a href="faculty-islamiyat.php">Islamiyat</a></li>
                                          <li><a href="faculty-login.php">Faculty Login</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Student's Life</a>
                                        <ul>
                                          <li><a href="students-societies.php">Student Societies</a></li>
                                          <li><a href="students-society-members.php">Society Members</a></li>
                                          <li><a href="students-academic-visits.php">Academic Visits</a></li>
                                          <li><a href="students-recreational-trips.php">Recreational Trips</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Facilities</a>
                                        <ul>
                                  <li><a href="facilities-bookshop.php">Bookshop</a></li>                                          <li><a href="facilities-canteen.php">Canteen</a></li>

                                          <li><a href="facilities-daycare.php">Day Care</a></li>                                          <li><a href="facilities-first-aid-room.php">First Aid Room</a></li>

                                          <li><a href="facilities-generators.php">Generators</a></li>
                                                                                                                   <li><a href="facilities-home-management-residence.php">Home Management Residence</a></li>
        <li><a href="facilities-hostel.php">Hostel</a></li>
   <li><a href="facilities-internet.php">Internet</a></li>

                                          <li><a href="facilities-library.php">Library</a></li>
                                                                              <li><a href="facilities-mosque.php">Mosque</a></li>
                                          <li><a href="facilities-nursery.php">Nursery</a></li>
                                        <li><a href="facilities-photocopier.php">Photocopier</a></li>

                                          <li><a href="facilities-playgroup.php">Play Group</a></li>
                                            <li><a href="facilities-preplaygroup.php">Pre Play Group</a></li>      
                                          <li><a href="facilities-transport.php">Transport</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="alumni-list.php">PFHE</a>
                                        <ul>
                                          <li><a href="pfhe.php">Introduction</a></li>
                                          <li><a href="alumni-profile.php">Members Profile</a></li>
                                          <li><a href="alumni-list.php">Federation & Alumni Members</a></li>
                                        </ul>
  </li>
                                      <li class="sub-menu"><a href="#">JHEBS</a>
                                        <ul><li><a href="jhebs-call-for-papers.php">Call for Papers</a></li>
                                          <li><a href="jhebs-published-versions.php">Published Versions</a></li>
                                          <li><a href="jhebs-research.php">Research</a></li>
                                          <li><a href="jhebs-rules.php">Rules</a></li>
                                                                                    <li><a href="jhebs-updates.php">Updates</a></li>

                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Conference</a>
                                        <ul>
                                          <li><a href="conference-call-for-papers.php">Call For Papers</a></li>
										  <li><a href="conference-accepted-papers.php">Accepted Papers</a></li>
										  <li><a href="conference-registration-and-payment.php">Registration and Payment</a></li>
										  <li><a href="conference-important-dates.php">Important Dates</a></li>
										  <li><a href="conference-keynote-speaker.php">Keynote Speaker</a></li>
										  <li><a href="conference-committee.php">Committee</a></li>
										  <li><a href="conference-abstract-submission.php">Abstract Submission</a></li>
										  <li><a href="conference-topics.php">Conference Topics</a></li>
										  <li><a href="conference-presentation-instructions.php">Presentation Instructions</a></li>
										  <li><a href="conference-who-should-attend.php">Who should Attend</a></li>
										  <li><a href="conference-tentative-programme.php">Tentative Programme</a></li>
										  <li><a href="conference-venue.php">Venue</a></li>
										  <li><a href="conference-final-paper-submission.php">Final Paper Submission</a></li>
										  <li><a href="conference-paper-templates.php">Paper Templates</a></li>
										  <li><a href="conference-accommodation-and-travel.php">Accommodation & Travel</a></li>
										  <li><a href="conference-conference-poster.php">Conference Poster</a></li>
										  <li><a href="contact-us.php">Contact Us</a></li>
                                        </ul>
                                      </li>
									  <li class="sub-menu"><a href="#">Activities</a>
                                        <ul>                                          <li><a href="college-magazine.php">College Magazine</a></li>
                                          <li><a href="activities-exhibitions.php">Exhibitions</a></li>
                                          <li><a href="activities-internships.php">Internships</a></li>
                                          <li><a href="activities-lectures.php">Lectures</a></li>
                                          <li><a href="newsletter.php">Newsletter</a></li>                                          <li><a href="activities-seminars.php">Seminars</a></li>

                                          <li><a href="activities-sports.php">Sports</a></li>
                                                                                 <li><a href="activities-tutorials.php">Tutorials</a></li>
   <li><a href="activities-workshops.php">Workshops</a></li>
                                        </ul>
                                      </li>
                                    </ul>
                                 </div>
                                 <ul class="follow_icon">
                                    <li><a href="https://www.facebook.com/CHEUOP/"><img src="img/follow_icon2.png" alt=""></a></li>                                                                    </ul>                          </div>
                    </div>
                </div>
                <h1 class="brand"><a href="index.php"><img src="img/logo.png" alt=""></a></h1>
                <form id="search" class="search" action="search-results.php" method="GET" accept-charset="utf-8">
                	 <input type="text" onFocus="if(this.value =='Search for...' ) this.value=''" onBlur="if(this.value=='') this.value='Search for...'" value="Search for..." name="q">
                     <a href="#" onClick="document.getElementById('search').submit()"><img src="img/magnify.png" alt=""></a>
                </form>             </article>
        </div>
        </div>
    </div>
</header>

<div class="main">
    <div class="gradient1">
        <section class="container">
            <div class="row">
                <article class="span12 margBot6">
                    <div class="row">
                        <div class="span3 support-box">
                            <h3>JHEBS Links</h3>
                            <ul class="list3">
                                  <li><em></em><p><a href="jhebs-research.php">Research</a></p></li>
                                  <li><em></em><p><a href="jhebs-updates.php">Updates</a></p></li>
                                  <li><em></em><p><a href="jhebs-rules.php">Rules</a></p></li>
                                  <li><em></em><p><a href="jhebs-call-for-papers.php">Call for Papers</a></p></li>
                                  <li><em></em><p><a href="jhebs-published-versions.php">Published Versions</a></p></li>
                            </ul>
                        </div>
                        <div class="span6 support-box">
                            <h3>Journal of Home Economics and Behavioral Sciences (JHEBS) > Rules</h3>
                                                        <p class="margBot"><p class="margBot"><strong>AUTHOR'S GUIDELINE&nbsp;</strong></p>

<p class="margBot">The paper file is limited to a maximum of 2MB electronic file size. Documents must be received in MS word format. Text should appear in 12-point Times Roman, single-spaced, with one inch or 3cm margins all around. The body of the paper should be right &amp; left justified. Figures placed within the text should have the same margins as the, as a maximum.&nbsp;</p>

<p class="margBot">At the top of the page, place a center-justified heading as follows:</p>

<p class="margBot">Full title of paper &nbsp;(16 point bold)</p>

<p class="margBot">Author ( s ) name ( s ) ( 12 point bold ) Organization / affiliation &nbsp;(12 point bold )</p>

<p class="margBot">Complete postal Address (12 point bold )&nbsp;</p>

<p class="margBot">Telephone number ( 12 point bold )&nbsp;</p>

<p class="margBot">&nbsp;Email address ( 12 point bold )&nbsp;</p>

<p class="margBot">The paper begins on this page &nbsp;(there is no separate title page ) and must contain:</p>

<p class="margBot">1. An abstract summarizing the entire paper (not exceeding 200 words in italics)&nbsp;</p>

<p class="margBot">2. List of up to eight keywords that describes the paper.</p>

<p class="margBot">3. Body of paper&nbsp;</p>

<p class="margBot">4. Results include tables and their descriptions.&nbsp;</p>

<p class="margBot">5. Discussion</p>

<p class="margBot">6. Conclusion&nbsp;</p>

<p class="margBot">7. References ( when formatting your references, please ensure you check the reference style followed by APA.</p>

<p class="margBot">Please contact us if you are having any queries.</p>

<hr />
<p class="margBot"><strong>Guidelines for Publishing Papers in the JOE</strong></p>

<p class="margBot">Writing an effective article is a challenging assignment. The following guidelines are provided to assist authors in submitting manuscripts.</p>

<p class="margBot">The&nbsp;<em>JOE</em>&nbsp;publishes original and review articles related to the scientific and applied aspects of endodontics. Moreover, the&nbsp;<em>JOE</em>&nbsp;has a diverse readership that includes full-time clinicians, full-time academicians, residents, students and scientists. Effective communication with this diverse readership requires careful attention to writing style.</p>

<p class="margBot"><a href="http://www.aae.org/publications-and-research/journal-of-endodontics/guidelines-for-publishing-papers-in-the-joe.aspx#GeneralPoints"><strong>General Points on Composition</strong></a></p>

<p class="margBot"><a href="http://www.aae.org/publications-and-research/journal-of-endodontics/guidelines-for-publishing-papers-in-the-joe.aspx#Organization"><strong>Organization of Original Research Manuscripts</strong></a></p>

<p class="margBot"><a href="http://www.aae.org/publications-and-research/journal-of-endodontics/guidelines-for-publishing-papers-in-the-joe.aspx#ManuscriptsCategory"><strong>Manuscripts Category Classifications and Requirements</strong></a></p>

<p class="margBot"><a href="http://www.aae.org/publications-and-research/journal-of-endodontics/guidelines-for-publishing-papers-in-the-joe.aspx#Resources"><strong>Available Resources</strong></a></p>

<ol>
	<li>&nbsp;<strong>General Points on Composition</strong>

	<ol>
		<li>Authors are strongly encouraged to analyze their final draft with both software (<em>e.g.</em>, spelling and grammar programs) and colleagues who have expertise in English grammar. References listed at the end of this section provide a more extensive review of rules of English grammar and guidelines for writing a scientific article. Always remember that clarity is the most important feature of scientific writing. Scientific articles must be clear and precise in their content and concise in their delivery since their purpose is to inform the reader. The Editor reserves the right to edit all manuscripts or to reject those manuscripts that lack clarity or precision, or have unacceptable grammar or syntax. The following list represents common errors in manuscripts submitted to the <em>JOE</em>:</li>
		<li>The paragraph is the ideal unit of organization. Paragraphs typically start with an introductory sentence that is followed by sentences that describe additional detail or examples. The last sentence of the paragraph provides conclusions and forms a transition to the next paragraph. Common problems include one-sentence paragraphs, sentences that do not develop the theme of the paragraph (see also section &ldquo;c&rdquo; below), or sentences with little to no transition within a paragraph.</li>
		<li>Keep to the point. The subject of the sentence should support the subject of the paragraph. For example, the introduction of authors&rsquo; names in a sentence changes the subject and lengthens the text. In a paragraph on sodium hypochlorite, the sentence, &ldquo;In 1983, Langeland et al., reported that sodium hypochlorite acts as a lubricating factor during instrumentation and helps to flush debris from the root canals&rdquo; can be edited to: &ldquo;Sodium hypochlorite acts as a lubricant during instrumentation and as a vehicle for flushing the generated debris (Langeland et al., 1983).&quot; In this example, the paragraph&rsquo;s subject is sodium hypochlorite and sentences should focus on this subject.</li>
		<li>Sentences are stronger when written in the active voice,&nbsp;<em>i.e.</em>, the subject performs the action. Passive sentences are identified by the use of passive verbs such as &ldquo;was,&rdquo; &ldquo;were,&rdquo; &ldquo;could,&rdquo; etc. For example: &ldquo;Dexamethasone was found in this study to be a factor that was associated with reduced inflammation,&rdquo; can be edited to: &ldquo;Our results demonstrated that dexamethasone reduced inflammation.&rdquo; Sentences written in a direct and active voice are generally more powerful and shorter than sentences written in the passive voice.</li>
		<li>Reduce verbiage. Short sentences are easier to understand. The inclusion of unnecessary words is often associated with the use of a passive voice, a lack of focus or run-on sentences. This is not to imply that all sentences need be short or even the same length. Indeed, variation in sentence structure and length often helps to maintain reader interest. However, make all words count. A more formal way of stating this point is that the use of subordinate clauses adds variety and information when constructing a paragraph. (This section was written deliberately with sentences of varying length to illustrate this point.)</li>
		<li>Use parallel construction to express related ideas. For example, the sentence, &ldquo;Formerly, endodontics was taught by hand instrumentation, while now rotary instrumentation is the common method,&rdquo; can be edited to &ldquo;Formerly, endodontics was taught using hand instrumentation; now it is commonly taught using rotary instrumentation.&rdquo; The use of parallel construction in sentences simply means that similar ideas are expressed in similar ways, and this helps the reader recognize that the ideas are related.</li>
		<li>Keep modifying phrases close to the word that they modify. This is a common problem in complex sentences that may confuse the reader. For example, the statement, &ldquo;Accordingly, when conclusions are drawn from the results of this study, caution must be used,&rdquo; can be edited to &ldquo;Caution must be used when conclusions are drawn from the results of this study.&rdquo;</li>
		<li>To summarize these points, effective sentences are clear and precise, and often are short, simple and focused on one key point that supports the paragraph&rsquo;s theme.&nbsp;</li>
		<li>Authors should be aware that the&nbsp;<em>JOE</em>&nbsp;uses iThenticate, plagiarism detection software, to assure originality and integrity of material published in the&nbsp;<em>Journal</em>. The use of copied sentences, even when present within quotation marks, is highly discouraged. Instead, the information of the original research should be expressed by new manuscript author&rsquo;s own words, and a proper citation given at the end of the sentence. Plagiarism will not be tolerated and manuscripts will be rejected, or papers withdrawn after publication based on unethical actions by the authors. In addition, authors may be sanctioned for future publication.</li>
	</ol>
	</li>
	<li>&nbsp;<strong>Organization of Original Research Manuscripts</strong></li>
</ol>

<p class="margBot"><strong><em>Please Note:</em></strong><em>&nbsp;All abstracts should be organized into sections that start with a one-word title (in bold),&nbsp;</em>i.e.<em>, Introduction, Methods, Results, Conclusions, etc., and should not exceed more than 250 words in length.</em></p>

<ol>
	<li><strong>Title Page:</strong>&nbsp;The title should describe the major emphasis of the paper. It should be as short as possible without loss of clarity. Remember that the title is your advertising billboard&mdash;it represents your major opportunity to solicit readers to spend the time to read your paper. It is best not to use abbreviations in the title since this may lead to imprecise coding by electronic citation programs such as PubMed (<em>e.g.</em>, use &ldquo;sodium hypochlorite&rdquo; rather than NaOCl). The author list must conform to published standards on authorship (see authorship criteria in the Uniform Requirements for Manuscripts Submitted to Biomedical Journals at<a href="http://www.icmje.org/" target="_blank"><strong><em>www.icmje.org</em></strong></a>). The manuscript title, name and address (including email) of one author designated as the corresponding author. This author will be responsible for editing proofs and ordering reprints when applicable. The contribution of each author should also be highlighted in the cover letter.</li>
	<li><strong>Abstract:</strong>&nbsp;The abstract should concisely describe the purpose of the study, the hypothesis, methods, major findings and conclusions. The abstract should describe the new contributions made by this study. The word limitations (250 words) and the wide distribution of the abstract (<em>e.g.</em>, PubMed) make this section challenging to write clearly. This section often is written last by many authors since they can draw on the rest of the manuscript. Write the abstract in past tense since the study has been completed. Three to ten keywords should be listed below the abstract.</li>
	<li><strong>Introduction:</strong>&nbsp;The introduction should briefly review the pertinent literature in order to identify the gap in knowledge that the study is intended to address and the limitations of previous studies in the area. The purpose of the study, the tested hypothesis and its scope should be clearly described. Authors should realize that this section of the paper is their primary opportunity to establish communication with the diverse readership of the&nbsp;<em>JOE</em>. Readers who are not expert in the topic of the manuscript are likely to skip the paper if the introduction fails to succinctly summarize the gap in knowledge that the study addresses. It is important to note that many successful manuscripts require no more than a few paragraphs to accomplish these goals. Therefore, authors should refrain from performing extensive review or the literature, and discussing the results of the study in this section.</li>
	<li><strong>Materials and Methods:</strong>&nbsp;The objective of the materials and methods section is to permit other investigators to repeat your experiments. The four components to this section are the detailed description of the materials used and their components, the experimental design, the procedures employed, and the statistical tests used to analyze the results. The vast majority of manuscripts should cite prior studies using similar methods and succinctly describe the essential aspects used in the present study. Thus, the reader should still be able to understand the method used in the experimental approach and concentration of the main reagents (<em>e.g.</em>, antibodies, drugs, etc.) even when citing a previously published method. The inclusion of a &ldquo;methods figure&rdquo; will be rejected unless the procedure is novel and requires an illustration for comprehension. If the method is novel, then the authors should carefully describe the method and include validation experiments. If the study utilized a&nbsp;<strong>commercial product</strong>, the manuscript must state that they either followed manufacturer&rsquo;s protocol&nbsp;<em>or</em>specify any changes made to the protocol. If the study used an&nbsp;<strong><em>in vitro</em>&nbsp;model&nbsp;</strong>to simulate a clinical outcome, the authors must describe experiments made to validate the model, or previous literature that proved the clinical relevance of the model. Studies on&nbsp;<strong>humans</strong>&nbsp;must conform to the Helsinki Declaration of 1975 and state that the institutional IRB/equivalent committee(s) approved the protocol and that informed consent was obtained after the risks and benefits of participation were described to the subjects or patients recruited. Studies involving&nbsp;<strong>animals</strong>&nbsp;must state that the institutional animal care and use committee approved the protocol. The statistical analysis section should describe which tests were used to analyze which dependent measures; p-values should be specified. Additional details may include randomization scheme, stratification (if any), power analysis as a basis for sample size computation, drop-outs from clinical trials, the effects of important confounding variables, and bivariate versus multivariate analysis.</li>
	<li><strong>Results:</strong>&nbsp;Only experimental results are appropriate in this section (<em>i.e.</em>, neither methods, discussion, nor conclusions should be in this section). Include only those data that are critical for the study, as defined by the aim(s). Do not include all available data without justification; any repetitive findings will be rejected from publication. All Figures, Charts and Tables should be described in their order of numbering with a brief description of the major findings. Author may consider the use of supplemental figures, tables or video clips that will be published online. Supplemental material is often used to provide additional information or control experiments that support the results section (<em>e.g.</em>, microarray data).</li>
	<li><strong>Figures:</strong>&nbsp;There are two general types of figures. The first type of figures includes photographs, radiographs or micrographs. Include only essential figures, and even if essential, the use of composite figures containing several panels of photographs is encouraged. For example, most photo-, radio- or micrographs take up one column-width, or about 185 mm wide X 185 mm tall. If instead, you construct a two columns-width figure (<em>i.e.</em>, about 175 mm wide X 125 mm high when published in the&nbsp;<em>JOE</em>), you would be able to place about 12 panels of photomicrographs (or radiographs, etc.) as an array of four columns across and three rows down (with each panel about 40 X 40 mm). This will require some editing to emphasize the most important feature of each photomicrograph, but it greatly increases the total number of illustrations that you can present in your paper. Remember that each panel must be clearly identified with a letter (<em>e.g.</em>, &ldquo;A,&rdquo; &ldquo;B,&rdquo; etc.), in order for the reader to understand each individual panel. Several nice examples of composite figures are seen in recent articles by Jeger et al (J Endod 2012;38:884&ndash;888); Olivieri et al., (J Endod 2012;38:1007 1011); Tsai et al (J Endod 2012;38:965&ndash;970). Please note that color figures may be published at no cost to the authors and authors are encouraged to use color to enhance the value of the illustration. Please note that a multipanel, composite figure only counts as one figure when considering the total number of figures in a manuscript (see section 3, below, for maximum number of allowable figures).<br />
	<br />
	The second type of figures are graphs (<em>i.e.</em>, line drawings including bar graphs) that plot a dependent measure (on the Y axis) as a function of an independent measure (usually plotted on the X axis). Examples include a graph depicting pain scores over time, etc. Graphs should be used when the overall trend of the results are more important than the exact numerical values of the results. For example, a graph is a convenient way of reporting that an ibuprofen-treated group reported less pain than a placebo group over the first 24 hours, but was the same as the placebo group for the next 96 hours. In this case, the trend of the results is the primary finding; the actual pain scores are not as critical as the relative differences between the NSAID and placebo groups.</li>
	<li><strong>Tables:</strong>&nbsp;Tables are appropriate when it is critical to present exact numerical values. However, not all results need be placed in either a table or figure. For example, the following table may not be necessary:</li>
</ol>

<table border="1" cellpadding="0" cellspacing="0" style="width:636px">
	<tbody>
		<tr>
			<td style="height:16px; width:57px">
			<p class="margBot"><strong>% NaOCl</strong></p>
			</td>
			<td style="height:16px">
			<p class="margBot">&nbsp;</p>
			</td>
			<td style="height:16px">
			<p class="margBot"><strong>N/Group</strong></p>
			</td>
			<td style="height:16px">
			<p class="margBot">&nbsp;</p>
			</td>
			<td style="height:16px">
			<p class="margBot"><strong>% Inhibition of Growth</strong></p>
			</td>
		</tr>
		<tr>
			<td>
			<p class="margBot">0.001</p>
			</td>
			<td>
			<p class="margBot">&nbsp;</p>
			</td>
			<td>
			<p class="margBot">5</p>
			</td>
			<td>
			<p class="margBot">&nbsp;</p>
			</td>
			<td>
			<p class="margBot">0</p>
			</td>
		</tr>
		<tr>
			<td>
			<p class="margBot">0.003</p>
			</td>
			<td>
			<p class="margBot">&nbsp;</p>
			</td>
			<td>
			<p class="margBot">5</p>
			</td>
			<td>
			<p class="margBot">&nbsp;</p>
			</td>
			<td>
			<p class="margBot">0</p>
			</td>
		</tr>
		<tr>
			<td>
			<p class="margBot">0.01</p>
			</td>
			<td>
			<p class="margBot">&nbsp;</p>
			</td>
			<td>
			<p class="margBot">5</p>
			</td>
			<td>
			<p class="margBot">&nbsp;</p>
			</td>
			<td>
			<p class="margBot">0</p>
			</td>
		</tr>
		<tr>
			<td>
			<p class="margBot">0.03</p>
			</td>
			<td>
			<p class="margBot">&nbsp;</p>
			</td>
			<td>
			<p class="margBot">5</p>
			</td>
			<td>
			<p class="margBot">&nbsp;</p>
			</td>
			<td>
			<p class="margBot">0</p>
			</td>
		</tr>
		<tr>
			<td>
			<p class="margBot">0.1</p>
			</td>
			<td>
			<p class="margBot">&nbsp;</p>
			</td>
			<td>
			<p class="margBot">5</p>
			</td>
			<td>
			<p class="margBot">&nbsp;</p>
			</td>
			<td>
			<p class="margBot">100</p>
			</td>
		</tr>
		<tr>
			<td>
			<p class="margBot">0.3</p>
			</td>
			<td>
			<p class="margBot">&nbsp;</p>
			</td>
			<td>
			<p class="margBot">5</p>
			</td>
			<td>
			<p class="margBot">&nbsp;</p>
			</td>
			<td>
			<p class="margBot">100</p>
			</td>
		</tr>
		<tr>
			<td>
			<p class="margBot">1</p>
			</td>
			<td>
			<p class="margBot">&nbsp;</p>
			</td>
			<td>
			<p class="margBot">5</p>
			</td>
			<td>
			<p class="margBot">&nbsp;</p>
			</td>
			<td>
			<p class="margBot">100</p>
			</td>
		</tr>
		<tr>
			<td>
			<p class="margBot">3</p>
			</td>
			<td>
			<p class="margBot">&nbsp;</p>
			</td>
			<td>
			<p class="margBot">5</p>
			</td>
			<td>
			<p class="margBot">&nbsp;</p>
			</td>
			<td>
			<p class="margBot">100</p>
			</td>
		</tr>
	</tbody>
</table>

<ol>
	<li><br />
	Instead, the results could simply state that there was no inhibition of growth from 0.001-0.03% NaOCl, and a 100% inhibition of growth from 0.03-3% NaOCl (N=5/group). Similarly, if the results are not significant, then it is probably not necessary to include the results in either a table or as a figure. These and many other suggestions on figure and table construction are described in additional detail in Day (1998).</li>
	<li><strong>Discussion:</strong>&nbsp;This section should be used to interpret and explain the results. Both the strengths and weaknesses of the observations should be discussed. How do these findings compare to the published literature? What are the clinical implications? Although this last section might be tentative given the nature of a particular study, the authors should realize that even preliminary clinical implications might have value for the clinical readership. Ideally, a review of the potential clinical significance is the last section of the discussion. What are the major conclusions of the study? How does the data support these conclusions</li>
	<li><strong>Acknowledgments:</strong>&nbsp;All authors must affirm that they have no financial affiliation (<em>e.g.</em>, employment, direct payment, stock holdings, retainers, consultantships, patent licensing arrangements or honoraria), or involvement with any commercial organization with direct financial interest in the subject or materials discussed in this manuscript, nor have any such arrangements existed in the past three years. Any other potential conflict of interest should be disclosed. Any author for whom this statement is not true must append a paragraph to the manuscript that fully discloses any financial or other interest that poses a conflict. Likewise the sources and correct attributions of all other grants, contracts or donations that funded the study must be disclosed</li>
	<li><strong>References:</strong>&nbsp;The reference style follows Index Medicus and can be easily learned from reading past issues of the&nbsp;<em>JOE</em>. The&nbsp;<em>JOE</em>&nbsp;uses the Vancouver reference style, which can be found in most citation management software products. Citations are placed in parentheses at the end of a sentence or at the end of a clause that requires a literature citation. Do not use superscript for references. Original reports are limited to 35 references. There are no limits in the number of references for review articles.</li>
</ol>

<ol>
	<li>&nbsp;<strong>Manuscripts Category Classifications and Requirements</strong></li>
</ol>

<p class="margBot">Manuscripts submitted to the&nbsp;<em>JOE</em>&nbsp;must fall into one of the following categories. The abstracts for all these categories would have a maximum word count of 250 words:</p>

<ol>
	<li>CONSORT Randomized Clinical Trial-Manuscripts in this category must strictly adhere to the Consolidated Standards of Reporting Trials-CONSORT- minimum guidelines for the publication of randomized clinical trials. These guidelines can be found at&nbsp;<a href="http://www.consort-statement.org/" target="_blank"><strong><em>www.consort-statement.org/</em></strong></a>. These manuscripts have a limit of 3,500 words, [including abstract, introduction, materials and methods, results, discussion and acknowledgments; excluding figure legends and references]. In addition, there is a limit of a total of 4 figures and 4 tables*.</li>
	<li>Review Article-Manuscripts in this category are either narrative articles, or systematic reviews/meta-analyses. Case report/Clinical Technique articles even when followed by extensive review of the literature will should be categorized as &ldquo;Case Report/Clinical Technique&rdquo;. These manuscripts have a limit of 3,500 words, [including abstract, introduction, discussion and acknowledgments; excluding figure legends and references]. In addition, there is a limit of a total of 4 figures and 4 tables*.</li>
	<li>Clinical Research (<em>e.g.</em>, prospective or retrospective studies on patients or patient records, or research on biopsies, excluding the use of human teeth for technique studies). These manuscripts have a limit of 3,500 words [including abstract, introduction, materials and methods, results, discussion and acknowledgments; excluding figure legends and references]. In addition, there is a limit of a total of 4 figures and 4 tables*.</li>
	<li>Basic Research Biology (animal or culture studies on biological research on physiology, development, stem cell differentiation, inflammation or pathology). Manuscripts that have a primary focus on biology should be submitted in this category while manuscripts that have a primary focus on materials should be submitted in the Basic Research Technology category. For example, a study on cytotoxicity of a material should be submitted in the Basic Research Technology category, even if it was performed in animals with histological analyses.&nbsp; These manuscripts have a limit of 2,500 words [including abstract, introduction, materials and methods, results, discussion and acknowledgments; excluding figure legends and references]. In addition, there is a limit of a total of 4 figures or 4 tables*.</li>
	<li>Basic Research Technology (Manuscripts submitted in this category focus primarily on research related to techniques and materials used, or with potential clinical use, in endodontics). These manuscripts have a limit of 2,500 words [including abstract, introduction, materials and methods, results, discussion and acknowledgments; excluding figure legends and references]. In addition, there is a limit of a total of 3 figures and tables *.</li>
	<li>Case Report/Clinical Technique (<em>e.g.</em>, report of an unusual clinical case or the use of cutting-edge technology in a clinical case). These manuscripts have a limit of 2,500 words [including abstract, introduction, materials and methods, results, discussion and acknowledgments; excluding figure legends and references]. In addition, there is a limit of a total of 4 figures or tables*.</li>
</ol>

<p class="margBot">* Figures, if submitted as multipanel figures must not exceed 1 page length. Manuscripts submitted with more than the allowed number of figures or tables will require approval of the&nbsp;<em>JOE</em>&nbsp;Editor or associate editors. If you are not sure whether your manuscript falls within one of the categories above, or would like to request preapproval for submission of additional figures please contact the Editor by email at&nbsp;<a href="mailto:jendodontics@uthscsa.edu" target="_blank"><strong><em>jendodontics@uthscsa.edu</em></strong></a>.</p>

<p class="margBot">Importantly, adhering to the general writing methods described in these guidelines (and in the resources listed below) will help to reduce the size of the manuscript while maintaining its focus and significance. Authors are encouraged to focus on only the essential aspects of the study and to avoid inclusion of extraneous text and figures. The Editor may reject manuscripts that exceed these limitations.</p>

<p class="margBot">&nbsp;<strong>Available Resources:</strong><br />
Strunk W, White EB. The Elements of Style. Allyn &amp; Bacon, 4th ed, 2000, ISBN 020530902X.&nbsp;<br />
Day R. How to Write and Publish a Scientific Paper. Oryx Press, 5th ed. 1998. ISBN 1-57356-164-9.&nbsp;<br />
Woods G. English Grammar for Dummies. Hungry Minds:NY, 2001 (an entertaining review of grammar).<br />
Alley M. The Craft of Scientific Writing. Springer, 3rd edition 1996 SBN 0-387-94766-3.&nbsp;<br />
Alley M. The Craft of Editing. Springer, 2000 SBN 0-387-98964-1.</p>

<p class="margBot">http://www.aae.org/publications-and-research/journal-of-endodontics/guidelines-for-publishing-papers-in-the-joe.aspx</p>

<p class="margBot">&nbsp;</p>

<p class="margBot"><strong>Introduction.</strong> A strong introduction engages the reader in the problem of interest and provides a context for the study at hand. In introducing the research concern, the writer should provide a clear rationale for why the problem deserves new research, placing the study in the context of current knowledge and prior theoretical and empirical work on the topic. Responsible scholarship stipulates that the writer properly credit the work of others. Whereas it is impractical to exhaustively describe all prior research, the most current and relevant studies should be cited. Swales and Feak (2004) identified four cornerstones of the introduction in a research paper, advising authors to establish current knowledge of the field;&middot;&nbsp; to summarize previous research, providing the wider context and background&middot; and the importance of the current study; to set the stage for the present research, indicating gaps in knowledge and&middot; presenting the research question; and&nbsp; to introduce present research, stating its purpose and outlining its design.&middot; Within this framework, the writer states the hypotheses of the current study and their correspondence to the research design (APA, 2010, pp. 27&ndash;28).</p>

<p class="margBot"><strong>Method</strong>. In both quantitative and qualitative research, the use of appropriate methods of participant sampling, study design, measures, and statistical analysis critically influences the study&rsquo;s methodological soundness. Calfee and Valencia (2007) suggested that good methodology can be described by the two &ldquo;Cs&rdquo;&mdash;clean and clear. 7 Manuscript Preparation Guide The soundness of the study hinges on clean methodology, that is, use of appropriate, valid, and unflawed methods of sampling and use of instruments, procedures, and analysis. In a clean study, Calfee and Valencia (2007) noted that the researcher ensures that sample variables are free of confounding influences (e.g., education is&middot; controlled for), recruitment and sampling techniques are appropriate,&middot;&nbsp; measures are reliable and valid for assessing the variables of interest, and&middot;&nbsp; the statistical procedures are appropriate and sufficiently sophisticated to&middot; examine the data and are carried out appropriately. The ideal Method section is written in a clear manner, such that another researcher could duplicate the study. Toward this end, the writer should provide a thorough description of methods of recruitment, participant characteristics, measures and apparatus, and procedures. Recruitment methods and effects of attrition should be articulated. The writer should take care to thoroughly describe the sample with regard to demographic characteristics, including notation of any characteristics that may have bearing on the results (e.g., socioeconomic status). This information assists the reader in understanding the characterization of the current sample and the degree to which results may be generalizable. Measures should be appropriately referenced, including notation of their reliability and validity, and any adaptations to their customary use should be noted. In a clear study, the author explicates the research design and plan for analysis, noting whether conditions were manipulated or naturalistic, whether groups were randomly assigned, and whether the design explored variables within or between participants (APA, 2010).</p>

<p class="margBot"><strong>Results and discussion.</strong> The Results section should include a summary of the collected data and analyses, which follows from the analytic plan. All results should be described, including unexpected findings. Authors should include both descriptive statistics and tests of significance. The Publication Manual provides information on tests of significance, including null hypothesis testing, effect sizes, confidence intervals, inferential statistics, and supplementary analyses. In the Discussion section, the writer evaluates and interprets the findings. This section should begin with a statement of support or nonsupport for the original hypotheses in light of the findings. If the hypotheses were not supported, the author considers post hoc explanations. In interpreting the results, authors consider sources of bias and other threats to internal validity, imprecision of measures, overall number of tests or overlap among tests, effect sizes, and other weaknesses of the study (APA, 2010, p. 35). Limitations and a discussion of the importance of the findings should conclude the discussion. Providing a link to future research, the author may offer recommendations for further study. More specific recommendations are more useful. As Skelton (1994) observed, researchers too often end their papers with a recommendation that is &ldquo;too imprecise to be operationalized, or too grand to be implemented by a decision at much lower than a ministerial level&rdquo; (p. 459). 8 Manuscript Preparation Guide</p>

<p class="margBot"><strong>Tables and figures</strong>. Tables and figures are particularly valuable for conveying large amounts of information and for showing relationships among data. The expanding development of advanced tools for graphic display provides authors with greater flexibility and capability for illustrating their results. Such tools can convey information in visually engaging ways that facilitate the reader&rsquo;s understanding of comparisons and evaluations of change over time. Authors should avoid duplicate reporting of data but instead should decide on the most comprehensible ways of presenting the information, whether it is through text or through tabular or graphic form. Good tables and figures should be structured according to APA Style and be clear and self-explanatory so that, with their captions, they can stand apart from the text. In addition to Chapter 5 of the Publication Manual on displaying results, the interested writer may wish to consult the APA publication, Displaying Your Findings (Nicol &amp; Pexman, 2010), as well as the article on this topic published in the American Psychologist (Smith, Best, Stubbs, Archibald, &amp; Roberson-Nay, 2002).</p>

<p class="margBot">Ethical Considerations In planning for and conducting a study, researchers should consult the &ldquo;Ethical Principles of Psychologists and Code of Conduct&rdquo; (APA, 2002) as well as the ethical guidelines of the institution where the research was conducted. The APA Ethics Code requires that researchers ensure approval by relevant institutional review boards and obtain informed consent from all participants. Fulfillment of these requirements should be noted in the Method section. Researchers should take care to exercise proper conduct in administering measures and carrying out experiments with participants. When applicable, participants should be thoroughly debriefed, and such procedures should be indicated in the manuscript. Style Style in scholarly manuscripts can refer to various aspects of the writing technique. Here, we highlight editorial style and writing style. Authors preparing a manuscript for submission will want to attend closely to APA editorial style, the mechanics of convention laid out in the Publication Manual&mdash;the decisive resource for capitalization, italics, abbreviations, heading structure, and so forth. The Publication Manual also includes guidance on avoiding bias in language, which is particularly important in demonstrating sensitivity to such concerns as participants&rsquo; mental illness and cultural background. A strong manuscript will demonstrate the author&rsquo;s command of writing style in the academic genre of a research article. Tardy and Swales (2008) characterized writing genres in the following way: Written texts are known to have culturally preferred shapes that structure their overall organization and influence their internal patterning. These shaping forces, 9 Manuscript Preparation Guide at both general and local levels, are neither incidental nor accidental; rather, they exist to provide orientations for both readers and writers. (p. 565) Learning the language of the genre will contribute to the production of a technically sound, well-written manuscript. In the case of an empirical research article, perhaps the most apparent feature is its standard structure, which follows some variation on the format of Introduction&ndash;Method&ndash;Results&ndash;Discussion. Beyond this organizational frame, however, there are a number of major and more subtle features that characterize the empirical research article. A good research article hinges on its coherence and organization. These aspects of the article are influenced by the ways in which the study evolves from the data. Whereas a typical psychology research article will follow a standard framework of ordered sections, as noted above, a coherent article is not usually written in the order of these sections but instead develops from the data analyses. As expressed by Bem (2004) in his chapter on the empirical research article, There are two possible articles you can write: (a) the article you planned to write when you designed your study or (b) the article that makes the most sense now that you have seen the results. They are rarely the same, and the correct answer is (b). (p. 186) Although the research paper should be guided outward from the hypotheses and resulting data, the paper should be guided by ideas and one&rsquo;s point of view. As stated by Sternberg (1988), &ldquo;Facts are presented in service of ideas: to help elucidate, support, or refute these ideas. They provide a test against which the validity of ideas can be measured&rdquo; (p. 4). Along these lines, an organizing principle of strong research papers is to convey central features first, followed by more peripheral or less important aspects (Bem, 2004). Whereas selectivity in presentation is important, it is crucial to present facts objectively, both those that refute and those that support one&rsquo;s position. &ldquo;Scientists demand that scientific reporting be scrupulously honest. Without such honesty, scientific communication would collapse&rdquo; (Sternberg, 1988, p. 5). Additional suggestions for writing accurate, clear, and concise research articles are provided in Chapter 3 of the Publication Manual, which discusses continuity and transitions, tone, precision, word choice, and grammatical principles. Another source of useful information is the APA Style website (www.apastyle.org)</p>                            </p>
                        </div>
                        <div class="span3">
                            <h3>Announcements <a href="announcements.php" style="font-size:12px;">View All</a></h3>
                            <div id="news-container">
                            <ul class="list4 support-box">
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=209"><time datetime="2024-10-30">October 30, 2024</time></a>
                                        <div>Science Department, College of Home Econ...</div>
                                        <div><a href="show-event.php?id=209" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=208"><time datetime="2024-10-06">October 06, 2024</time></a>
                                        <div>Ms. Sidra Ali defended her research unde...</div>
                                        <div><a href="show-event.php?id=208" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=207"><time datetime="2024-09-11">September 11, 2024</time></a>
                                        <div>The entry test for MPhil/PhD programs in...</div>
                                        <div><a href="show-event.php?id=207" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                            </ul>
                            </div>
                            <h3>Upcoming Events <a href="upcoming-events.php" style="font-size:12px;">View All</a></h3>
                            <div id="news-container2">
                            <ul class="list4 support-box">
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=202"><time datetime="2024-03-03">March 03, 2024</time></a>
                                        <div>SPRING FIESTA, TUESDAY 5TH MARCH 2024....</div>
                                        <div><a href="show-event.php?id=202" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=201"><time datetime="2024-02-21">February 21, 2024</time></a>
                                        <div>A two day book fair was organized in col...</div>
                                        <div><a href="show-event.php?id=201" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=193"><time datetime="2023-10-04">October 04, 2023</time></a>
                                        <div>Newly admitted FSc students Orientation ...</div>
                                        <div><a href="show-event.php?id=193" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                            </ul>
                            </div>
                            
                        </div>                    </div>
                 </article>
            </div>
        </section>
    </div>
</div>
</div>
<!--footer-->
<footer>
    <div class="main">
        <div class="container">
            <div class="row">
                <article class="span12">
                    <p style="margin-top:20px;">College of Home Economics &copy; 2024. <a href="privacy-policy.php" title="Learn how we use your information">Privacy Policy</a></p>
                    <p align="right"><a style="display:none;" target="_blank" title="Site designed by SuperWebz.com" href="http://www.superwebz.com"><img src="img/superwebz_logo.jpg" alt="SuperWebz.com" /></a></p>
                </article>
            </div>
            <!-- {%FOOTER_LINK} -->
        </div>  
    </div> 
</footer><script type="text/javascript" src="js/bootstrap.js"></script>
<script>
    $('.list3 li a').hover(function(){
        $(this).stop().css({color:'#fc6f22'});	
        $(this).stop().parent().siblings('em').css({'background-position':'0 bottom'});	 
            }, function(){
        $(this).stop().css({color:'#1295d4'});	
        $(this).stop().parent().siblings('em').css({'background-position':'0 top'});						 
    })
    $('#search a').hover(function(){
        $(this).stop().animate({opacity:'0.5'});	
            }, function(){
       $(this).stop().animate({opacity:'1'});						 
    })
</script>

</body>
</html>
