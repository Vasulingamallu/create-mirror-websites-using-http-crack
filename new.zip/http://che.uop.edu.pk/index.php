<!DOCTYPE html>
<html lang="en">
<head>
<title>College of Home Economics, University of Peshawar, Pakistan</title>
<meta charset="utf-8">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
<meta name="description" content="The institution equips young women with the specialized knowledge in the field of interior design, textile design, small business management, teaching, and research.">
<meta name="keywords" content="interior design, textile design, small business management, teaching, and research, computer science, college of home economics peshawar, che">
<meta name = "format-detection" content = "telephone=no" />
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<!--CSS-->
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/camera.css">
<!--JS-->
<script src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery.vticker-min.js"></script>
<script src="js/jquery-migrate-1.1.1.js"></script>
<script src="js/superfish.js"></script>
<script src="js/jquery.mobilemenu.js"></script>
<script src="js/jquery.cookie.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/camera.js"></script>
<script src="js/jquery.ui.totop.js"></script>
<script>
    $(document).ready(function(){
        jQuery('.camera_wrap').camera({
		navigation: true,
		fx: 'random',
		hover: true
		});
    });
	
	$(function(){
	$('#news-container').vTicker({ 
		speed: 500,
		pause: 5000,
		animation: 'fade',
		mousePause: true,
		showItems: 2
		});
	});
	
	$(function(){
	$('#news-container2').vTicker({ 
		speed: 500,
		pause: 5000,
		animation: 'fade',
		mousePause: true,
		showItems: 2
		});
	});
</script>
<!--[if (gt IE 9)|!(IE)]><!-->
      <script type="text/javascript" src="js/jquery.mobile.customized.min.js"></script>
<!--<![endif]-->    
<!--[if lt IE 8]>
		<div style='text-align:center'><a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/img/upgrade.jpg"border="0"alt=""/></a></div>  
<![endif]-->
<!--[if lt IE 9]>
  <link rel="stylesheet" href="css/ie.css">
  <link rel="stylesheet" href="css/docs.css">
  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body>
<div class="global">
<!--header-->
<header>
    <div class="main">
        <div class="gradient">
        <div class="container">
             <article>
                <div class="navbar navbar_ clearfix">
                    <div class="navbar-inner">      
                          <div class="clearfix">
                                <div class="nav-collapse nav-collapse_">
                                	<ul class="nav sf-menu clearfix">
                                	  <li><a href="index.php">Home</a></li>
                                      <li class="sub-menu"><a href="#">About</a>
                                        <ul>
                                            <li><a href="che-history.php">Brief History</a></li>
                                            <li><a href="leadership.php">Leadership</a></li>
                                            <li><a href="foundation-faculty.php">Foundation Faculty</a></li>
                                            <li><a href="contact-us.php">Contact Us</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Programs</a>
                                        <ul>
                                            <li><a href="art-design-introduction.php">Art & Design</a></li>
                                            <li><a href="food-nutrition-sciences-introduction.php">Food & Nutrition Sciences</a></li>
                                            <li><a href="human-development-family-studies-introduction.php">Human Development &amp; Family Studies</a></li>
                                            <li><a href="resource-facility-management-introduction.php">Resource &amp; Facility Management</a></li>
                                            <li><a href="textile-clothing-introduction.php">Textile & Clothing</a></li>
                                            <li><a href="#">Mandatory Supportive<span></span></a>
                                              <ul>
                                             <li><a href="computer-science-introduction.php">Computer Science</a></li>
                                              <li><a href="english-introduction.php">English</a></li>
                                              <li><a href="pak-studies-introduction.php">Pak. Studies</a></li>

                                              <li><a href="science-introduction.php">Science Department</a></li>
                                              <li><a href="urdu-islamiyat-introduction.php">Urdu / Islamiyat</a></li>
                                              </ul>
                                            </li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Admissions</a>
                                        <ul>
                                          <li><a href="bsc.php">BS Public Health<span></span></a>
                                        	<ul>
                                              <li><a href="bsc-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="bsc-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="bsc-uniform.php">Uniform</a></li>
                                              <li><a href="bsc-merit-list.php">Merit List</a></li>
                                              <li><a href="bsc-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="fsc.php">F.A/ F.Sc.<span></span></a>
                                        	<ul>
                                              <li><a href="fsc-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="fsc-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="fsc-uniform.php">Uniform</a></li>
                                              <li><a href="fsc-merit-list.php">Merit List</a></li>
                                              <li><a href="fsc-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="bs-hons.php">B.S Home Economics<span></span></a>
                                        	<ul>
                                              <li><a href="bs-hons-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="bs-hons-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="bs-hons-uniform.php">Uniform</a></li>
                                              <li><a href="bs-hons-merit-list.php">Merit List</a></li>
                                              <li><a href="bs-hons-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="msc.php">BS Human Nutrition & Dietetics<span></span></a>
                                        	<ul>
                                              <li><a href="msc-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="msc-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="msc-uniform.php">Uniform</a></li>
                                              <li><a href="msc-merit-list.php">Merit List</a></li>
                                              <li><a href="msc-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="mphil.php">M.Phil<span></span></a>
                                        	<ul>
                                              <li><a href="mphil-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="mphil-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="mphil-uniform.php">Uniform</a></li>
                                              <li><a href="mphil-merit-list.php">Merit List</a></li>
                                              <li><a href="mphil-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="phd.php">Ph.D<span></span></a>
                                        	<ul>
                                              <li><a href="phd-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="phd-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="phd-uniform.php">Uniform</a></li>
                                              <li><a href="phd-merit-list.php">Merit List</a></li>
                                              <li><a href="phd-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Examination</a>
                                        <ul>
                                          <li><a href="examination-rules.php">Rules</a></li>
                                          <li><a href="datesheet.php">Date Sheet</a></li>
                                          <li><a href="results.php">Results</a></li>
                                          <li><a href="convocation.php">Convocation</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="college-faculty.php">Faculty</a>
                                        <ul>
                                          <li><a href="faculty-art-and-design.php">Art & Design</a></li>
                                          <li><a href="faculty-food-and-nutrition-sciences.php">Food & Nutrition Sciences</a></li>
                                          <li><a href="faculty-human-development-and-family-studies.php">Human Development and Family Studies</a></li>
                                          <li><a href="faculty-resource-and-facility-management.php">Resource and Facility Management</a></li>
                                          <li><a href="faculty-textile-and-clothing.php">Textile & Clothing</a></li>
                                          <li><a href="faculty-science.php">Science</a></li>
                                          <li><a href="faculty-computer-studies.php">Computer Studies</a></li>
                                          <li><a href="faculty-english.php">English</a></li>
                                          <li><a href="faculty-pak-studies.php">Pak. Studies</a></li>
                                          <li><a href="faculty-urdu.php">Urdu</a></li>
                                          <li><a href="faculty-islamiyat.php">Islamiyat</a></li>
                                          <li><a href="faculty-login.php">Faculty Login</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Student's Life</a>
                                        <ul>
                                          <li><a href="students-societies.php">Student Societies</a></li>
                                          <li><a href="students-society-members.php">Society Members</a></li>
                                          <li><a href="students-academic-visits.php">Academic Visits</a></li>
                                          <li><a href="students-recreational-trips.php">Recreational Trips</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Facilities</a>
                                        <ul>
                                  <li><a href="facilities-bookshop.php">Bookshop</a></li>                                          <li><a href="facilities-canteen.php">Canteen</a></li>

                                          <li><a href="facilities-daycare.php">Day Care</a></li>                                          <li><a href="facilities-first-aid-room.php">First Aid Room</a></li>

                                          <li><a href="facilities-generators.php">Generators</a></li>
                                                                                                                   <li><a href="facilities-home-management-residence.php">Home Management Residence</a></li>
        <li><a href="facilities-hostel.php">Hostel</a></li>
   <li><a href="facilities-internet.php">Internet</a></li>

                                          <li><a href="facilities-library.php">Library</a></li>
                                                                              <li><a href="facilities-mosque.php">Mosque</a></li>
                                          <li><a href="facilities-nursery.php">Nursery</a></li>
                                        <li><a href="facilities-photocopier.php">Photocopier</a></li>

                                          <li><a href="facilities-playgroup.php">Play Group</a></li>
                                            <li><a href="facilities-preplaygroup.php">Pre Play Group</a></li>      
                                          <li><a href="facilities-transport.php">Transport</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="alumni-list.php">PFHE</a>
                                        <ul>
                                          <li><a href="pfhe.php">Introduction</a></li>
                                          <li><a href="alumni-profile.php">Members Profile</a></li>
                                          <li><a href="alumni-list.php">Federation & Alumni Members</a></li>
                                        </ul>
  </li>
                                      <li class="sub-menu"><a href="#">JHEBS</a>
                                        <ul><li><a href="jhebs-call-for-papers.php">Call for Papers</a></li>
                                          <li><a href="jhebs-published-versions.php">Published Versions</a></li>
                                          <li><a href="jhebs-research.php">Research</a></li>
                                          <li><a href="jhebs-rules.php">Rules</a></li>
                                                                                    <li><a href="jhebs-updates.php">Updates</a></li>

                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Conference</a>
                                        <ul>
                                          <li><a href="conference-call-for-papers.php">Call For Papers</a></li>
										  <li><a href="conference-accepted-papers.php">Accepted Papers</a></li>
										  <li><a href="conference-registration-and-payment.php">Registration and Payment</a></li>
										  <li><a href="conference-important-dates.php">Important Dates</a></li>
										  <li><a href="conference-keynote-speaker.php">Keynote Speaker</a></li>
										  <li><a href="conference-committee.php">Committee</a></li>
										  <li><a href="conference-abstract-submission.php">Abstract Submission</a></li>
										  <li><a href="conference-topics.php">Conference Topics</a></li>
										  <li><a href="conference-presentation-instructions.php">Presentation Instructions</a></li>
										  <li><a href="conference-who-should-attend.php">Who should Attend</a></li>
										  <li><a href="conference-tentative-programme.php">Tentative Programme</a></li>
										  <li><a href="conference-venue.php">Venue</a></li>
										  <li><a href="conference-final-paper-submission.php">Final Paper Submission</a></li>
										  <li><a href="conference-paper-templates.php">Paper Templates</a></li>
										  <li><a href="conference-accommodation-and-travel.php">Accommodation & Travel</a></li>
										  <li><a href="conference-conference-poster.php">Conference Poster</a></li>
										  <li><a href="contact-us.php">Contact Us</a></li>
                                        </ul>
                                      </li>
									  <li class="sub-menu"><a href="#">Activities</a>
                                        <ul>                                          <li><a href="college-magazine.php">College Magazine</a></li>
                                          <li><a href="activities-exhibitions.php">Exhibitions</a></li>
                                          <li><a href="activities-internships.php">Internships</a></li>
                                          <li><a href="activities-lectures.php">Lectures</a></li>
                                          <li><a href="newsletter.php">Newsletter</a></li>                                          <li><a href="activities-seminars.php">Seminars</a></li>

                                          <li><a href="activities-sports.php">Sports</a></li>
                                                                                 <li><a href="activities-tutorials.php">Tutorials</a></li>
   <li><a href="activities-workshops.php">Workshops</a></li>
                                        </ul>
                                      </li>
                                    </ul>
                                 </div>
                                 <ul class="follow_icon">
                                    <li><a href="https://www.facebook.com/CHEUOP/"><img src="img/follow_icon2.png" alt=""></a></li>                                                                    </ul>                          </div>
                    </div>
                </div>
                <h1 class="brand"><a href="index.php"><img src="img/logo.png" alt=""></a></h1>
                <form id="search" class="search" action="search-results.php" method="GET" accept-charset="utf-8">
                	 <input type="text" onFocus="if(this.value =='Search for...' ) this.value=''" onBlur="if(this.value=='') this.value='Search for...'" value="Search for..." name="q">
                     <a href="#" onClick="document.getElementById('search').submit()"><img src="img/magnify.png" alt=""></a>
                </form>             </article>
        </div>
        </div>
    </div>
</header>
<div class="main">
<section class="container padTop">
    <div class="row">
        <article class="span9 slider pull-right">
            <div class="camera_wrap">
             			<div data-src="img/slider/FB_IMG_1709975501394_1.jpg" ><div class="camera-caption">Spring Food Fiesta was organised by the Department of Food and Nutrition Sciences,  College of Home Economics UOP under the gracious supervision of Prof. Dr. Shazia Shah</div></div>
                                			<div data-src="img/slider/FB_IMG_1715919303460_1.jpg" ><div class="camera-caption">Respected Prof. Dr. Shazia Shah, graced the inaugural ceremony of Literary Week at Rehman Medical College , Peshawar, as a Judge for remarkable paintings, Sketches, Calligraphic and  representation of quranic verses.</div></div>
                                			<div data-src="img/slider/FB_IMG_1709466639153_1.jpg" data-link="Facebook"><div class="camera-caption">College of Home Economics feels elated to annnounce that the Principal, Prof. Dr. Shazia Shah, has been awarded Women Recognition Excellence Award(Arts and Culture) on 1st March, 2024</div></div>
                                			<div data-src="img/slider/FB_IMG_1715400515184_1.jpg" ><div class="camera-caption">Prof. Dr. Shazia Shah attended leadership training workshop (6~9 May 2024 ) organised by International Islamic University, Islamabad (IIUI) in collaboration with Fatima Jinnah  Women University, Rawalpini (Funded by HEC)</div></div>
                                			<div data-src="img/slider/Screenshot_20240529-101152.png" ><div class="camera-caption">A fashion show was organized by the students of Department of Textiles and Clothing on 21 May 2024 under the supervision of Prof. Dr. Shazia Shah,Dr. Shabana Sajjad and Miss Faryal.</div></div>
                                			<div data-src="img/slider/Screenshot_20240529-102351.png" ><div class="camera-caption">Opening Ceremony and Five-Day Workshop on "Culinary Art Skills " arranged by Department  of Food and Nutrition Sciences,  under the supervision of Prof. Dr. Shazia Shah, Principal CHE and Dr. Zahin Anjum.</div></div>
                                			<div data-src="img/slider/FB_IMG_1728644914227_1.jpg" data-link="Facebook"><div class="camera-caption">University of Peshawar Partners with USAID/HESSA for Enhanced Student Support</div></div>
                                			<div data-src="img/slider/FB_IMG_1728644923996_1.jpg" data-link="Facebook"><div class="camera-caption">BS PROGRAM</div></div>
                                			<div data-src="img/slider/FB_IMG_1729092745230.jpg" data-link="Facebook"><div class="camera-caption">.</div></div>
                                			<div data-src="img/slider/FB_IMG_1709051546765_1.jpg" data-link="Facebook"><div class="camera-caption">First Home Economics (Art and Design) Thesis display,A studio research</div></div>
                                			<div data-src="img/slider/FB_IMG_1709366696547_2.jpg" ><div class="camera-caption">A seminar addressing "Oral Cancer" was organized by the Department of Human Development and Family Studies (HDFS) under the guidance of Prof. Dr. Shazia Ghulam Mohammad, Principal CHE</div></div>
                                			<div data-src="img/slider/FB_IMG_1713499701324_1.jpg" ><div class="camera-caption">Department of Public Health and BS 6 semester attended International Public Health Conference 16th-18th April, 2024 organized by Khyber Medical University with Principal, Prof. Dr. Shazia Shah</div></div>
                                			<div data-src="img/slider/FB_IMG_1709090281016_1.jpg" data-link="Facebook"><div class="camera-caption">Installation Ceremony  2024</div></div>
                                			<div data-src="img/slider/FB_IMG_1708933663017_1.jpg" ><div class="camera-caption">One day educational trip to NIFA (Nuclear Institute for Food and Agriculture)  arranged by Dr. Amina Rahat, Department of Food & Nutrition Sciences.</div></div>
                                			<div data-src="img/slider/FB_IMG_1708777997727_1.jpg" ><div class="camera-caption">The distinguished speaker, Miss Tabbasum Yunus Katozai focused on the significant role of women in parliament.</div></div>
                                			<div data-src="img/slider/FB_IMG_1708778015560_2.jpg" ><div class="camera-caption">Department of Human Development and Family Studies organized an enlightening seminar on the "Art of Communication.</div></div>
                                			<div data-src="img/slider/FB_IMG_1708670829140.jpg" ><div class="camera-caption">seminar organised on Thursday, 22 February 2024 for BS Students in collaboration with Cyntax Health projects Pvt  Ltd under the supervision of Professor Dr. Shazia Shah</div></div>
                                			<div data-src="img/slider/FB_IMG_1708510112013.jpg" data-link="Facebook"><div class="camera-caption">A two day book fair was organized in collaboration with Readers book fair on 19th and 20th of February at college of Home Economics.</div></div>
                                			<div data-src="img/slider/img_1707894538590_1.jpg" data-link="Facebook"><div class="camera-caption">Green Campus Reuse Able Revolutional Seminar</div></div>
                                			<div data-src="img/slider/img_1707894473775.jpg" ><div class="camera-caption">Principal Prof Dr. Shazia Shah addressed the students on the importance of discipline</div></div>
                                            </div>
         </article>
         <article class="span3 list1-box pull-left">
            <ul class="list1">
                <li><a href="college-faculty.php">College Faculty</a></li>
                <li><a href="proctorial-board.php">Proctorial Board</a></li>
                <li><a href="annual-report.php">Annual Report</a></li>
                <li><a href="newsletter.php">Newsletter</a></li>
                <li><a href="scheme-of-studies.php">Scheme of Studies</a></li>
                <li><a href="syllabi.php">Syllabi</a></li>
                <li><a href="college-calendar.php">College Calendar</a></li>
                <li><a href="merit-list.php">Merit / Waiting List</a></li>
                <li><a href="results.php">Results</a></li>
            </ul>
         </article>
     </div>
 </section>
</div>
<div class="main">
    <div class="gradient">
        <section class="container">
            <div class="row">
                <article class="span12">
                    <div class="row">
                        <ul class="list2">
                            <li class="span4">
                                <div class="title"><img src="img/page1_icon3.png" alt="">
                                <p>VC Message</p>
                                </div>
                                
                                <p class="marg1"><img src="img/site/naeem-pro-vc.jpeg" align="left" alt="" style="width:100px;height:125px;margin-right:10px;" /><p>Students play the role of backbone of every nation. They determine the future of every society. I personally am a staunch believer that it is only the education which determines the progress of an individual and a nation.</p><br /></p>
                                <a href="vc-message.php" class="btn btn-primary"><span>Read more</span><img src="img/more_arrow.png" alt=""></a>
                            </li>
                            <li class="span4">
                                <div class="title"><img src="img/page1_icon3.png" alt=""><p>Dean Message</p></div>

                                <p class="marg1"><img src="img/site/Dr.Sajjad ESSEX.jpg" align="left" alt="" style="width:100px;height:125px;margin-right:10px;" /><p>The College of Home Economics is a unique institution of the University of Peshawar. The purpose of its establishment was to provide education with specific skills to female students in an environment conducive to the culture and traditions of Khyber Pakhtunkhwa. Over the period of time the College has expanded in terms of its purpose and scope of its academic programmes. The college is now providing education in five specialized disciplines and preparing its graduates to serve the nation in diverse areas. 
The College has well-equipped laboratories and has qualified and devoted faculty members. Student's talent of entrepreneurship is promoted by whetting their creativity. Following in the footsteps of the other postgraduate institutions of University of Peshawar, the College of Home Economics has moved toward knowledge based learning by encouraging the process of research among its students and faculty members. The effort of the Principal, Professor Dr. Shehnaz Khattak, is highly commendable and I have no doubt that the College will reach the pinnacle of glory under her able leadership with the support of motivated students and staff members.

</p><br /></p>
                                <a href="dean-message.php" class="btn btn-primary"><span>Read more</span><img src="img/more_arrow.png" alt=""></a>
                            </li>
                            <li class="span4">
                                <div class="title"><img src="img/page1_icon3.png" alt=""><p>Principal Message</p></div>

                                <p class="marg1"><img src="img/site/0_IMG-20240204-WA0044.jpg" align="left" alt="" style="width:100px;height:125px;margin-right:10px;" /><p>College of Home Economics is a unique and prestigious institution which offers a vista of diverse avenues for young entrepreneur. It is a privilege to serve this institution which not only produces accomplished daughters, mothers and wives but enables them to combat market place competition by excelling in their specific fields. My vision encompasses crossroads of unexplored opportunities for sprouting talent and my mission is to empower women in various roles. This institution provides a platform for exhibiting their latent potential and we strive to polish those skills which will yield a promising outcome. College of Home Economics equips the students to face the challenges of professional life by refining those skills.  Moreover, my preoccupation has always been to create a conductive environment for research and inquiry. Encouraging inquisitive mindset among students is indeed vital for unprecedented discoveries. Having a highly qualified faculty at College of Home Economics is a significant asset.  The faculty strives to transform emerging talent into versatile entrepreneur by expanding the horizon of knowledge by pushing back the boundaries from home to market place. Transitioning from being home maker to achieving professional excellence involves identifying the inherent potential and pursuing relevant education. Keeping in view the currency of interdisciplinary subjects, the curriculum has been devised and revised to meet the emerging need of Home Economics education in the market place. I hope to see this institution at the zenith of renowned glory in years ahead. </p><br /></p>
                                <a href="principal-message.php" class="btn btn-primary"><span>Read more</span><img src="img/more_arrow.png" alt=""></a>
                            </li>
                        </ul>
                    </div>
             </article>
            </div>
        </section>
    </div>
</div>
<div class="main">
    <div class="gradient1">
        <section class="container">
            <div class="row">
                <article class="span12 margBot6">
                    <div class="row">
                        <div class="span3 support-box">
                            <h3>Quick Links</h3>
                            <ul class="list3">
                                                                <li><em></em><p><a href="https://www.facebook.com/CHEUOP/">FaceBook Page (updated)</a></p></li>                                                                <li><em></em><p><a href="convocation.php">Convocation</a></p></li>                                                                <li><em></em><p><a href="data.php?id=5">Co-Curricurlar Activites</a></p></li>                                                                <li><em></em><p><a href="data.php?id=6">BS Course Material</a></p></li>                                                                <li><em></em><p><a href="data.php?id=7">BS Course</a></p></li>                                                                <li><em></em><p><a href="data.php?id=8">M.Phil and Ph.D Course Material</a></p></li>                                                                                            </ul>
                        </div>
                        <div class="span6 support-box">
                            <h3>Welcome to CHE</h3>
                            <p class="margBot">The study of Home Economics as a distinct discipline was introduced in the country soon after the emergence of Pakistan.</p>

<p class="margBot">Initially, a separate department, devoted to the subject, was set-up in 1954 by the University of Peshawar, in collaboration with Colorado State University, USA. The department was later upgraded to College status in 1963. It is one of the four colleges in Pakistan devoted to the study of Home Economics, for developing a complete education programme for female students to meet the challenges of a free society. The institution equips young women with the specialized knowledge in the field of interior design, textile design, small business management, teaching, and research.</p>

<p class="margBot">This field of study extends opportunities for pursuing careers in any of the above professions. Therefore, it has acquired a special significance in moulding the female generation, providing them with an opportunity to study a unique blend of both science and art related subjects. It also opens up future avenues for personal, professional and social enhancement...</p<br />
                            </p>
                            <a href="che-history.php" class="btn btn-primary"><span>Read more</span><img src="img/more_arrow.png" alt=""></a>
                        </div>
                        <div class="span3">
                            <h3>Announcements <a href="announcements.php" style="font-size:12px;">View All</a></h3>
                            <div id="news-container">
                            <ul class="list4 support-box">
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=209"><time datetime="2024-10-30">October 30, 2024</time></a>
                                        <div>Science Department, College of Home Econ...</div>
                                        <div><a href="show-event.php?id=209" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=208"><time datetime="2024-10-06">October 06, 2024</time></a>
                                        <div>Ms. Sidra Ali defended her research unde...</div>
                                        <div><a href="show-event.php?id=208" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=207"><time datetime="2024-09-11">September 11, 2024</time></a>
                                        <div>The entry test for MPhil/PhD programs in...</div>
                                        <div><a href="show-event.php?id=207" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                            </ul>
                            </div>
                            <h3>Upcoming Events <a href="upcoming-events.php" style="font-size:12px;">View All</a></h3>
                            <div id="news-container2">
                            <ul class="list4 support-box">
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=202"><time datetime="2024-03-03">March 03, 2024</time></a>
                                        <div>SPRING FIESTA, TUESDAY 5TH MARCH 2024....</div>
                                        <div><a href="show-event.php?id=202" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=201"><time datetime="2024-02-21">February 21, 2024</time></a>
                                        <div>A two day book fair was organized in col...</div>
                                        <div><a href="show-event.php?id=201" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=193"><time datetime="2023-10-04">October 04, 2023</time></a>
                                        <div>Newly admitted FSc students Orientation ...</div>
                                        <div><a href="show-event.php?id=193" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                            </ul>
                            </div>
                            
                        </div>                    </div>
                 </article>
            </div>
        </section>
    </div>
</div>
</div>
<!--footer-->
<footer>
    <div class="main">
        <div class="container">
            <div class="row">
                <article class="span12">
                    <p style="margin-top:20px;">College of Home Economics &copy; 2024. <a href="privacy-policy.php" title="Learn how we use your information">Privacy Policy</a></p>
                    <p align="right"><a style="display:none;" target="_blank" title="Site designed by SuperWebz.com" href="http://www.superwebz.com"><img src="img/superwebz_logo.jpg" alt="SuperWebz.com" /></a></p>
                </article>
            </div>
            <!-- {%FOOTER_LINK} -->
        </div>  
    </div> 
</footer><script type="text/javascript" src="js/bootstrap.js"></script>
<script>
    $('.list3 li a').hover(function(){
        $(this).stop().css({color:'#fc6f22'});	
        $(this).stop().parent().siblings('em').css({'background-position':'0 bottom'});	 
            }, function(){
        $(this).stop().css({color:'#1295d4'});	
        $(this).stop().parent().siblings('em').css({'background-position':'0 top'});						 
    })
    $('#search a').hover(function(){
        $(this).stop().animate({opacity:'0.5'});	
            }, function(){
       $(this).stop().animate({opacity:'1'});						 
    })
</script>

</body>
</html>
