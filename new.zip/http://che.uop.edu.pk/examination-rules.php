<!DOCTYPE html>
<html lang="en">
<head>
<title>Examination Rules - College of Home Economics, University of Peshawar</title>
<meta charset="utf-8">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
<meta name = "format-detection" content = "telephone=no" />
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<!--CSS-->
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/camera.css">
<!--JS-->
<script src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery.vticker-min.js"></script>
<script src="js/jquery-migrate-1.1.1.js"></script>
<script src="js/superfish.js"></script>
<script src="js/jquery.mobilemenu.js"></script>
<script src="js/jquery.cookie.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.ui.totop.js"></script>
<script>	
	$(function(){
	$('#news-container').vTicker({ 
		speed: 500,
		pause: 5000,
		animation: 'fade',
		mousePause: true,
		showItems: 3
		});
	});
	
	$(function(){
	$('#news-container2').vTicker({ 
		speed: 500,
		pause: 5000,
		animation: 'fade',
		mousePause: true,
		showItems: 2
		});
	});
</script>
<!--[if (gt IE 9)|!(IE)]><!-->
      <script type="text/javascript" src="js/jquery.mobile.customized.min.js"></script>
<!--<![endif]-->    
<!--[if lt IE 8]>
		<div style='text-align:center'><a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/img/upgrade.jpg"border="0"alt=""/></a></div>  
<![endif]-->
<!--[if lt IE 9]>
  <link rel="stylesheet" href="css/ie.css">
  <link rel="stylesheet" href="css/docs.css">
  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body>
<div class="global">
<!--header-->
<header>
    <div class="main">
        <div class="gradient">
        <div class="container">
             <article>
                <div class="navbar navbar_ clearfix">
                    <div class="navbar-inner">      
                          <div class="clearfix">
                                <div class="nav-collapse nav-collapse_">
                                	<ul class="nav sf-menu clearfix">
                                	  <li><a href="index.php">Home</a></li>
                                      <li class="sub-menu"><a href="#">About</a>
                                        <ul>
                                            <li><a href="che-history.php">Brief History</a></li>
                                            <li><a href="leadership.php">Leadership</a></li>
                                            <li><a href="foundation-faculty.php">Foundation Faculty</a></li>
                                            <li><a href="contact-us.php">Contact Us</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Programs</a>
                                        <ul>
                                            <li><a href="art-design-introduction.php">Art & Design</a></li>
                                            <li><a href="food-nutrition-sciences-introduction.php">Food & Nutrition Sciences</a></li>
                                            <li><a href="human-development-family-studies-introduction.php">Human Development &amp; Family Studies</a></li>
                                            <li><a href="resource-facility-management-introduction.php">Resource &amp; Facility Management</a></li>
                                            <li><a href="textile-clothing-introduction.php">Textile & Clothing</a></li>
                                            <li><a href="#">Mandatory Supportive<span></span></a>
                                              <ul>
                                             <li><a href="computer-science-introduction.php">Computer Science</a></li>
                                              <li><a href="english-introduction.php">English</a></li>
                                              <li><a href="pak-studies-introduction.php">Pak. Studies</a></li>

                                              <li><a href="science-introduction.php">Science Department</a></li>
                                              <li><a href="urdu-islamiyat-introduction.php">Urdu / Islamiyat</a></li>
                                              </ul>
                                            </li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Admissions</a>
                                        <ul>
                                          <li><a href="bsc.php">BS Public Health<span></span></a>
                                        	<ul>
                                              <li><a href="bsc-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="bsc-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="bsc-uniform.php">Uniform</a></li>
                                              <li><a href="bsc-merit-list.php">Merit List</a></li>
                                              <li><a href="bsc-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="fsc.php">F.A/ F.Sc.<span></span></a>
                                        	<ul>
                                              <li><a href="fsc-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="fsc-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="fsc-uniform.php">Uniform</a></li>
                                              <li><a href="fsc-merit-list.php">Merit List</a></li>
                                              <li><a href="fsc-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="bs-hons.php">B.S Home Economics<span></span></a>
                                        	<ul>
                                              <li><a href="bs-hons-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="bs-hons-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="bs-hons-uniform.php">Uniform</a></li>
                                              <li><a href="bs-hons-merit-list.php">Merit List</a></li>
                                              <li><a href="bs-hons-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="msc.php">BS Human Nutrition & Dietetics<span></span></a>
                                        	<ul>
                                              <li><a href="msc-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="msc-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="msc-uniform.php">Uniform</a></li>
                                              <li><a href="msc-merit-list.php">Merit List</a></li>
                                              <li><a href="msc-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="mphil.php">M.Phil<span></span></a>
                                        	<ul>
                                              <li><a href="mphil-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="mphil-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="mphil-uniform.php">Uniform</a></li>
                                              <li><a href="mphil-merit-list.php">Merit List</a></li>
                                              <li><a href="mphil-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="phd.php">Ph.D<span></span></a>
                                        	<ul>
                                              <li><a href="phd-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="phd-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="phd-uniform.php">Uniform</a></li>
                                              <li><a href="phd-merit-list.php">Merit List</a></li>
                                              <li><a href="phd-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Examination</a>
                                        <ul>
                                          <li><a href="examination-rules.php">Rules</a></li>
                                          <li><a href="datesheet.php">Date Sheet</a></li>
                                          <li><a href="results.php">Results</a></li>
                                          <li><a href="convocation.php">Convocation</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="college-faculty.php">Faculty</a>
                                        <ul>
                                          <li><a href="faculty-art-and-design.php">Art & Design</a></li>
                                          <li><a href="faculty-food-and-nutrition-sciences.php">Food & Nutrition Sciences</a></li>
                                          <li><a href="faculty-human-development-and-family-studies.php">Human Development and Family Studies</a></li>
                                          <li><a href="faculty-resource-and-facility-management.php">Resource and Facility Management</a></li>
                                          <li><a href="faculty-textile-and-clothing.php">Textile & Clothing</a></li>
                                          <li><a href="faculty-science.php">Science</a></li>
                                          <li><a href="faculty-computer-studies.php">Computer Studies</a></li>
                                          <li><a href="faculty-english.php">English</a></li>
                                          <li><a href="faculty-pak-studies.php">Pak. Studies</a></li>
                                          <li><a href="faculty-urdu.php">Urdu</a></li>
                                          <li><a href="faculty-islamiyat.php">Islamiyat</a></li>
                                          <li><a href="faculty-login.php">Faculty Login</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Student's Life</a>
                                        <ul>
                                          <li><a href="students-societies.php">Student Societies</a></li>
                                          <li><a href="students-society-members.php">Society Members</a></li>
                                          <li><a href="students-academic-visits.php">Academic Visits</a></li>
                                          <li><a href="students-recreational-trips.php">Recreational Trips</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Facilities</a>
                                        <ul>
                                  <li><a href="facilities-bookshop.php">Bookshop</a></li>                                          <li><a href="facilities-canteen.php">Canteen</a></li>

                                          <li><a href="facilities-daycare.php">Day Care</a></li>                                          <li><a href="facilities-first-aid-room.php">First Aid Room</a></li>

                                          <li><a href="facilities-generators.php">Generators</a></li>
                                                                                                                   <li><a href="facilities-home-management-residence.php">Home Management Residence</a></li>
        <li><a href="facilities-hostel.php">Hostel</a></li>
   <li><a href="facilities-internet.php">Internet</a></li>

                                          <li><a href="facilities-library.php">Library</a></li>
                                                                              <li><a href="facilities-mosque.php">Mosque</a></li>
                                          <li><a href="facilities-nursery.php">Nursery</a></li>
                                        <li><a href="facilities-photocopier.php">Photocopier</a></li>

                                          <li><a href="facilities-playgroup.php">Play Group</a></li>
                                            <li><a href="facilities-preplaygroup.php">Pre Play Group</a></li>      
                                          <li><a href="facilities-transport.php">Transport</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="alumni-list.php">PFHE</a>
                                        <ul>
                                          <li><a href="pfhe.php">Introduction</a></li>
                                          <li><a href="alumni-profile.php">Members Profile</a></li>
                                          <li><a href="alumni-list.php">Federation & Alumni Members</a></li>
                                        </ul>
  </li>
                                      <li class="sub-menu"><a href="#">JHEBS</a>
                                        <ul><li><a href="jhebs-call-for-papers.php">Call for Papers</a></li>
                                          <li><a href="jhebs-published-versions.php">Published Versions</a></li>
                                          <li><a href="jhebs-research.php">Research</a></li>
                                          <li><a href="jhebs-rules.php">Rules</a></li>
                                                                                    <li><a href="jhebs-updates.php">Updates</a></li>

                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Conference</a>
                                        <ul>
                                          <li><a href="conference-call-for-papers.php">Call For Papers</a></li>
										  <li><a href="conference-accepted-papers.php">Accepted Papers</a></li>
										  <li><a href="conference-registration-and-payment.php">Registration and Payment</a></li>
										  <li><a href="conference-important-dates.php">Important Dates</a></li>
										  <li><a href="conference-keynote-speaker.php">Keynote Speaker</a></li>
										  <li><a href="conference-committee.php">Committee</a></li>
										  <li><a href="conference-abstract-submission.php">Abstract Submission</a></li>
										  <li><a href="conference-topics.php">Conference Topics</a></li>
										  <li><a href="conference-presentation-instructions.php">Presentation Instructions</a></li>
										  <li><a href="conference-who-should-attend.php">Who should Attend</a></li>
										  <li><a href="conference-tentative-programme.php">Tentative Programme</a></li>
										  <li><a href="conference-venue.php">Venue</a></li>
										  <li><a href="conference-final-paper-submission.php">Final Paper Submission</a></li>
										  <li><a href="conference-paper-templates.php">Paper Templates</a></li>
										  <li><a href="conference-accommodation-and-travel.php">Accommodation & Travel</a></li>
										  <li><a href="conference-conference-poster.php">Conference Poster</a></li>
										  <li><a href="contact-us.php">Contact Us</a></li>
                                        </ul>
                                      </li>
									  <li class="sub-menu"><a href="#">Activities</a>
                                        <ul>                                          <li><a href="college-magazine.php">College Magazine</a></li>
                                          <li><a href="activities-exhibitions.php">Exhibitions</a></li>
                                          <li><a href="activities-internships.php">Internships</a></li>
                                          <li><a href="activities-lectures.php">Lectures</a></li>
                                          <li><a href="newsletter.php">Newsletter</a></li>                                          <li><a href="activities-seminars.php">Seminars</a></li>

                                          <li><a href="activities-sports.php">Sports</a></li>
                                                                                 <li><a href="activities-tutorials.php">Tutorials</a></li>
   <li><a href="activities-workshops.php">Workshops</a></li>
                                        </ul>
                                      </li>
                                    </ul>
                                 </div>
                                 <ul class="follow_icon">
                                    <li><a href="https://www.facebook.com/CHEUOP/"><img src="img/follow_icon2.png" alt=""></a></li>                                                                    </ul>                          </div>
                    </div>
                </div>
                <h1 class="brand"><a href="index.php"><img src="img/logo.png" alt=""></a></h1>
                <form id="search" class="search" action="search-results.php" method="GET" accept-charset="utf-8">
                	 <input type="text" onFocus="if(this.value =='Search for...' ) this.value=''" onBlur="if(this.value=='') this.value='Search for...'" value="Search for..." name="q">
                     <a href="#" onClick="document.getElementById('search').submit()"><img src="img/magnify.png" alt=""></a>
                </form>             </article>
        </div>
        </div>
    </div>
</header>

<div class="main">
    <div class="gradient1">
        <section class="container">
            <div class="row">
                <article class="span12 margBot6">
                    <div class="row">
                        <div class="span3 support-box">
                            <h3>Examination</h3>
                            <ul class="list3">
                                <li><em></em><p><a href="examination-rules.php">Rules</a></p></li>
                                <li><em></em><p><a href="datesheet.php">Date Sheet</a></p></li>
                                <li><em></em><p><a href="results.php">Results</a></p></li>
                                <li><em></em><p><a href="convocation.php">Convocation</a></p></li>

                            </ul>
                        </div>
                        <div class="span6 support-box">
                            <h3>Examination Rules</h3>
                                                        <p class="margBot"><a target="_blank" href="img/pages/DSCN2793-Optimized.JPG"><img src="img/pages/DSCN2793-Optimized.JPG" alt="" align="right" style="width:200px;margin-left:10px;" border="0" /></a><p class="margBot"><strong>EXAMINATIONS</strong></p>

<p class="margBot"><strong>B.S&nbsp;Home Economics</strong></p>

<p class="margBot"><strong>BS Human Nutrition &amp; Dietetics</strong></p>

<p class="margBot"><strong>BS Public Health</strong></p>

<p class="margBot"><strong>Short Title,</strong></p>

<p class="margBot"><strong>Commencement and Application:</strong></p>

<p class="margBot">i. These regulations shall be called the &ldquo;University of Peshawar Semester Regulations 2010&rdquo;.</p>

<p class="margBot">ii. These regulations shall come into force with effect from academic session 2010-2011.</p>

<p class="margBot">iii. These regulations shall be applicable to all the degree programs offered by the University of Peshawar or its constituent or affiliated institutions under semester system.</p>

<p class="margBot">2. <strong>Definitions:</strong> In these regulations, unless the context otherwise requires, the following ex<x>pressions shall have the meanings hereby respectively assigned to them:</p>

<p class="margBot">i. &ldquo;Head&rdquo; means Chairperson of a Department, or Principal of a College, or Director of an Institute/Academy/Centre.</p>

<p class="margBot">ii. &ldquo;Institution&rdquo; means a constituent or affiliated department / college / institute / centre / academy of the university.</p>

<p class="margBot">iii. &ldquo;Dean&rdquo; means Dean of a Faculty of University of Peshawar.</p>

<p class="margBot">iv. &ldquo;Departmental Coordinator of Semester System&rdquo; means a faculty member of the department/college/institute/centre/academy who has been assigned the duty of coordinating semester system in a department by the Head of respective department.</p>

<p class="margBot">v. &ldquo;Departmental Semester Committee&rdquo; means a committee constituted under these regulations.</p>

<p class="margBot">3. <strong>Duration of Semester:</strong></p>

<p class="margBot">i. Each semester shall be of 18 weeks duration; out of which 16 weeks shall be reserved for teaching, and 2 weeks for examinations.</p>

<p class="margBot">ii. A &lsquo;Summer Semester&rsquo; shall be of 10 weeks duration, i.e. 8 weeks for teaching, and 2 weeks for examination. However, the contact hours during the Summer Semester will be enhanced to ensure that the course is completely taught / covered.</p>

<p class="margBot">iii. There shall be a &lsquo;teaching break&rsquo;, to be called &lsquo;Semester Break&rsquo;, of 2 weeks after every semester; this break will be used for preparation/submission of results and admission/registration processes for next semester.</p>

<p class="margBot">iv. If teaching in whole of the university is suspended due to some exigency, the period of the semester shall be either extended to the extent of the duration lost due to this or by offering additional teaching/contact hours per week during the remaining part of the semester.</p>

<p class="margBot">v. There will be two terms/tests in One Semester i.e. Mid Term Test (8 weeks teaching +9th week for examination) and Final Term Test (8 weeks of teaching + 18th week for examination) vi. A semester will be considered as valid if 80% lectures are delivered. vii. There will be no classes on Saturdays and Sundays.</p>

<p class="margBot">4.<strong> Academic Year/Session</strong>: The academic year / session shall comprise of two Regular and optional Summer Semesters as follows:</p>

<p class="margBot">i. Fall Semester, starting from First Monday of September to second week of January</p>

<p class="margBot">ii. Spring Semester, starting from First Monday of February &ndash; Second week of June iii. Summer Semester, during summer vacations to be used for offering minor/related or special courses, OR in special circumstances, particularly during the first academic years of students, the Head of the Department may conduct Spring Semester classes during Summer Semester. Note-1: In case the teaching in the whole or part of the semester is suspended because of some exigency, the Head of the Department may work out its own mechanism to compensate for the time lost.</p>

<p class="margBot">5.<strong> Admissions:</strong></p>

<p class="margBot">i. Admissions for 4-years Undergraduate Degree Programme (BS) and the ongoing MA/M.Sc shall be made for Fall Semester only.</p>

<p class="margBot">ii. Admission to BS 4-Year, Master 2-Year, MPhil &amp; MS will be announced within one week of the declaration of Intermediate, Bachelor and Master Examinations respectively and the process shall be completed within one month prior to commencement of semester.</p>

<p class="margBot">iii. If the number of students admitted in a programme is less than 15, the admission will be considered as cancelled</p>

<p class="margBot">iv. The Regulations for Admissions and Eligibility Requirements for various programs of studies are already prescribed and described in the Prospectus(s) of various programmes.</p>

<p class="margBot">6. <strong>Scheme of Studies/Program Structur</strong>e: Particular Programmes 1-Year Degree (Master) 2-Year Degree (Master) 3-Year Degree (Honours) 4-Year Degree (BS) 5-Year Degree (MS) Total Number of Cr. Hrs 33 - 36 63 &ndash; 72* 99 - 108 130 &ndash; 140* 163 &ndash; 172 No. of Semesters 2 4 6 8 10 Max. Duration** (In Semesters) 4 8 10 12 14 Course Load for Students (In Cr. Hrs) 9-12 15 - 18 15 - 18 15 &ndash; 18 15 &ndash; 18 *Excluding internship/viva voce **Maximum duration implies the compensation for time lost due to unavoidable circumstances</p>

<p class="margBot">7. <strong>Credit Hours</strong>:</p>

<p class="margBot">i. &ldquo;Credit Hour&rdquo; means teaching a theory class for 01 hour or laboratory/practical work of 02 hours or a field work of one day every week throughout the semester.</p>

<p class="margBot">ii. The number of credit hours for a degree program is inclusive of credit hours assigned to internship/research project/thesis etc.</p>

<p class="margBot">iii. The credit hours are denoted by two digits within brackets with a hyphen in between. The first (left side) digit represents the theory part while the second (right side) digit represents the practical. Thus 3(3-0) means three credit hours of theory, while 3(2-1) means a total of three credit hours, of which two are for theory while one credit hour is for laboratory.</p>

<p class="margBot">iv. The weekly contact hours of a 3(3-0) course will be three, while the contact hours of a 4(3-1) course will be four such that three contact hours for theory and one contact hour for laboratory.</p>

<p class="margBot">v. A course that shall be counted in calculation of GPA/CGPA is called &lsquo;Credit Courses&rsquo;, while a course that shall be mandatory to pass but shall not be counted in calculating GPA/CGPA is called &lsquo;Non-Credit Course&rsquo;.</p>

<p class="margBot">8. <strong>Assessment/Evaluation:</strong></p>

<p class="margBot">Marks Breakdown for assessment of each course shall be made as follows: S/No. Item Maximum Marks for Courses without Laboratory (3 + 0) Maximum Marks for Courses with Laboratory (2 + 1) 1 Mid Terms 9 th week 30% 30% 2 Quizzes/ Assignments/ Presentation/ Attendance/Laboratory 20% ( HoD/Teacher concerned will determine the distribution as per their requirement) 20% ( HoD/concerned Teacher will determine the distribution as per their requirement) 3. Final Terms 18th week 50% 50% Note-2: The format of the question paper(s) shall be designed by the concerned teacher(s) in such a way that it should explore the students&rsquo; grasp of the subject and originality of thoughts/concept clearance and not only the stored up knowledge. All the subjective and objective questions should be on higher cognitive level.</p>

<p class="margBot">i. MID TERM- 30%: (Duration 1.5 Hour) Number &amp; Nature of test questions: Ten objective type questions of 1 mark each. Two essay type questions of 10 marks each with no choice. Nature of Question Paper No. of Questions Marks Allotted Objective Type 10 10 (01 mark each) Essay Type 02 20 (10 marks each)</p>

<p class="margBot">ii. FINAL TERM: (Duration 2.0 Hours) Number &amp; Nature of test questions: Ten objective type questions of 20 marks. Three essay type questions of 10 marks each with no choice. Nature of Question Paper No. of Questions Marks Allotted Objective Type 10 20 (02 marks each) Essay Type 03 30 (10 marks each) Note-3: i. The Final Term paper shall cover 20% from Mid Term and 80% from the Final Term courses. Every teacher shall be required to inform the students regarding this distribution in the beginning of the Semester.</p>

<p class="margBot">i. The viva-voce of internship/research report shall be conducted by a committee comprising: a. Head of concerned department b. Teacher concerned c. One senior faculty member of the department concerned</p>

<p class="margBot">ii. For thesis an external examiner may be appointed and paid remuneration as per university rules.</p>

<p class="margBot">9.<strong> Attendance Requirement:</strong></p>

<p class="margBot">i. A minimum of 75% attendance of the lectures delivered in each course will be prerequisite to appear in Examinations.</p>

<p class="margBot">ii. A student who does not satisfy the requirements of attendance (at least 75% in each course) shall be ineligible to appear for the final-term examination of that course. And he/she shall repeat that course as regular student whenever it is offered again. Note-4: If a student represents the University, Province or Country in Sports, or any other officially sponsored activities during a semester, he/she will be given benefit in attendance up to 20 days in that semester on the recommendation of the head of the department concerned.</p>

<p class="margBot">10<strong>. Organization of Teaching:</strong></p>

<p class="margBot">i. Teaching in various courses shall be organized through lectures, tutorials, discussions, seminars, demonstrations, practical work in laboratories, field work, project, and any other method of instruction approved by the University.</p>

<p class="margBot">ii. Teaching shall be conducted by the University teachers or such other persons as may be declared to be teachers by the competent authority.</p>

<p class="margBot">iii. The university shall offer every required course at least once in an academic year.</p>

<p class="margBot">iv. English shall be the medium of instruction and examination for all courses except where otherwise approved by the competent authority.</p>

<p class="margBot">11. <strong>Change of course(s):</strong></p>

<p class="margBot">i. A student, with the permission of relevant dean/respective head of department, may be allowed to change the course/(s) within 7 days of the commencement of a semester. No change of course shall be allowed beyond this time limit. ii. So far change in a Programme/Discipline is concerned; the already existing university rules shall apply.</p>

<p class="margBot">12. <strong>Drop/Addition of course(s)</strong>: i. A student, with the permission of respective head of department may be allowed to drop/add a course within 7 days of the commencement of semester subject to the provisions of maximum and minimum semester work load. ii. The dropped course will be deemed not taken by the student ab-initio and will not appear on his/her transcript altogether.</p>

<p class="margBot">13.<strong> Withdrawal from course(s): </strong>a. Withdrawal from a course will be allowed latest up to one week before the final-semester examination on the recommendation of the concerned teacher with approval by the respective Head of Department / Institute / Centre. b. Withdrawn course shall be represented by the letter grade &lsquo;W&rsquo; on the transcript and will not be treated as &lsquo;F&rsquo; grade, i.e. the credit hours of a &lsquo;W&rsquo; course will not be taken into account while calculating GPA/CGPA of the student.</p>

<p class="margBot">14. <strong>Repeating Courses:</strong></p>

<p class="margBot">i. If a student was not allowed to take the examination of any subject due to shortage of attendance in that subject, he/she shall be required to register himself/herself in that subject whenever offered again, attend the classes regularly and reappear in examination.</p>

<p class="margBot">ii. If a student fails in any subject he/she shall be required to register himself/herself in that subject whenever offered.</p>

<p class="margBot">iii. The credit hours of repeating courses shall not be considered for the purpose of calculating maximum semester work load of the student.</p>

<p class="margBot">iv. The student(s) may repeat up to 6 courses in which he/she failed throughout the programme.</p>

<p class="margBot">v. In case a student repeats the course which has already been taken, the old grade will be substituted with the new grade, (for CGPA calculation) but in case student takes a new course in lieu of the course in which he/she failed, both the grades will reflect on his/her transcript i.e. old course grade and new course grade.</p>

<p class="margBot">15. <strong>Repeat Courses for Master/M.Phil Students: </strong>A graduate student with a &lsquo;C&rsquo; grade can repeat the course if he/she desires to improve. The maximum number of courses that a student may repeat at graduate level is three.</p>

<p class="margBot">16. <strong>Transfer of Credit Hours for Undergraduates/Masters/M.Phil: </strong>No credit hour of a course will be transferred if the grade is less than C for undergraduate and B for graduate.</p>

<p class="margBot">17. <strong>Improvement of Grades:</strong></p>

<p class="margBot">i. A student desirous of improving grade(s), from B or C, in selected course(s) may be allowed by the Head of the relevant Department, with information to the Controller of Examinations, after declaration of the result of the Final Semester (end of Programme).</p>

<p class="margBot">ii. Such improvement shall be allowed for not more than four courses, and shall be done within two semesters after declaration of the result of the Final Semester.</p>

<p class="margBot">iii. On improving subject, if one gets the grade less than the previous, the previous grade will be counted towards his passing. iv. Attendance will not be mandatory in the courses for which one has registered for improvement of grades. Nevertheless, it will be the sole responsibility of the concerned student to coordinate with the subject teacher regarding class quiz, assignments, presentation etc.</p>

<p class="margBot">18.<strong> Make-up Examination:</strong></p>

<p class="margBot">i. Make up test will be given on the request of those students who have fulfilled all requirements for appearing in the Mid/Final Term Examination but could not appear for any genuine reason or due to attending national/international event on behalf of the University.</p>

<p class="margBot">ii. Make-up Examination shall be conducted within 2 weeks of the end of the semester.</p>

<p class="margBot">iii. The pattern, i.e. nature and number of questions and weightage of the Make-up Examination shall remain similar to that of the Mid/Final Term Examination.</p>

<p class="margBot">iv. Students appearing in the Make-up Examination shall be charged with double examination fee.</p>

<p class="margBot">v. Any student failing in the Make-up Examination shall be required to re-register for the same semester as and when that semester starts in future.</p>

<p class="margBot">vi. There will be no Makeup/Special Examination in a semester for failed students; if a student fails in a course, he/she is required to repeat it. Note-5: Answer books/assignments must be shared with students after grading before the submission of the result by the concerned teacher.</p>

<p class="margBot">19.<strong> Promotion (undergraduate programme):</strong></p>

<p class="margBot">For promotion the following conditions shall be followed:</p>

<p class="margBot">i. If a student&rsquo;s CGPA falls below 2.0, he/she will be promoted (conditionally) and will be put on 1 st probation for the next semester.</p>

<p class="margBot">ii. If the student does not come out by increasing his/her CGPA to 2.0, he/she will go on Last Probation.</p>

<p class="margBot">iii. If the student who was earlier on last probation, does not come out by achieving the minimum desired CGPA, he/she shall be dropped from the Institute and can not be re-admitted by the same Institute. Note-6: Whenever a student fails or gets a &lsquo;F&rsquo; grade, s/he has to repeat the course, whenever offered. The maximum number of courses that a student may be allowed to repeat will be six (6). The re-registration for students with &lsquo;F&rsquo; grade shall be allowed (on a written request) to appear in the Mid Term and Final Term examinations for the failed courses whenever such examinations are conducted again. However, their grades earned in the previous semester in quizzes/attendance/ assignments/presentation/laboratory work will be considered for grading with the results of the new semester. No new quizzes/attendance/assignment/ presentation/laboratory work will be required.</p>

<p class="margBot">Promotion Table:1 S.No Promotion to A student shall pass 50% of the courses of A student shall pass 100% of the courses of 1 2 nd Sem 1 st Semester - 2 3 rd Sem 2 nd Semester - 3 4 th Sem 3 rd Semester 1 st Semester 4 5 th Sem 4 th Semester 2 nd Semester 5 6 th Sem 5 th Semester 3 rd Semester 6 7 th Sem 6 th Semester 4 th Semester 7 8 th Sem 7 th Semester 5 th Semester 20. Semester Freezing/leave of absence:</p>

<p class="margBot">i. Semester freezing will be granted by the relevant Dean on recommendations of the concerned Head of the Department in response to a request made by the student with reasonable justification.</p>

<p class="margBot">ii. A student can freeze up to two semesters at the maximum during the entire period of a relevant program of studies.</p>

<p class="margBot">iii. No freezing during the semester is allowed, i.e. whenever semester freezing is granted on the request of the student it would be effective from the beginning of the respective semester, thus all the attendance, quizzes, assignments, mid-term etc. taken so far in the semester by the student would be deemed as not have taken place in respect of the concerned student.</p>

<p class="margBot">iv. At the end of semester freezing the student will retake admission in the same semester when offered again and shall have to opt for courses in place at the time of readmission.</p>

<p class="margBot">v. The maximum duration allowed for completion of degree will be extended by the duration of semester freezing. Note-7: During the semester freezing the concerned student shall not be provided any facility by the University.</p>

<p class="margBot">21. <strong>Examination Fee</strong>:</p>

<p class="margBot">i. Examination Fee shall be collected along with admission fee and other dues by the concerned Department at the time of admission to a Semester.</p>

<p class="margBot">ii. The examination related stationary shall be provided by the Controller of Examinations.</p>

<p class="margBot">iii. The amount of prescribed fee and remuneration rates etc. will be as per university rules to be notified from time to time.</p>

<p class="margBot">22. <strong>Conduct of Examination:</strong></p>

<p class="margBot">i. Schedule of examination (Date Sheet) for mid-term and final-term examinations shall be notified by the Coordinator of Examinations at least two weeks before the commencement of respective examinations.</p>

<p class="margBot">ii. Every Course teacher shall submit the question paper to the coordinator of examinations at least 02 working days before the scheduled date of his/her paper.</p>

<p class="margBot">iii. The coordinator of examinations shall make necessary arrangements for the conduct of examinations including date sheets, acquisition of stationary (answer books) from the Controller of Examinations office, seating arrangement, photocopying of question paper in required number, notification of duty roster for teaching and non-teaching staff.</p>

<p class="margBot">23. <strong>Unfair Means (UFM) Cases:</strong></p>

<p class="margBot">i. Duty teacher/invigilator shall report any unfair means (UFM) case to the coordinator examinations soon after the conduct of concerned paper.</p>

<p class="margBot">ii. The coordinator of examinations shall report the UFM cases to the departmental semester committee which shall decide all such cases at the most after three days of end of respective midterm/final-term examinations.</p>

<p class="margBot">iii. The UFM cases shall be dealt with as per approved university rules.</p>

<p class="margBot">24. <strong>Cancellation of Admission:</strong> If a student fails to attend any lecture during the first two weeks, after the commencement of the semester as per announced schedule, his/her admission shall stand cancelled automatically as per already existing university rules without giving any notice.</p>

<p class="margBot">25. <strong>Course File:</strong> Maintenance of Course Files is mandatory for the teacher. It will have a complete record of everything that happened during the Semester.</p>

<p class="margBot">The Course File will contain: 1. Description of Course/course contents 2. Course coding 3. Weekly Teaching Schedule 4. Dates of Mid-semester Examination 5. Grading policy will identify each activity such as homework, quizzes, mid semester examination, final examination, term papers 6. Copy of each homework assignment 7. Copy of each quiz given 8. Copy of mid semester examinations 9. Grading sheets of the Course detailing statistical data on the grades obtained by students 10. Difficulties, problems faced during classroom/course delivery</p>

<p class="margBot">26. <strong>Result Declaration:</strong></p>

<p class="margBot">i. The mid-term result of a semester shall be prepared and displayed on the departmental notice board by the concerned teacher within 7 days of the end of such examination.</p>

<p class="margBot">ii. After holding the final-term examination of a semester each teacher shall prepare three copies of the result/awards on the prescribed subject award list (Annexure-I). He/she shall retain one copy and submit two copies to the Coordinator of Examinations along with answer books and question paper.</p>

<p class="margBot">iii. The Coordinator of Examinations shall keep one copy in his/her record while forward the second copy of the award list to the Controller of Examinations duly signed by the head of department/institute/centre.</p>

<p class="margBot">iv. The result of First Semester of any programme of studies shall be prepared and notified provisionally by the departmental semester coordinator of examinations after taking approval from the concerned head of department. Such a result shall be notified within 10 days of the conduct of final-term examination of the semester and a copy (Provisional) will be given to the student concerned.</p>

<p class="margBot">v. The results of all the following semesters including the results of previous semester (s) as per attached specimen (Annexure-II) will be prepared by the coordinator of examinations duly signed by the head of department/institute/centre and forwarded to the Controller of Examinations of the University for Notification. One copy of the result will be given to the student concerned also.</p>

<p class="margBot">vi. The result of each semester shall be declared within 10 days of the conduct of the Final Term examination.</p>

<p class="margBot">vii. The consolidated result shall be declared within 30 days of the conduct of the last examination of the Final Semester of the programme.</p>

<p class="margBot">viii. For the programs / degrees where research is optional, the students are required to submit the Thesis / Research Project report within two months from the date of last examination of the final semester. The evaluation of the project shall be made by the panel of three examiners comprising the Head, external examiner (to be recommended by the departmental semester committee and appointed by the controller of examinations) and a faculty member nominated by the Departmental Semester Committee.</p>

<p class="margBot">27. <strong>Record Keeping:</strong> i. Record of all results of each semester provided by the concerned Head of the Department to the Controller of Examinations shall be kept on record by the Controller of Examinations. ii. All Answer Books shall be kept on record for two years after declaration of the final result at the concerned Department.</p>

<p class="margBot">28. <strong>Grading System:</strong></p>

<p class="margBot">i. The grading shall be done on a scale of 1 &ndash; 4.</p>

<p class="margBot">ii. Equivalence between Letter grading and Numerical grading shall be as follows: Marks % age Value Grade Remarks 85 and above 4.0 A Excellent 84 3.9 B Very Good 83 38 82 3.7 81 3.6 80 3.5 79 3.4 78 3.4 77 3.3 76 3.3 75 3.2 74 3.2 73 3.1 72 3.0 71 2.9 C Good 70 2.8 69 2.7 68 2.6 67 2.5 66 2.5 65 2.4 64 2.4 63 2.3 62 2.2 61 2.1 60 2.0 59 1.9 D Fair 58 1.8 57 1.7 56 1.6 55 1.5 54 1.4 53 1.3 52 1.2 51 1.1 50 1.0 49 and below 0.0 F Fail I -- I Incomplete W -- W Withdrawal P -- P Pass (Non-Credit Course)</p>

<p class="margBot">iii. Fraction of marks obtained in a course shall be counted as one mark, e.g. 60.3 shall be considered as 60 while 49.5 or more is to be considered as 50.</p>

<p class="margBot">iv. Grade Point Average (GPA) is an ex<x>pression for the average performance of the student in the courses he/she has taken during any semester, thus GPA may be calculated for 1st semester, 2nd semester or any other semester. v. GPA shall be rounded to two decimal places, e.g. a GPA of 2.064285 shall be reported as 2.06, while a GPA of 2.065124 shall be reported as 2.07. vi. GPA shall be calculated in the following manner: GPA = &Sigma;GP/&Sigma;CH (for all the courses offered in a single semester), where: GP = Numeric Value of % of Marks obtained in a course multiplied by credit Hours of the said course &Sigma;GP = Sum of all the Grade Points of courses offered in the semester &Sigma;CH = Sum of all credit hours of courses offered in the semester Example-1: Calculation of GPA without Withdrawal of courses: Course Code %age of Marks Obtained Grade Value Credit Hours (CH) Grade Point (GP) 511 65 C 2.4 3 7.2 513 72 B 3.0 3 9.0 515 80 B 3.5 3 10.5 517 51 D 1.1 2 2.2 519 42 F 0.0 3 0.0 Total 14 28.9 GPA = &Sigma;GP/&Sigma;CH (for all courses offered in a semester) = 14 28.9 = 2.064285, and by rounding to two decimal places, the GPA will become 2.06. Example -2: Calculation of GPA with Withdrawal of courses: Suppose a student withdraws course code &lsquo;519&rsquo; as provided in these rules, then the GPA shall be calculated as follow: Course %age of Marks Obtained Grade Value Credit Hours (CH) Grade Point (GP) 511 65 C 2.4 3 7.2 513 72 B 3.0 3 9.0 515 80 B 3.5 3 10.5 517 51 D 1.1 2 2.2 519 42 W - - - Total 11 28.9 GPA = &Sigma;GP/&Sigma;CH (for all courses offered in a semester) = 11 28.9 = 2.6272, and by rounding to two decimal places, the GPA will become 2.63. vii. Cumulative Grade Point Average (CGPA) is an ex<x>pression for the average performance of the student in all the courses he/she has taken during all the previous semesters (the entire course of study), thus at the end of 1st semester, CGPA will be the same as GPA, while CGPA at the end of 2 nd or any subsequent semester will be calculated by taking into account all the courses taken by the student in all the previous semesters. viii. The CGPA shall be rounded to two decimal places. CGPA = &Sigma;GP/&Sigma;CH (for all the courses taken so far in all the previous semesters/ the entire course of study), where: GP = Numeric Value of % of Marks obtained in a subject multiplied by credit hours of the said subject &Sigma;GP = Sum of all the Grade Points of courses offered in all the previous semesters &Sigma;CH = Sum of all the credit hours of courses offered in all the previous semesters ix. A student shall be awarded incomplete grade represented by &lsquo;I&rsquo; in the following cases: a. If a student fails to complete any assignment, term paper or presentation assigned to him by the teacher for the purpose of internal assessment. b. In case a student is unable to appear in part or whole of the mid or final term examination of a semester on medical grounds or circumstances beyond the control of student to be determined by the Head of the Department, provided that he/she fulfills the condition of having attended the prescribed number of lectures.</p>

<p class="margBot">29. <strong>Award of Degrees</strong>: Minimum requirement for the award of 4 year BA/BS and ongoing MA/MSc or MS/MPhil/PhD degrees shall be a CGPA of 2.0 and 2.5 respectively.</p>

<p class="margBot">30. <strong>Departmental Semester Examination Committee</strong>: The Head of every Department shall notify a Semester Examination Committee, comprising 4 members including the Head of the Department as the Convener, two senior faculty members and Coordinator Examinations as the Secretary of the Committee, to perform the following functions: i. Periodic assessment of the progress of different courses being taught. ii. Periodic assessment of the contents of different courses being taught. iii. Investigation of any irregularity in the assessment of any course taught. iv. Periodic assessment of the method of teaching, pattern of question papers, and any other relevant aspect. v. The Committee shall submit annual report on the academic performance and assessment of students to the respective Dean. vi. The Committee shall also submit a report, to the respective Dean, on the evaluation of teachers by the students and evaluation of the courses by the students, using the questionnaires available with the Director, Quality Enhancement Cell. vii. The Committee shall look after the use of un-fair means during the any examination, and also the general behavior of students. The Committee shall be entitled to impose appropriate penalties as per university rules. viii. To review and analyze the question paper on standard format. ix. All the proceeding of the Committee shall be recorded by the Secretary (Departmental Coordinator Semester Examinations) and approved by the Convener.</p>

<p class="margBot">31. <strong>University Semester Committee:</strong> There shall be a University Semester Committee to be constituted by the Vice Chancellor. The Committee shall comprise the following as members: 1. All Deans 2. Registrar or his nominee 3. Director Admissions 4. Controller of Examinations or his nominee 5. Director, Quality Enhancement Cell (QEC) 6. Coordinator Semester Programme The Committee shall perform the following functions: i. Provide consultation to the Departments regarding implementation of semester system. ii. Provide support in the implementation of semester system by arranging short courses for the faculty on various aspects. iii. Monitor and report on the implementation of semester Regulations and address various issues arising thereof. iv. Recommend necessary amendments in the Semester Regulations, if needed.</p>

<p class="margBot">32. <strong>Repealing Clause</strong>: Subsequent to the approval of the above-mentioned Regulations for the Semester System at the University of Peshawar, all existing Regulations pertaining to the conduct of Semester System at any of the Department / College / Institute / Centre shall stand repealed.</p>

<p class="margBot">33. <strong>Academic Calendar</strong>: The university shall publish a schedule of complete academic year for Fall, Spring, and Summer Semesters in the respective prospectus for the convenience of students and faculty members mentioning the following: 1. Semester starting date 2. Holidays during the semester 3. Semester culmination date 4. Mid/Final-Exam Week 5. Grade notification date Note-8: Instruction should be given in the calendar to the students that they will be responsible to meet the requirement and deadline published for each semester in the academic calendar of the university. Students are expected to know, adhere to regulations, course loads, prerequisites and policies of the university as well as those of the departments/institutes/centers in which they will be enrolled.</p>

<p class="margBot">34. <strong>Submission of Thesis</strong>: Students will be required to submit the thesis within 120 days of last theory paper, failing which will vacate the Hostels.</p>                            </p>
                        </div>
                        <div class="span3">
                            <h3>Announcements <a href="announcements.php" style="font-size:12px;">View All</a></h3>
                            <div id="news-container">
                            <ul class="list4 support-box">
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=209"><time datetime="2024-10-30">October 30, 2024</time></a>
                                        <div>Science Department, College of Home Econ...</div>
                                        <div><a href="show-event.php?id=209" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=208"><time datetime="2024-10-06">October 06, 2024</time></a>
                                        <div>Ms. Sidra Ali defended her research unde...</div>
                                        <div><a href="show-event.php?id=208" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=207"><time datetime="2024-09-11">September 11, 2024</time></a>
                                        <div>The entry test for MPhil/PhD programs in...</div>
                                        <div><a href="show-event.php?id=207" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                            </ul>
                            </div>
                            <h3>Upcoming Events <a href="upcoming-events.php" style="font-size:12px;">View All</a></h3>
                            <div id="news-container2">
                            <ul class="list4 support-box">
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=202"><time datetime="2024-03-03">March 03, 2024</time></a>
                                        <div>SPRING FIESTA, TUESDAY 5TH MARCH 2024....</div>
                                        <div><a href="show-event.php?id=202" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=201"><time datetime="2024-02-21">February 21, 2024</time></a>
                                        <div>A two day book fair was organized in col...</div>
                                        <div><a href="show-event.php?id=201" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=193"><time datetime="2023-10-04">October 04, 2023</time></a>
                                        <div>Newly admitted FSc students Orientation ...</div>
                                        <div><a href="show-event.php?id=193" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                            </ul>
                            </div>
                            
                        </div>                    </div>
                 </article>
            </div>
        </section>
    </div>
</div>
</div>
<!--footer-->
<footer>
    <div class="main">
        <div class="container">
            <div class="row">
                <article class="span12">
                    <p style="margin-top:20px;">College of Home Economics &copy; 2024. <a href="privacy-policy.php" title="Learn how we use your information">Privacy Policy</a></p>
                    <p align="right"><a style="display:none;" target="_blank" title="Site designed by SuperWebz.com" href="http://www.superwebz.com"><img src="img/superwebz_logo.jpg" alt="SuperWebz.com" /></a></p>
                </article>
            </div>
            <!-- {%FOOTER_LINK} -->
        </div>  
    </div> 
</footer><script type="text/javascript" src="js/bootstrap.js"></script>
<script>
    $('.list3 li a').hover(function(){
        $(this).stop().css({color:'#fc6f22'});	
        $(this).stop().parent().siblings('em').css({'background-position':'0 bottom'});	 
            }, function(){
        $(this).stop().css({color:'#1295d4'});	
        $(this).stop().parent().siblings('em').css({'background-position':'0 top'});						 
    })
    $('#search a').hover(function(){
        $(this).stop().animate({opacity:'0.5'});	
            }, function(){
       $(this).stop().animate({opacity:'1'});						 
    })
</script>

</body>
</html>
