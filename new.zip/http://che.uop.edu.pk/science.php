<!DOCTYPE html>
<html lang="en">
<head>
<title>Science Department - College of Home Economics, University of Peshawar</title>
<meta charset="utf-8">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
<meta name = "format-detection" content = "telephone=no" />
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<!--CSS-->
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/camera.css">
<!--JS-->
<script src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery.vticker-min.js"></script>
<script src="js/jquery-migrate-1.1.1.js"></script>
<script src="js/superfish.js"></script>
<script src="js/jquery.mobilemenu.js"></script>
<script src="js/jquery.cookie.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.ui.totop.js"></script>
<script>	
	$(function(){
	$('#news-container').vTicker({ 
		speed: 500,
		pause: 5000,
		animation: 'fade',
		mousePause: true,
		showItems: 3
		});
	});
	
	$(function(){
	$('#news-container2').vTicker({ 
		speed: 500,
		pause: 5000,
		animation: 'fade',
		mousePause: true,
		showItems: 2
		});
	});
</script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
<script src="//code.jquery.com/ui/1.11.2/jquery-ui.js"></script>
<script>
$(function() {
$( "#accordion" ).accordion({
collapsible: true,
active: false,
heightStyle: "content"
});
});
</script>
<!--[if lt IE 8]>
		<div style='text-align:center'><a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/img/upgrade.jpg"border="0"alt=""/></a></div>  
<![endif]-->
<!--[if lt IE 9]>
  <link rel="stylesheet" href="css/ie.css">
  <link rel="stylesheet" href="css/docs.css">
  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body>
<div class="global">
<!--header-->
<header>
    <div class="main">
        <div class="gradient">
        <div class="container">
             <article>
                <div class="navbar navbar_ clearfix">
                    <div class="navbar-inner">      
                          <div class="clearfix">
                                <div class="nav-collapse nav-collapse_">
                                	<ul class="nav sf-menu clearfix">
                                	  <li><a href="index.php">Home</a></li>
                                      <li class="sub-menu"><a href="#">About</a>
                                        <ul>
                                            <li><a href="che-history.php">Brief History</a></li>
                                            <li><a href="leadership.php">Leadership</a></li>
                                            <li><a href="foundation-faculty.php">Foundation Faculty</a></li>
                                            <li><a href="contact-us.php">Contact Us</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Programs</a>
                                        <ul>
                                            <li><a href="art-design-introduction.php">Art & Design</a></li>
                                            <li><a href="food-nutrition-sciences-introduction.php">Food & Nutrition Sciences</a></li>
                                            <li><a href="human-development-family-studies-introduction.php">Human Development &amp; Family Studies</a></li>
                                            <li><a href="resource-facility-management-introduction.php">Resource &amp; Facility Management</a></li>
                                            <li><a href="textile-clothing-introduction.php">Textile & Clothing</a></li>
                                            <li><a href="#">Mandatory Supportive<span></span></a>
                                              <ul>
                                             <li><a href="computer-science-introduction.php">Computer Science</a></li>
                                              <li><a href="english-introduction.php">English</a></li>
                                              <li><a href="pak-studies-introduction.php">Pak. Studies</a></li>

                                              <li><a href="science-introduction.php">Science Department</a></li>
                                              <li><a href="urdu-islamiyat-introduction.php">Urdu / Islamiyat</a></li>
                                              </ul>
                                            </li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Admissions</a>
                                        <ul>
                                          <li><a href="bsc.php">BS Public Health<span></span></a>
                                        	<ul>
                                              <li><a href="bsc-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="bsc-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="bsc-uniform.php">Uniform</a></li>
                                              <li><a href="bsc-merit-list.php">Merit List</a></li>
                                              <li><a href="bsc-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="fsc.php">F.A/ F.Sc.<span></span></a>
                                        	<ul>
                                              <li><a href="fsc-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="fsc-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="fsc-uniform.php">Uniform</a></li>
                                              <li><a href="fsc-merit-list.php">Merit List</a></li>
                                              <li><a href="fsc-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="bs-hons.php">B.S Home Economics<span></span></a>
                                        	<ul>
                                              <li><a href="bs-hons-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="bs-hons-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="bs-hons-uniform.php">Uniform</a></li>
                                              <li><a href="bs-hons-merit-list.php">Merit List</a></li>
                                              <li><a href="bs-hons-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="msc.php">BS Human Nutrition & Dietetics<span></span></a>
                                        	<ul>
                                              <li><a href="msc-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="msc-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="msc-uniform.php">Uniform</a></li>
                                              <li><a href="msc-merit-list.php">Merit List</a></li>
                                              <li><a href="msc-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="mphil.php">M.Phil<span></span></a>
                                        	<ul>
                                              <li><a href="mphil-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="mphil-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="mphil-uniform.php">Uniform</a></li>
                                              <li><a href="mphil-merit-list.php">Merit List</a></li>
                                              <li><a href="mphil-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="phd.php">Ph.D<span></span></a>
                                        	<ul>
                                              <li><a href="phd-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="phd-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="phd-uniform.php">Uniform</a></li>
                                              <li><a href="phd-merit-list.php">Merit List</a></li>
                                              <li><a href="phd-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Examination</a>
                                        <ul>
                                          <li><a href="examination-rules.php">Rules</a></li>
                                          <li><a href="datesheet.php">Date Sheet</a></li>
                                          <li><a href="results.php">Results</a></li>
                                          <li><a href="convocation.php">Convocation</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="college-faculty.php">Faculty</a>
                                        <ul>
                                          <li><a href="faculty-art-and-design.php">Art & Design</a></li>
                                          <li><a href="faculty-food-and-nutrition-sciences.php">Food & Nutrition Sciences</a></li>
                                          <li><a href="faculty-human-development-and-family-studies.php">Human Development and Family Studies</a></li>
                                          <li><a href="faculty-resource-and-facility-management.php">Resource and Facility Management</a></li>
                                          <li><a href="faculty-textile-and-clothing.php">Textile & Clothing</a></li>
                                          <li><a href="faculty-science.php">Science</a></li>
                                          <li><a href="faculty-computer-studies.php">Computer Studies</a></li>
                                          <li><a href="faculty-english.php">English</a></li>
                                          <li><a href="faculty-pak-studies.php">Pak. Studies</a></li>
                                          <li><a href="faculty-urdu.php">Urdu</a></li>
                                          <li><a href="faculty-islamiyat.php">Islamiyat</a></li>
                                          <li><a href="faculty-login.php">Faculty Login</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Student's Life</a>
                                        <ul>
                                          <li><a href="students-societies.php">Student Societies</a></li>
                                          <li><a href="students-society-members.php">Society Members</a></li>
                                          <li><a href="students-academic-visits.php">Academic Visits</a></li>
                                          <li><a href="students-recreational-trips.php">Recreational Trips</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Facilities</a>
                                        <ul>
                                  <li><a href="facilities-bookshop.php">Bookshop</a></li>                                          <li><a href="facilities-canteen.php">Canteen</a></li>

                                          <li><a href="facilities-daycare.php">Day Care</a></li>                                          <li><a href="facilities-first-aid-room.php">First Aid Room</a></li>

                                          <li><a href="facilities-generators.php">Generators</a></li>
                                                                                                                   <li><a href="facilities-home-management-residence.php">Home Management Residence</a></li>
        <li><a href="facilities-hostel.php">Hostel</a></li>
   <li><a href="facilities-internet.php">Internet</a></li>

                                          <li><a href="facilities-library.php">Library</a></li>
                                                                              <li><a href="facilities-mosque.php">Mosque</a></li>
                                          <li><a href="facilities-nursery.php">Nursery</a></li>
                                        <li><a href="facilities-photocopier.php">Photocopier</a></li>

                                          <li><a href="facilities-playgroup.php">Play Group</a></li>
                                            <li><a href="facilities-preplaygroup.php">Pre Play Group</a></li>      
                                          <li><a href="facilities-transport.php">Transport</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="alumni-list.php">PFHE</a>
                                        <ul>
                                          <li><a href="pfhe.php">Introduction</a></li>
                                          <li><a href="alumni-profile.php">Members Profile</a></li>
                                          <li><a href="alumni-list.php">Federation & Alumni Members</a></li>
                                        </ul>
  </li>
                                      <li class="sub-menu"><a href="#">JHEBS</a>
                                        <ul><li><a href="jhebs-call-for-papers.php">Call for Papers</a></li>
                                          <li><a href="jhebs-published-versions.php">Published Versions</a></li>
                                          <li><a href="jhebs-research.php">Research</a></li>
                                          <li><a href="jhebs-rules.php">Rules</a></li>
                                                                                    <li><a href="jhebs-updates.php">Updates</a></li>

                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Conference</a>
                                        <ul>
                                          <li><a href="conference-call-for-papers.php">Call For Papers</a></li>
										  <li><a href="conference-accepted-papers.php">Accepted Papers</a></li>
										  <li><a href="conference-registration-and-payment.php">Registration and Payment</a></li>
										  <li><a href="conference-important-dates.php">Important Dates</a></li>
										  <li><a href="conference-keynote-speaker.php">Keynote Speaker</a></li>
										  <li><a href="conference-committee.php">Committee</a></li>
										  <li><a href="conference-abstract-submission.php">Abstract Submission</a></li>
										  <li><a href="conference-topics.php">Conference Topics</a></li>
										  <li><a href="conference-presentation-instructions.php">Presentation Instructions</a></li>
										  <li><a href="conference-who-should-attend.php">Who should Attend</a></li>
										  <li><a href="conference-tentative-programme.php">Tentative Programme</a></li>
										  <li><a href="conference-venue.php">Venue</a></li>
										  <li><a href="conference-final-paper-submission.php">Final Paper Submission</a></li>
										  <li><a href="conference-paper-templates.php">Paper Templates</a></li>
										  <li><a href="conference-accommodation-and-travel.php">Accommodation & Travel</a></li>
										  <li><a href="conference-conference-poster.php">Conference Poster</a></li>
										  <li><a href="contact-us.php">Contact Us</a></li>
                                        </ul>
                                      </li>
									  <li class="sub-menu"><a href="#">Activities</a>
                                        <ul>                                          <li><a href="college-magazine.php">College Magazine</a></li>
                                          <li><a href="activities-exhibitions.php">Exhibitions</a></li>
                                          <li><a href="activities-internships.php">Internships</a></li>
                                          <li><a href="activities-lectures.php">Lectures</a></li>
                                          <li><a href="newsletter.php">Newsletter</a></li>                                          <li><a href="activities-seminars.php">Seminars</a></li>

                                          <li><a href="activities-sports.php">Sports</a></li>
                                                                                 <li><a href="activities-tutorials.php">Tutorials</a></li>
   <li><a href="activities-workshops.php">Workshops</a></li>
                                        </ul>
                                      </li>
                                    </ul>
                                 </div>
                                 <ul class="follow_icon">
                                    <li><a href="https://www.facebook.com/CHEUOP/"><img src="img/follow_icon2.png" alt=""></a></li>                                                                    </ul>                          </div>
                    </div>
                </div>
                <h1 class="brand"><a href="index.php"><img src="img/logo.png" alt=""></a></h1>
                <form id="search" class="search" action="search-results.php" method="GET" accept-charset="utf-8">
                	 <input type="text" onFocus="if(this.value =='Search for...' ) this.value=''" onBlur="if(this.value=='') this.value='Search for...'" value="Search for..." name="q">
                     <a href="#" onClick="document.getElementById('search').submit()"><img src="img/magnify.png" alt=""></a>
                </form>             </article>
        </div>
        </div>
    </div>
</header>

<div class="main">
    <div class="gradient1">
        <section class="container">
            <div class="row">
                <article class="span12 margBot6">
                    <div class="row">
                        <div class="span3 support-box">
                            <h3>Program Links</h3>
                            <ul class="list3">
                                <li><em></em><p><a href="science-introduction.php">Introduction</a></p></li>
                                <li><em></em><p><a href="science.php">Department Highlights</a></p></li>
                                <li><em></em><p><a href="science-faculty.php">Faculty</a></p></li>
                                <li><em></em><p><a href="science-department-pictures.php">Department Pictures</a></p></li>
                                <li><em></em><p><a href="science-scheme-of-study.php">Scheme of Study</a></p></li>
                                <li><em></em><p><a href="science-research-publications.php">Research Publications</a></p></li>
                                
                            </ul>
                        </div>
                        <div class="span6 support-box">
                            <h3>Science Department > Department Highlights</h3>

                            <div id="accordion">
							
                                <h3>Workshops</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p class="MsoNormal" style="text-align: justify; text-justify: inter-ideograph;"><strong style="mso-bidi-font-weight: normal;"><strong>Ph.D Research:</strong></strong></p>
<p class="MsoNormal" style="text-align: justify; text-justify: inter-ideograph;">Two-stage Pyrolysis of Spent Lubricant Oil into Premium Fuels over Ferrites and Coal Ash as Heterogeneous Catalysts</p>
<p class="MsoNormal" style="text-align: justify; text-justify: inter-ideograph;"><strong style="mso-bidi-font-weight: normal;">EXPERIENCE:</strong></p>
<p class="MsoNormal" style="text-align: justify; text-justify: inter-ideograph;">Teaching Various courses at Ph.D, M. Phil level, Biochemistry to M.Sc &amp; B.Sc III, IV and BS and Chemistry to BS l, B.Sc II &amp; F.Sc at College of Home Economics, University of Peshawar since 7thJanuary 1994 till date</p>
<p class="MsoNormal" style="text-align: justify; text-justify: inter-ideograph;"><strong style="mso-bidi-font-weight: normal;">ACADEMIC QUALIFICATION:</strong></p>
<p class="MsoListParagraphCxSpFirst" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong style="mso-bidi-font-weight: normal;">Ph.D: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong>Institute of Chemical Sciences , University of Peshawar 2016</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong style="mso-bidi-font-weight: normal;">M.Phil</strong>:&nbsp;&nbsp;&nbsp; &nbsp;Institute of Chemical Sciences , University of Peshawar 2009</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong style="mso-bidi-font-weight: normal;">M.Sc</strong>: &nbsp;&nbsp;&nbsp;&nbsp;Chemistry (Biochemistry, Institute of Chemical Sciences , University of Peshawar 1992</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong style="mso-bidi-font-weight: normal;">B.Sc: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong>(Biological Science Group) JCW , University of Peshawar 1989</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong style="mso-bidi-font-weight: normal;">B.Ed: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong>IER, University of Peshawar 1993</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong style="mso-bidi-font-weight: normal;">F.Sc: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong>University Model School &amp; College, UOP, BISE Peshawar 1987</p>
<p class="MsoListParagraphCxSpLast" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong style="mso-bidi-font-weight: normal;">SSC: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong>University Model School &amp; College, UOP, BISE Peshawar 1985</p></p><p align="right">,Participated,, by: <a href="profile.php?id=16" class="text-info"><span class="text-info">Dr. Razia Tariq Khan</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p class="MsoListParagraphCxSpFirst" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Participated in &ldquo; National Educational&nbsp; Seminar&rdquo; jointly organized by University of Peshawar and Federation of All Pakistan Universities Academic Staff Association at Bara Gali Summer Camp 11th-16th August, 2004</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; AIDS Control Program organized by Ministry of Health at Khyber Medical College, Peshawar in December, 2005.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Seminar attended on &ldquo;Why Proteins Attenuate Blood Glucose Levels in Teenage Girls&rdquo; on 1st November, 2011 at College of Home Economics, University of Peshawar, arranged by Family Science Department, University of Kuwait.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; An extension lecture &ldquo;Hybridization Technique&rdquo; was arranged for students of F.Sc part 2 on 16th November, 2011 at College of Home Economics, University of Peshawar.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Attended a seminar on&rdquo; Introduction to Centralized Resource Laboratory, University of Peshawar&rdquo; on January 19th, 2012 by professor Dr. Riaz, at&nbsp; Institute&nbsp; of Physics and Electronics, University of Peshawar</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Participated in &ldquo; International Women&rsquo;s Day organized by Peshawar University Teachers&rsquo; Association (PUTA) March 8th 2012</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Attended a lecture on &ldquo;Introduction to Centralized Resource Laboratory, University of Peshawar, as a Research Place for Food Analysis&rdquo; to M.Sc, M.Phil and Ph.D scholars on 3rd December, 2013 at College of Home Economics, University of Peshawar.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Attended a lecture on &ldquo;Use of Equipment for Research Work&rdquo; to M.Phil Scholars at Institute of Chemical Sciences, University of Peshawar, supervised by Prof. Dr Jasmine Shah on 5th January, 2014</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Attended a lecture on &ldquo;Health Hazards of House Hold Chemicals and How to Control Them&rdquo; to BS students on 15th January, 2014 at College of Home Economics, University of Peshawar.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Participated in Mega event MOTHER&rsquo;s DAY by South Asian Center for International &amp; Regional Studies May 11th, 2014 at University of Peshawar.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Attended 1st National Conference on &ldquo;HOME ECONOMICS: EXPOLRING NEW HORIZON&rdquo; held on June 03-04th, 2014 at Bara Gali Summer Camp, KPK</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Attended a lecture on &ldquo;Influence of Some Heterogeneous Catalysts on Pyrolytic Conversion of Model Polypropylene and High Density Polyethylene into Fuel like Products&rdquo; by M. Ismail, a Ph.D scholar, on 25th June, 2014 at Institute of Chemical Sciences, University of Peshawar. </p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Attended a lecture on &ldquo;Nutrition and Diet as an Adjunct Factor in Cardiovascular Disorders&rdquo;, arranged by Food and Nutrition Department, College of Home Economics. University of Peshawar on World Heart Day i.e. 30th &nbsp;Sept, 2014.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Attended a lecture to BS and M.Sc students on &ldquo;Chemistry in Daily Life and its Role in Home Economics&rdquo; on 16th October, 2014 at College of Home Economics, University of Peshawar.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Attended a lecture delivered by Dr. Nabeela Javed, Oncologist at IRNUM, Peshawar on Breast Cancer Awareness Program, organized by Food and Nutrition Department, College of Home Economics, University of Peshawar, on 28th October, 2014 in collaboration with PASTIC.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Attended a workshop on &ldquo;Counseling and Rehabilitation of Disabled People at College of Home Economics, University of Peshawar on 16th of December, 2014.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Attended a public defence of a Ph.D scholar on 27th February, 2015 at Department of Environmental Sciences, UOP, on &ldquo;Water Pollution&rdquo; </p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Attended a two-days training on &ldquo;Basic life Support and First Aid&rdquo; on 14th and 15thMay&nbsp; 2015,organized by US Educational Foundation Pakistan in collaboration with Rescue 1122 Peshawar at College of Home Economics, University of Peshawar.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Arranged a one-day workshop on &ldquo;Three Dimensional Structure of Organic Molecules on 15th May, 2015 at College of Home Economics, University of Peshawar.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Organized Seminar on &ldquo;Laboratory Safety Rules, Precautions and Measures&rdquo; speaker: Dr Behisht Ara Assist. Prof. Malakand University, on May 22nd 2015 at College of Home Economics, University of Peshawar.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Attended a workshop on &ldquo;Work Place Ethics and Food Science, Etiquettes for Organization at Exhibition Hall at College of Home Economics, University of Peshawar on 25th may, 2015 arranged by Department of Foods and Nutrition Sciences. </p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Attended a breast cancer awareness lecture arranged at Agha Khan Auditorium on 7th of October, 2015.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Attended a workshop on &ldquo;Emergency Response Management&rdquo; on 19th and 21st of November, 2015 at College of Home Economics, University of Peshawar.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Attended a lecture on &ldquo;Influence of Methanol Extracts of Rice Husk and Saw Dust as Antioxidants on Thermo-Oxidative Stability of Base Lubricating Oil&rdquo; by Jan Ullah, a Ph.D scholar, at ICS, UOP, on 18thDecember, 2015.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Attended a lectures on &ldquo;Synthesis and Characterization of Chemosensors and their Screening against Metals and Pharmaceutical&rdquo; by Aliya Minhas,&nbsp; a Ph.D scholar, at ICS, UOP, on 1st March, 2016 </p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Attended a consultative workshop on &ldquo; Updation of Revised Environmental Profile&rdquo; of Khyber Pakhtunkhwa at Pakistan Forest Institute, Organized by Environmental Protection Agency , Govt of KP on 3rd June, 2016</p>
<p class="MsoListParagraphCxSpMiddle" style="text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Attended a lecture on &ldquo;Advanced Solid Phase Extraction Methods for the Preconcentration of selected Heavy Metals using Magnetic Nanomaterials&rdquo; by Mansoor Khan, a Ph.D scholar, at ICS, UOP, on 18th October, 2016.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Organized a seminar titled &ldquo;Effects of early marriage on nutritional status of women in KP&rdquo; 2016 by Momina Tariq M.Sc research scholar college of Home Economics UOP in the college as well as ICS, UOP</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Organized a seminar titled &ldquo;General Laboratory Precautionary Measures&rdquo; on 20th January 2017 at College of Home Economics, UOP for B.Sc II, IV &amp; M.Sc textile department students, guest speaker Dr. Behisht Ara, asst. Prof. ICS, UOP.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Organized a seminar titled &ldquo;Emerging Environmental Issues&rdquo; on 26th January 2017 at College of Home Economics, UOP for F.Sc II, IV &amp; M.Sc students, guest speaker Dr. Kashif Gul, asst. Prof. ICS, UOP.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Organized a seminar titled &ldquo;Household water purification methods&rdquo; in January 2017 at College of Home Economics, UOP for B.Sc III, IV &amp; M.Sc students, guest speaker Dr. Waqas Ahmad , asst. Prof. ICS, UOP.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Organized a seminar titled &ldquo;solar energy&rdquo; in January 2017 at College of Home Economics, UOP for B.Sc I &amp; M.Sc students, guest speaker Dr. Gul Rehman , asst. Prof. ICS, UOP.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Arranged an extension lecture, titled &ldquo;Coordination Complexes&rdquo; speaker Dr. Adnan Khan, assist Prof., ICS, UOP on 2nd Feb 2017 for F.Sc II at College of Home Economics University of Peshawar</p>
<p class="MsoListParagraphCxSpMiddle" style="text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Organized a seminar titled &ldquo;Oil Pollution&rdquo; on 19th october 2017 at College of Home Economics, UOP for BS-l students, guest speaker Dr. Waqas Ahmad , asst. Prof. ICS, UOP.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Organized a seminar titled &ldquo;Molecular Basis of Carcinogenesis&rdquo; on October 26th 2017 at College of Home Economics, UOP for BS-Ist semester, guest speaker Dr. Muhammad Imran , asst. Prof. ICS, UOP.</p>
<p class="MsoListParagraphCxSpLast" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Organized a Workshop titled &ldquo; Techniques and Methodology in Thesis Writing&rdquo; on March 8th 2018 by Ms. Azra Masood M.Sc research scholar college of Home Economics UOP</p></p><p align="right">,Participated,, by: <a href="profile.php?id=16" class="text-info"><span class="text-info">Dr. Razia Tariq Khan</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>state life wo</p></p><p align="right">,,,Attended by: <a href="profile.php?id=61" class="text-info"><span class="text-info">Ms. Urooj Syed</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Conferences</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p class="MsoNormal" style="text-align: justify; text-justify: inter-ideograph;"><strong>Conferences/Seminars/Workshops: </strong>She organized and participated in Spring Research Poster Symposium, held in April, 2016.</p></p><p align="right">,Participated,, by: <a href="profile.php?id=16" class="text-info"><span class="text-info">Dr. Razia Tariq Khan</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Seminars</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>Extension Lectures</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p class="MsoListParagraph" style="text-align: justify; text-justify: inter-ideograph;"><strong>Teaching Assignments</strong><strong>:</strong> Dr. RAZIA TARIQ KHAN taught courses to Ph.D, M.Phil, F.Sc, B.Sc, BS, and M.Sc classes. She supervised general and advanced level labs. She also supervised Laboratory of Special Practical&rsquo;s. Further, she supervised Thesis at M.Sc. level.</p></p><p align="right">,Participated,, by: <a href="profile.php?id=16" class="text-info"><span class="text-info">Dr. Razia Tariq Khan</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Trainings</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                           <p style="color:#333333;font-weight:normal;"><p class="MsoNormal" style="text-align: justify; text-justify: inter-ideograph;"><strong style="mso-bidi-font-weight: normal;">TRAINING RECEIVED:</strong></p>
<p class="MsoListParagraphCxSpFirst" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Supported open learning Program at British Council Peshawar from 1stOct 2007-31st March 2008</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Live Stock and Dairy Farming from Pakistan Academy for Rural Development (PARD) May 5th-9th 2009.</p>
<p class="MsoListParagraphCxSpLast" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Three-day workshop attended on Research and Proposal Writing February 9th-11th 2010 at TCC organized by Peshawar University Teachers&rsquo; Association (PUTA), University of Peshawar.</p>
<p class="MsoNormal" style="text-align: justify; text-justify: inter-ideograph;"><strong style="mso-bidi-font-weight: normal;">TRAINING IMPARTED:</strong></p>
<p class="MsoListParagraphCxSpFirst" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Concepts and Principals of Model Making to College Students of B.Sc Part I, II &amp; III at College of Home Economics, University of Peshawar&nbsp; from 5-8th November, 2006</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Participated in a walk regarding immunization on October, 1st 2009 arranged by provisional Minister for Health from Convocation hall to TCC, UOP.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Attended a lecture titled &ldquo;Awareness of AIDS caused by spread of HIV infection on 8th December, 2009 organized by provincial AIDS control program on World AIDS Day.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Arranged a visit to train M.Sc students for HBC and RBC at IRNUM hospital on February 22nd, 2010.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Screening of blood samples for HBV and HDC was arranged for students at College of Home Economics, University of Peshawar, March 10th, 2010. </p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Co-organized&nbsp; 5-days training in &ldquo;DOING CHEMISTRY IN A SAFE WAY&rdquo; by Institute of Chemical Sciences, University of Peshawar, International year of Chemistry 2011 (Chemistry our life &ndash;our future) January 06-10th,2011</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Participated in a breast cancer awareness walk on October 18th, 2011 arranged by IRNUM, PAEC.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Arranged an activity &ldquo;Green Walk&rdquo; to promote clean environment on 5th January, 2012 at College of Home Economics, University of Peshawar.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Supervised and arranged a demonstration about RBC and WBC counts at pathology Laboratory, IRNUM Hospital on 12th of May, 2012 for students of M.Sc Previous, College of Home Economics, University of Peshawar.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Organized one-Day workshop on &ldquo;Three dimensional Structures of Organic Molecules&rdquo; on May 15th, 2015 at College of Home Economics, University of Peshawar.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Trained students of F.sc II&nbsp; in January, 2016 for attempting MCQ&rsquo;s for ETEA for high scores </p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Organized one-day awareness program for students of College of Home Economics in contest to self-grooming, child labor, eating habits on 18th January 2017.</p>
<p class="MsoListParagraphCxSpLast" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Supervised and arranged a demonstration about RBC and WBC counts at pathology Laboratory, IRNUM Hospital 2013-18 for students of M.Sc Previous, College of Home Economics, University of Peshawar.</p></p><p align="right">,Participated,, by: <a href="profile.php?id=16" class="text-info"><span class="text-info">Dr. Razia Tariq Khan</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Exhibitions</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p class="MsoListParagraphCxSpFirst" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Remained <strong style="mso-bidi-font-weight: normal;">President Science Club</strong> at Jinnah College for Women, University of Peshawar. 1988-89.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Won <strong style="mso-bidi-font-weight: normal;">3rd Prize NWFP Science fair &lsquo;86</strong> held April 24- 30, 1986, University of Peshawar.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong style="mso-bidi-font-weight: normal;">S</strong>upervised students of College of Home Economics as Teacher in Science Exhibitions/Competitions since 1994 at <strong style="mso-bidi-font-weight: normal;">JCW won 3rd</strong> prize<strong style="mso-bidi-font-weight: normal;">, Edwards College won 1st</strong> prize.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;Participated in Science and Cultural Exhibition at Edwards College, Peshawar 1993-94</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Participated in Science and Cultural Fair at Edwards College, Peshawar 7th -8th ,February 2003.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Supervised Science Exhibition organized by Science Club, College of Home Economics, University of Peshawar, September 27th, 2003.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;Mega Science Fair organized by Science Society UOP, PUTA Hall won <strong style="mso-bidi-font-weight: normal;">3rd prize</strong>.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 17th Annual National Science fair at Lahore 2004.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Participated in 2nd Science and Cultural Exhibition at Jinnah College for women, University of Peshawar, January 24th, 2004</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Supervised the <strong style="mso-bidi-font-weight: normal;">First prize winning team in The &ldquo; 19th Annual Science Competitions, 2006 held at Lahore-</strong>Category Girls, College Universities&rdquo;</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Participated in 2nd Science and Cultural Exhibition at Edwards College, Peshawar 21-22nd December, 2006</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Presented Certificate of Excellence in Dynamic Guidance &amp; Outstanding Services for&nbsp; Science Society College of Home Economics, University of Peshawar,&nbsp;&nbsp; 8th November, 2006</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Participated in MEGA Science Exhibition organized by Science Society at University of Peshawar 2007.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Arranged an Essay writing competition on &ldquo;Science and Quran&rdquo; on November 11th, 2009 at College of Home Economics, University of Peshawar.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;Organized and supervised a &ldquo;science day&rdquo;, the theme was environment on November 11th ,2009 at College of Home Economics, University of Peshawar,</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Supervised students of&nbsp; in 7th Sub Regional Science, College of Home Economics, University of Peshawar, and Technology Competition March, 2010</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Got <strong style="mso-bidi-font-weight: normal;">3rd Position</strong> in Category University, field Physics in <strong style="mso-bidi-font-weight: normal;">7th Sub Regional Science and Technology Competition </strong>29th January, 2009-2010.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Got <strong style="mso-bidi-font-weight: normal;">1st Position</strong> in Category University, field Chemistry in <strong style="mso-bidi-font-weight: normal;">7th Sub Regional Science and Technology Competition </strong>29th January, 2009-2010.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Declared <strong style="mso-bidi-font-weight: normal;">Winner and got a Gold Medal in Category University, field Chemistry in 2nd Final at Provincial level in Science and Technology Competition</strong> 3rd March, 2009-2010.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Declared <strong style="mso-bidi-font-weight: normal;">Winner and got a Shield in Category University, field Chemistry in Grand Finale in NWFP Science and Technology</strong> Competition 4th March, 2009-2010.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Participated in Chemistry Model Exhibition February 9th 2011, organized by Chemical Society of Institute of Chemical Sciences University of Peshawar, International year of Chemistry 2011 (Chemistry our life &ndash;our future)</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Participated in &ldquo;DISASTER PREPAREDNESS AND MANAGEMENT EXHIBITION-2011&rdquo; organized by Centre for Disaster Preparedness and Management, University of Peshawar, in collaboration with National Disaster Management Authority, Pakistan and United Nations Development Program- Pakistan April 20-21st, 2011.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Supervised Quiz &amp; Model Making Competition in WORLD SPACE WEEK-2011 held October 4-7th, 2011, University of Engineering and Technology, Peshawar.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Organized science exhibition at College of Home Economics, University of Peshawar, on January 12th, 2011.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l1 level1 lfo2;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Supervise Science Society of the students association for a science exhibition, quiz competition, essay writing competition and model making on January 5th ,2012</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Supervised a poster and model exhibition titled &ldquo;TRAVELLING Expo Chemistry in Relation To 2011: Year of Chemistry&rdquo; on 13th march, 2012 held at PIA Planetarium Hayatabad Peshawar.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Participated as Presenter, in 4th SPRING RESEARCH POSTER EXHIBITION organized by Institute of Chemical Sciences, University of Peshawar April 11th, 2013</p>
<p class="MsoListParagraphCxSpLast" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Co-organizer, Spring Research Poster Symposium, Held in April, 2016 , ICS, UOP</p>
<p class="MsoListParagraphCxSpLast" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Organize Provincial Mega Home science Event 2019 on january 24,2019 at College of Home Economics,UOP for the female sciences of KPK.</p>
<p class="MsoListParagraphCxSpLast" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&nbsp;</p></p><p align="right">,Participated,Organized, by: <a href="profile.php?id=16" class="text-info"><span class="text-info">Dr. Razia Tariq Khan</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Competitions</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>Editorships</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>Research Publications</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><div align="center">
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">&nbsp;</p>
</div></p><p align="right">,National,International,Conference Paper by: <a href="profile.php?id=16" class="text-info"><span class="text-info">Dr. Razia Tariq Khan</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><div align="center">
<ul>
<li>1</li>
</ul>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">I. Ahmad, S.M.Sohail,&nbsp; H. Khan,&nbsp; W. Ahmad K. Gul, <strong style="mso-bidi-font-weight: normal;">R. Khan, </strong>A. Yasin,Energy &amp; Fuels,ISSN:0887-0624 (print);1520-5029(web),W,32, 181&ndash;190."Study on Atmospheric Distillation of Some Plain and Chemically Dispersed Crude Oils: Comparison of Yields and Fuel Quality of Distillate Fractions",2018</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">2&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; I. Ahmad, J. Ullah,M. Ishaq, H. Khan,<strong>R. Khan,</strong> W.Ahmad K. Gul,Energy &amp; Fuels,ISSN:0887-0624 (print);1520-5029,(web),W,31 (7), 7653&ndash;7661.&nbsp;Oxidative Stability of Base Lubricant Oil Monitored by Gas Chromatography&ndash;Mass Spectrometry: Influence of Sawdust-Derived Antioxidants.&nbsp;2017</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">3&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;I.AhmadM. I Khan,H. Khan M. Ishaq,<strong>R. Khan,</strong>K. Gul,W. Ahmad,Journal of Analytical and Applied Pyrolysis,ISSN:0165-1370,W,126, 247-256,Influence of Waste Brick Kiln Dust on Pyrolytic Conversion of Polypropylene in To Potential Automotive Fuels.,2017</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">4&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;I. Ahmad,M. I Khan,H. Khan,M. Ishaq,<strong>R. Khan,</strong>K. Gul,W. Ahmad,Journal of Analytical and Applied Pyrolysis,ISSN:0165-2370,W,124, 195-203.Pyrolysis of HDPE into Fuel Like Products: Evaluating Catalytic Performance of Plain and Metal Oxides Impregnated Waste Brick Kiln Dust.2017</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">5&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;I. Ahmad,<strong>R. Khan,</strong>M. Ishaq,H. Khan,M. Ismail,K. Gul,W. Ahmad,Journal of Analytical and Applied Pyrolysis,ISSN:0165-2370,W,122, 131-141.Valorization of Spent Lubricant Engine Oil via Catalytic Pyrolysis: Influence of Barium-Strontium Ferrite on Product Distribution and Composition.&nbsp;2016</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">6&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;I. Ahmad, <strong>R. Khan,</strong> M. Ishaq, H. Khan, M. Ismail, K. Gul,W. Ahmad,Energy Fuels,ISSN:0887-0624 (print);1520-5029</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; text-align: justify; text-justify: inter-ideograph; line-height: normal; mso-layout-grid-align: none; text-autospace: none;">(web),W,30 (6), 4781&ndash;4789.Production of Lighter Fuels from Spent Lubricating Oil via Pyrolysis over Barium-Substituted Spinel Ferrite.2016</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">7&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;I. Ahmad,J. Ullah,M. Ishaq,H. Khan,<strong>R. Khan,</strong>W. Ahmad,K. Gul,Waste and Biomass Valorization,ISSN:1877-2641 (Print),1877-265X (Online),W,7(2),&nbsp;331&ndash;341.Characterizing Antioxidant Potential of Alcoholic Extracts of Rice Husk and Saw Dust for Oxidative Stability of Base Lubricating Oil Using Physico-chemical Properties.2016</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">8&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;I. Ahmad, <strong>R. Khan</strong>, M. Ishaq, H. Khan, M. Ismail,K. Gul,&nbsp;W. Ahmad,Energy Fuels,ISSN:0887-0624 (print);1520-5029,(web),W,30 (1), 204&ndash;218.,Catalytic Pyrolysis of Used Engine Oil over Coal Ash into Fuel-like Products.,2016</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">9&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<strong>R. Khan,</strong>I. Ahmad,H. Khan,M. Ismail,K. Gul,A. Yasin,W. Ahmad,Journal of Analytical and Applied Pyrolysis,ISSN:0165-2370,W,120, 493-500.Production of Diesel-Like Fuel from Spent Engine Oil by Catalytic Pyrolysis over Natural Magnetite.,2016</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">10&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;I. Ahmad, J. Ullah,M. Ishaq, H. Khan,<strong>R. Khan,</strong>W Ahmad,&nbsp; K. Gul,Energy Fuels,ISSN:0887-0624 (print);1520-5029,(web),W,29 (10), 6522&ndash;6528.,Oxidative Stability of the Plain and the Additized Mineral Base Oil Samples Monitored through GC-MS.,2015</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">11&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;I. Ahmad,M. I. Khan H. Khan, M. Ishaq, <strong>R. Tariq</strong>,K. Gul,W. Ahmad,International Journal of Green Energy, ISSN:1543-5075,W,12 (7) 663-671.,Pyrolysis Study of Polypropylene and Polyethylene into Premium Oil Products.,2014</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">12&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;M. I. Khan, I. Ahmad, H. Khan, M. Ishaq, <strong>R. Khan,</strong>K. Gul,W. Ahmad,Fullerenes Nanotubes and Carbon Nanostructures,ISSN:1536-383X,W,23, 627-639.Catalytic Performance of Metal Impregnated Carbon (Darco) in Conversion of Polypropylene and High-Density Polyethylene into Useful Products.,2014</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">13&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;I. Ahmad, M. I. Khan,H. Khan,M Ishaq,<strong>R. Tariq</strong>,K. Gul,W. Ahmad,Journal of Applied Polymer Science,ISSN:1097-4628,W,132 (1), 41221,(1 of 19).,Influence of metal oxide supported bentonites on the pyrolysis behavior of polypropylene and high‐density polyethylene.,2014&nbsp;</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">14&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;F. Shehzad, <strong>R. Khan,</strong>B. Ara and M.Muhammad,Res. Pak. J. Weed Sci,ISSN:1015-3055,Y,18(3):,265-275,Determination of Dinitroaniline Herbicide in Food Samples and Commercial Formulations using Spectrophotometric Methods.,2012</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">15&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<strong>R. khan</strong>, M. Tariq. A. Khan.Peshawar university Teachers Association Journal, (PUTAJ),ISSN: 1608-7925,Y,Vol. 12, Pp: 67-72.,Kinetic study of plasma cholinesterase in diseased blood and effects on antibiotics and pesticides on the enzyme.,2005.</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">16&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;A.Khan, Y.I.Khattak&nbsp; <strong>R.Khan</strong>.Pakistan Journal of Biological Sciences,ISSN, 1028-8880,X,2(3): 863-866,Preservation of potatoes nuclear techniques16.,1999.</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">17&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;A.Khan, Y.I.Khattak <strong>R.Khan.</strong>Pakistan Journal of Biological Sciences,ISSN, 1028-8880,X,2(3): 750-751,Extending the storage life of onions by Gamma Radiation.1999.</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">18&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<strong>R. khan</strong>,&nbsp; M. Tariq, A.Khan, Naheeda, S.F.,Mabood.Pakistan Journal of Biological Sciences,ISSN, 1028-8880,X,1(4): 386-388,Isolation and characterization of Acid phasphatase in Chickpea Seed (Cicer arietinum).1998.</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">19&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<strong>R. khan</strong>,&nbsp; M. Tariq,&nbsp; A. Khan, Naheeda&nbsp; S.F. Mabood.,Pakistan Journal of Biological Sciences,ISSN, 1028-8880,X,1(4): 366-388,Isolation and characterization of Acid phasphatase from wheat&nbsp; (Triticum aestivum).,1998.</p>
</div>
<p class="MsoNormal" style="text-align: justify; text-justify: inter-ideograph;"><strong style="mso-bidi-font-weight: normal;">RESEARCH CONDUCTED:</strong></p>
<p class="MsoListParagraphCxSpFirst" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Radiation Preservation of Food 1991</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; The effect of Gamma Radiation on the acid Phosphatase Kinetics in Chickpea (Cicer arietinum) 1992</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; An Analysis of school drinking water in the Rural Area of NWFP 2009</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Analysis of well water pollutants and their hazardous effect on the health of the people of NWFP 2009</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Investigation of pollutants in drinking water of schools in urban areas of District Peshawar 2009</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; The effect of stain removal agents on the tensile strength &amp; wash fastness of selected cotton fabrics 2005</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Effect of some disinfection treatment on the quality of potable water related to nitrite and nitrate contents 2009</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Evaluation of Drinking Water in Flood Effected Areas of District Charsadda and Nowshera 2012 by Saima Aslam</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Effects of early marriage on nutritional status of women in KP 2016 by Momina Tariq</p>
<p class="MsoListParagraphCxSpLast" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Two-stage Pyrolysis of Spent Lubricant Oil into Premium Fuels over Ferrites and Coal Ash as Heterogeneous Catalysts&nbsp; 2016</p>
<p class="MsoNormal" style="text-align: justify; text-justify: inter-ideograph;">&nbsp;</p>
<p class="DefaultStyle" style="margin-top: 12.0pt; margin-right: 0in; margin-bottom: .0001pt; margin-left: .5in; text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; line-height: 150%; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Contamination Load of Drinking Water in Different Hospitals of District Peshawar and Charsadda 2017 by Ayesha Omaima</p>
<p class="DefaultStyle" style="margin-left: .5in; text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; line-height: 150%; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Drinking Water Analysis of Different Public and Private Hostels of District Peshawar, Khyber Pakhtunkhwa 2017 by Safina Arbab</p>
<p class="MsoListParagraph" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; line-height: 150%; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; From Garbage to Biomaterial; Analysis of Phosphate in Eggshell and Soil 2017 by Azra Masood</p></p><p align="right">,National,, by: <a href="profile.php?id=16" class="text-info"><span class="text-info">Dr. Razia Tariq Khan</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>1. Nutrient composition phosphorus and phytate contents of different whole and decorticated varieties of pigeon pea(Cajanus Cajan) PUTAJ vol.11,2004.</p>
<p style="font-variant-ligatures: normal; font-variant-caps: normal; orphans: 2; text-align: start; widows: 2; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial; word-spacing: 0px;">2. Nutritional Status of school going girls of Peshawr N.W.F.P (Sarhad J. Agric.vol.20,No.3 2004).</p>
<p style="font-variant-ligatures: normal; font-variant-caps: normal; orphans: 2; text-align: start; widows: 2; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial; word-spacing: 0px;">3. Levels of TT4, TT3 and TSH in normal individual PUTAJ vol 12 2005.</p>
<p style="font-variant-ligatures: normal; font-variant-caps: normal; orphans: 2; text-align: start; widows: 2; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial; word-spacing: 0px;">4.&nbsp;Imaging prostate cancer(PCa) with [99mTc(CO)3] Finasteride dithiocarbamate(J Label compd Radiopharm.2018;1-7)</p></p><p align="right">,National,International, by: <a href="profile.php?id=28" class="text-info"><span class="text-info">Dr. Gul-e-Rana Jamil</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Memberships</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p class="MsoNormal" style="text-align: justify; text-justify: inter-ideograph;"><strong style="mso-bidi-font-weight: normal;">Convener/Member Committee(s) for Specified Assignments</strong></p>
<p class="MsoNormal" style="text-align: justify; text-justify: inter-ideograph;">Convener/Member of Various College Committees including Admission, Time Table, Staffroom, Canteen, Hygiene, Purchases, Photography, Conferences, Seminars, Discipline, Examination, etc.</p></p><p align="right"> by: <a href="profile.php?id=16" class="text-info"><span class="text-info">Dr. Razia Tariq Khan</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>HEC recognized supervisors</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>Visits organized</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>Achievements</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>Certificate courses offered</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>Social events</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>Educational trips</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>Awards</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p class="MsoNormal" style="text-align: justify; text-justify: inter-ideograph;"><strong style="mso-bidi-font-weight: normal;">DISTINCTIONS:</strong></p>
<p class="MsoListParagraphCxSpFirst" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Nominated for Book TITLED &ldquo;<strong style="mso-bidi-font-weight: normal;">GALAXIES OF WHO&rsquo;S WHO IN PAKISTAN-2011</strong>, a book of achievement &amp; A Model Seed-Bed for Human Resource Development, Category Women, Field Education, by South Asian Publication </p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong style="mso-bidi-font-weight: normal;">8th STAR WOMEN INTERNATIONAL AWARDS 1997, </strong>(An international award by South Asian Publication) in the Field of Education</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Got 1st Position in Category University, field Chemistry in 7th Sub Regional Science and Technology Competition 29th January, 2009-2010.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Declared Winner and got a <strong style="mso-bidi-font-weight: normal;">Gold Medal</strong> in Category University, field Chemistry in 2nd Final at Provincial level in Science and Technology Competition 3rd March, 2009-2010.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Declared Winner and got a Shield&nbsp; in Category University, field Chemistry in Grand Finale in NWFP Science and Technology Competition 4th&nbsp; March, 2009-2010.</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; First Position in all Pakistan basis in Pakistan Atomic Energy Commission Merit Scholarship in M.Sc Previous and Final</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Ph.D&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; GPA 4</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; M.Phil&nbsp; &nbsp;GPA 4</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; M.Sc Chemistry (Biochemistry) <strong style="mso-bidi-font-weight: normal;">Gold Medalist </strong>University of Peshawar 1991</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; B.Ed<strong style="mso-bidi-font-weight: normal;"> Gold Medalist </strong>University of Peshawar 1993</p>
<p class="MsoListParagraphCxSpMiddle" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; F.Sc Third Position in College, got a <strong style="mso-bidi-font-weight: normal;">pin of excellence in </strong>studies 1987</p>
<p class="MsoListParagraphCxSpLast" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Merit Scholarship in M.Sc Previous and Final University of Peshawar</p></p><p align="right"> by: <a href="profile.php?id=16" class="text-info"><span class="text-info">Dr. Razia Tariq Khan</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Talks</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>Book reviews</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p class="MsoNormal" style="text-align: justify; text-justify: inter-ideograph;"><strong style="mso-bidi-font-weight: normal;">BOOK:</strong></p>
<p class="MsoListParagraph" style="text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <strong style="mso-bidi-font-weight: normal;">&nbsp;Book published by Lambert Academic Press, Germany titled &ldquo;</strong> Two-Stage Pyrolysis of Spent Lubricant Oil into Premium Fuels&rdquo; in 2016 by Razia Khan</p></p><p align="right"> by: <a href="profile.php?id=16" class="text-info"><span class="text-info">Dr. Razia Tariq Khan</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Promotions</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>Study Leaves</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>Higher qualifications</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
                                
                            </div>

                        </div>
                        <div class="span3">
                            <h3>Announcements <a href="announcements.php" style="font-size:12px;">View All</a></h3>
                            <div id="news-container">
                            <ul class="list4 support-box">
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=209"><time datetime="2024-10-30">October 30, 2024</time></a>
                                        <div>Science Department, College of Home Econ...</div>
                                        <div><a href="show-event.php?id=209" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=208"><time datetime="2024-10-06">October 06, 2024</time></a>
                                        <div>Ms. Sidra Ali defended her research unde...</div>
                                        <div><a href="show-event.php?id=208" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=207"><time datetime="2024-09-11">September 11, 2024</time></a>
                                        <div>The entry test for MPhil/PhD programs in...</div>
                                        <div><a href="show-event.php?id=207" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                            </ul>
                            </div>
                            <h3>Upcoming Events <a href="upcoming-events.php" style="font-size:12px;">View All</a></h3>
                            <div id="news-container2">
                            <ul class="list4 support-box">
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=202"><time datetime="2024-03-03">March 03, 2024</time></a>
                                        <div>SPRING FIESTA, TUESDAY 5TH MARCH 2024....</div>
                                        <div><a href="show-event.php?id=202" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=201"><time datetime="2024-02-21">February 21, 2024</time></a>
                                        <div>A two day book fair was organized in col...</div>
                                        <div><a href="show-event.php?id=201" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=193"><time datetime="2023-10-04">October 04, 2023</time></a>
                                        <div>Newly admitted FSc students Orientation ...</div>
                                        <div><a href="show-event.php?id=193" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                            </ul>
                            </div>
                            
                        </div>                    </div>
                 </article>
            </div>
        </section>
    </div>
</div>
</div>
<!--footer-->
<footer>
    <div class="main">
        <div class="container">
            <div class="row">
                <article class="span12">
                    <p style="margin-top:20px;">College of Home Economics &copy; 2024. <a href="privacy-policy.php" title="Learn how we use your information">Privacy Policy</a></p>
                    <p align="right"><a style="display:none;" target="_blank" title="Site designed by SuperWebz.com" href="http://www.superwebz.com"><img src="img/superwebz_logo.jpg" alt="SuperWebz.com" /></a></p>
                </article>
            </div>
            <!-- {%FOOTER_LINK} -->
        </div>  
    </div> 
</footer><script type="text/javascript" src="js/bootstrap.js"></script>
<script>
    $('.list3 li a').hover(function(){
        $(this).stop().css({color:'#fc6f22'});	
        $(this).stop().parent().siblings('em').css({'background-position':'0 bottom'});	 
            }, function(){
        $(this).stop().css({color:'#1295d4'});	
        $(this).stop().parent().siblings('em').css({'background-position':'0 top'});						 
    })
    $('#search a').hover(function(){
        $(this).stop().animate({opacity:'0.5'});	
            }, function(){
       $(this).stop().animate({opacity:'1'});						 
    })
</script>

</body>
</html>
