<!DOCTYPE html>
<html lang="en">
<head>
<title>Textile & Clothing - College of Home Economics, University of Peshawar</title>
<meta charset="utf-8">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
<meta name = "format-detection" content = "telephone=no" />
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<!--CSS-->
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/camera.css">
<!--JS-->
<script src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery.vticker-min.js"></script>
<script src="js/jquery-migrate-1.1.1.js"></script>
<script src="js/superfish.js"></script>
<script src="js/jquery.mobilemenu.js"></script>
<script src="js/jquery.cookie.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.ui.totop.js"></script>
<script>	
	$(function(){
	$('#news-container').vTicker({ 
		speed: 500,
		pause: 5000,
		animation: 'fade',
		mousePause: true,
		showItems: 3
		});
	});
	
	$(function(){
	$('#news-container2').vTicker({ 
		speed: 500,
		pause: 5000,
		animation: 'fade',
		mousePause: true,
		showItems: 2
		});
	});
</script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
<script src="//code.jquery.com/ui/1.11.2/jquery-ui.js"></script>
<script>
$(function() {
$( "#accordion" ).accordion({
collapsible: true,
active: false,
heightStyle: "content"
});
});
</script>
<!--[if lt IE 8]>
		<div style='text-align:center'><a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/img/upgrade.jpg"border="0"alt=""/></a></div>  
<![endif]-->
<!--[if lt IE 9]>
  <link rel="stylesheet" href="css/ie.css">
  <link rel="stylesheet" href="css/docs.css">
  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body>
<div class="global">
<!--header-->
<header>
    <div class="main">
        <div class="gradient">
        <div class="container">
             <article>
                <div class="navbar navbar_ clearfix">
                    <div class="navbar-inner">      
                          <div class="clearfix">
                                <div class="nav-collapse nav-collapse_">
                                	<ul class="nav sf-menu clearfix">
                                	  <li><a href="index.php">Home</a></li>
                                      <li class="sub-menu"><a href="#">About</a>
                                        <ul>
                                            <li><a href="che-history.php">Brief History</a></li>
                                            <li><a href="leadership.php">Leadership</a></li>
                                            <li><a href="foundation-faculty.php">Foundation Faculty</a></li>
                                            <li><a href="contact-us.php">Contact Us</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Programs</a>
                                        <ul>
                                            <li><a href="art-design-introduction.php">Art & Design</a></li>
                                            <li><a href="food-nutrition-sciences-introduction.php">Food & Nutrition Sciences</a></li>
                                            <li><a href="human-development-family-studies-introduction.php">Human Development &amp; Family Studies</a></li>
                                            <li><a href="resource-facility-management-introduction.php">Resource &amp; Facility Management</a></li>
                                            <li><a href="textile-clothing-introduction.php">Textile & Clothing</a></li>
                                            <li><a href="#">Mandatory Supportive<span></span></a>
                                              <ul>
                                             <li><a href="computer-science-introduction.php">Computer Science</a></li>
                                              <li><a href="english-introduction.php">English</a></li>
                                              <li><a href="pak-studies-introduction.php">Pak. Studies</a></li>

                                              <li><a href="science-introduction.php">Science Department</a></li>
                                              <li><a href="urdu-islamiyat-introduction.php">Urdu / Islamiyat</a></li>
                                              </ul>
                                            </li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Admissions</a>
                                        <ul>
                                          <li><a href="bsc.php">BS Public Health<span></span></a>
                                        	<ul>
                                              <li><a href="bsc-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="bsc-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="bsc-uniform.php">Uniform</a></li>
                                              <li><a href="bsc-merit-list.php">Merit List</a></li>
                                              <li><a href="bsc-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="fsc.php">F.A/ F.Sc.<span></span></a>
                                        	<ul>
                                              <li><a href="fsc-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="fsc-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="fsc-uniform.php">Uniform</a></li>
                                              <li><a href="fsc-merit-list.php">Merit List</a></li>
                                              <li><a href="fsc-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="bs-hons.php">B.S Home Economics<span></span></a>
                                        	<ul>
                                              <li><a href="bs-hons-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="bs-hons-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="bs-hons-uniform.php">Uniform</a></li>
                                              <li><a href="bs-hons-merit-list.php">Merit List</a></li>
                                              <li><a href="bs-hons-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="msc.php">BS Human Nutrition & Dietetics<span></span></a>
                                        	<ul>
                                              <li><a href="msc-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="msc-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="msc-uniform.php">Uniform</a></li>
                                              <li><a href="msc-merit-list.php">Merit List</a></li>
                                              <li><a href="msc-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="mphil.php">M.Phil<span></span></a>
                                        	<ul>
                                              <li><a href="mphil-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="mphil-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="mphil-uniform.php">Uniform</a></li>
                                              <li><a href="mphil-merit-list.php">Merit List</a></li>
                                              <li><a href="mphil-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="phd.php">Ph.D<span></span></a>
                                        	<ul>
                                              <li><a href="phd-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="phd-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="phd-uniform.php">Uniform</a></li>
                                              <li><a href="phd-merit-list.php">Merit List</a></li>
                                              <li><a href="phd-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Examination</a>
                                        <ul>
                                          <li><a href="examination-rules.php">Rules</a></li>
                                          <li><a href="datesheet.php">Date Sheet</a></li>
                                          <li><a href="results.php">Results</a></li>
                                          <li><a href="convocation.php">Convocation</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="college-faculty.php">Faculty</a>
                                        <ul>
                                          <li><a href="faculty-art-and-design.php">Art & Design</a></li>
                                          <li><a href="faculty-food-and-nutrition-sciences.php">Food & Nutrition Sciences</a></li>
                                          <li><a href="faculty-human-development-and-family-studies.php">Human Development and Family Studies</a></li>
                                          <li><a href="faculty-resource-and-facility-management.php">Resource and Facility Management</a></li>
                                          <li><a href="faculty-textile-and-clothing.php">Textile & Clothing</a></li>
                                          <li><a href="faculty-science.php">Science</a></li>
                                          <li><a href="faculty-computer-studies.php">Computer Studies</a></li>
                                          <li><a href="faculty-english.php">English</a></li>
                                          <li><a href="faculty-pak-studies.php">Pak. Studies</a></li>
                                          <li><a href="faculty-urdu.php">Urdu</a></li>
                                          <li><a href="faculty-islamiyat.php">Islamiyat</a></li>
                                          <li><a href="faculty-login.php">Faculty Login</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Student's Life</a>
                                        <ul>
                                          <li><a href="students-societies.php">Student Societies</a></li>
                                          <li><a href="students-society-members.php">Society Members</a></li>
                                          <li><a href="students-academic-visits.php">Academic Visits</a></li>
                                          <li><a href="students-recreational-trips.php">Recreational Trips</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Facilities</a>
                                        <ul>
                                  <li><a href="facilities-bookshop.php">Bookshop</a></li>                                          <li><a href="facilities-canteen.php">Canteen</a></li>

                                          <li><a href="facilities-daycare.php">Day Care</a></li>                                          <li><a href="facilities-first-aid-room.php">First Aid Room</a></li>

                                          <li><a href="facilities-generators.php">Generators</a></li>
                                                                                                                   <li><a href="facilities-home-management-residence.php">Home Management Residence</a></li>
        <li><a href="facilities-hostel.php">Hostel</a></li>
   <li><a href="facilities-internet.php">Internet</a></li>

                                          <li><a href="facilities-library.php">Library</a></li>
                                                                              <li><a href="facilities-mosque.php">Mosque</a></li>
                                          <li><a href="facilities-nursery.php">Nursery</a></li>
                                        <li><a href="facilities-photocopier.php">Photocopier</a></li>

                                          <li><a href="facilities-playgroup.php">Play Group</a></li>
                                            <li><a href="facilities-preplaygroup.php">Pre Play Group</a></li>      
                                          <li><a href="facilities-transport.php">Transport</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="alumni-list.php">PFHE</a>
                                        <ul>
                                          <li><a href="pfhe.php">Introduction</a></li>
                                          <li><a href="alumni-profile.php">Members Profile</a></li>
                                          <li><a href="alumni-list.php">Federation & Alumni Members</a></li>
                                        </ul>
  </li>
                                      <li class="sub-menu"><a href="#">JHEBS</a>
                                        <ul><li><a href="jhebs-call-for-papers.php">Call for Papers</a></li>
                                          <li><a href="jhebs-published-versions.php">Published Versions</a></li>
                                          <li><a href="jhebs-research.php">Research</a></li>
                                          <li><a href="jhebs-rules.php">Rules</a></li>
                                                                                    <li><a href="jhebs-updates.php">Updates</a></li>

                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Conference</a>
                                        <ul>
                                          <li><a href="conference-call-for-papers.php">Call For Papers</a></li>
										  <li><a href="conference-accepted-papers.php">Accepted Papers</a></li>
										  <li><a href="conference-registration-and-payment.php">Registration and Payment</a></li>
										  <li><a href="conference-important-dates.php">Important Dates</a></li>
										  <li><a href="conference-keynote-speaker.php">Keynote Speaker</a></li>
										  <li><a href="conference-committee.php">Committee</a></li>
										  <li><a href="conference-abstract-submission.php">Abstract Submission</a></li>
										  <li><a href="conference-topics.php">Conference Topics</a></li>
										  <li><a href="conference-presentation-instructions.php">Presentation Instructions</a></li>
										  <li><a href="conference-who-should-attend.php">Who should Attend</a></li>
										  <li><a href="conference-tentative-programme.php">Tentative Programme</a></li>
										  <li><a href="conference-venue.php">Venue</a></li>
										  <li><a href="conference-final-paper-submission.php">Final Paper Submission</a></li>
										  <li><a href="conference-paper-templates.php">Paper Templates</a></li>
										  <li><a href="conference-accommodation-and-travel.php">Accommodation & Travel</a></li>
										  <li><a href="conference-conference-poster.php">Conference Poster</a></li>
										  <li><a href="contact-us.php">Contact Us</a></li>
                                        </ul>
                                      </li>
									  <li class="sub-menu"><a href="#">Activities</a>
                                        <ul>                                          <li><a href="college-magazine.php">College Magazine</a></li>
                                          <li><a href="activities-exhibitions.php">Exhibitions</a></li>
                                          <li><a href="activities-internships.php">Internships</a></li>
                                          <li><a href="activities-lectures.php">Lectures</a></li>
                                          <li><a href="newsletter.php">Newsletter</a></li>                                          <li><a href="activities-seminars.php">Seminars</a></li>

                                          <li><a href="activities-sports.php">Sports</a></li>
                                                                                 <li><a href="activities-tutorials.php">Tutorials</a></li>
   <li><a href="activities-workshops.php">Workshops</a></li>
                                        </ul>
                                      </li>
                                    </ul>
                                 </div>
                                 <ul class="follow_icon">
                                    <li><a href="https://www.facebook.com/CHEUOP/"><img src="img/follow_icon2.png" alt=""></a></li>                                                                    </ul>                          </div>
                    </div>
                </div>
                <h1 class="brand"><a href="index.php"><img src="img/logo.png" alt=""></a></h1>
                <form id="search" class="search" action="search-results.php" method="GET" accept-charset="utf-8">
                	 <input type="text" onFocus="if(this.value =='Search for...' ) this.value=''" onBlur="if(this.value=='') this.value='Search for...'" value="Search for..." name="q">
                     <a href="#" onClick="document.getElementById('search').submit()"><img src="img/magnify.png" alt=""></a>
                </form>             </article>
        </div>
        </div>
    </div>
</header>

<div class="main">
    <div class="gradient1">
        <section class="container">
            <div class="row">
                <article class="span12 margBot6">
                    <div class="row">
                        <div class="span3 support-box">
                            <h3>Program Links</h3>
                            <ul class="list3">
                                <li><em></em><p><a href="textile-clothing-introduction.php">Introduction</a></p></li>
                                <li><em></em><p><a href="textile-clothing.php">Department Highlights</a></p></li>
                                <li><em></em><p><a href="textile-clothing-faculty.php">Faculty</a></p></li>
                                <li><em></em><p><a href="textile-clothing-department-pictures.php">Department Pictures</a></p></li>
                                <li><em></em><p><a href="textile-clothing-scheme-of-study.php">Scheme of Study</a></p></li>
                                <li><em></em><p><a href="textile-clothing-research-publications.php">Research Publications</a></p></li>
                                
                            </ul>
                        </div>
                        <div class="span6 support-box">
                            <h3>Textile & Clothing > Department Highlights</h3>

                            <div id="accordion">
							
                                <h3>Workshops</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p></p>
<p class="15" style="margin-left: 11.2000pt; mso-para-margin-left: 0.0000gd; text-indent: -18.0000pt; text-align: justify; text-justify: inter-ideograph; mso-list: l0 level1 lfo1;" align="justify">1.&nbsp;Moderator in panel discussion in Second National Home Economics Conference &amp; First National Home Economics Art Exhibition May 21st to 24th, 2017.</p>
<p class="15" style="margin-left: 11.2000pt; mso-para-margin-left: 0.0000gd; text-indent: -18.0000pt; text-align: justify; text-justify: inter-ideograph; mso-list: l0 level1 lfo1;" align="justify">2.&nbsp;First National Conference on Home Economics organized by HEC June 3rd to 4th, 2014.</p>
<p class="15" style="margin-left: 11.2000pt; mso-para-margin-left: 0.0000gd; text-indent: -18.0000pt; text-align: justify; text-justify: inter-ideograph; mso-list: l0 level1 lfo1;" align="justify">3.&nbsp;Project Management &amp; Proposal Writing organized by HEC Pakistan October, 21st to 31st, 2013.</p>
<p class="15" style="margin-left: 11.2000pt; mso-para-margin-left: 0.0000gd; text-indent: -18.0000pt; text-align: justify; text-justify: inter-ideograph; mso-list: l0 level1 lfo1;" align="justify">4.&nbsp;International Conference organized by HEC Pakistan on The Latest Archaeological investigations in Pakistan held from November 13th to 15th, 2012 at Department of Archaeology University of Peshawar </p>
<p class="15" style="margin-left: 11.2000pt; mso-para-margin-left: 0.0000gd; text-indent: -18.0000pt; text-align: justify; text-justify: inter-ideograph; mso-list: l0 level1 lfo1;" align="justify">5.&nbsp;Project Proposal &amp; Project Cycle Management organized by HEC Pakistan December, 15th to 20th 2008.</p>
<p class="15" style="margin-left: 11.2000pt; mso-para-margin-left: 0.0000gd; text-indent: -18.0000pt; text-align: justify; text-justify: inter-ideograph; mso-list: l0 level1 lfo1;" align="justify">6.&nbsp;As a resource person in Four days workshop on handloom weaving organized by AHAN KPK June 25th to 28th. 2007.</p>
<p class="15" style="margin-left: 11.2000pt; mso-para-margin-left: 0.0000gd; text-indent: -18.0000pt; text-align: justify; text-justify: inter-ideograph; mso-list: l0 level1 lfo1;" align="justify">7.&nbsp;Science &amp; Cultural Fair held at Edwards College Peshawar February 7th -8th, 2003</p>
<p class="15" style="margin-left: 11.2000pt; mso-para-margin-left: 0.0000gd; text-indent: -18.0000pt; text-align: justify; text-justify: inter-ideograph; mso-list: l0 level1 lfo1;" align="justify">8.&nbsp;Certificate course on Factors Governing the Fashion Scene held at Asian Institute of Fashion Design, Iqra University Karachi May 20th to July 20th, 2002.</p>
<p class="15" style="margin-bottom: 8.0000pt; margin-left: 11.2000pt; mso-para-margin-left: 0.0000gd; text-indent: -18.0000pt; text-align: justify; text-justify: inter-ideograph; mso-list: l0 level1 lfo1;" align="justify">9.&nbsp;Resource Person in Workshop on Hand Loom Weaving organized by AHAN-KP.</p></p><p align="right">,Participated,,Attended by: <a href="profile.php?id=14" class="text-info"><span class="text-info">Dr. Faiza Tauqeer</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><div style="mso-element: para-border-div; border: none; border-bottom: double #943634 3.0pt; mso-border-bottom-alt: thin-thick-small-gap #943634 3.0pt; padding: 0in 0in 1.0pt 0in;">
<div style="mso-element: para-border-div; border: none; border-bottom: double #943634 3.0pt; mso-border-bottom-alt: thin-thick-small-gap #943634 3.0pt; padding: 0in 0in 1.0pt 0in;">
<p class="MsoNormal" style="margin-top: 20.0pt; margin-right: 0in; margin-bottom: 10.0pt; margin-left: 0in; text-align: center; line-height: 105%; mso-outline-level: 1; border: none; mso-border-bottom-alt: thin-thick-small-gap #943634 3.0pt; padding: 0in; mso-padding-alt: 0in 0in 1.0pt 0in;" align="center"><strong style="mso-bidi-font-weight: normal;">Seminars/Workshops/Administrative Experience</strong>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</p>
</div>
<div style="mso-element: para-border-div; border: none; border-bottom: double #943634 3.0pt; mso-border-bottom-alt: thin-thick-small-gap #943634 3.0pt; padding: 0in 0in 1.0pt 0in;">
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">2003&ndash;2006&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">Member Senate, University of Peshawar</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">2009&ndash; 2018</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">Incharge/Head department of Textiles &amp; Clothing.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">2006 till date</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">Incharge examination annual B.Sc. Home Economic and M.Sc. Home Economics.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">05.2007- 05.2010</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">Vice Principal academics, College of Home Economics, University of Peshawar.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">2013- 2015</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">Subject specialist of Textile and Clothing for selection board College of Home Sciences, University of Swat.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">2015- 2018</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">Subject specialist of Home Economics, and Textiles and Clothing Khyber Pakhtunkhwa Public Service Commission, Peshawar.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">2015 till date</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">Member, advisory committee for curriculum and Examination, Board of Intermediate and Secondary Education, Peshawar</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">2015- 2022</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">Coordinator, M.Phil and Ph.D. program of the College.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">2015- 2018</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">Non&ndash; resident warden of Fatimah Jinnah Girls Hostel.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">2015- 2018</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">Non&ndash; resident warden of Tatara Girls Hostel.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">2016- 2018</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">Organizer of the College Alumni Grand re union.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">2016- 2018</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">Focal person to University of Peshawar Alumni Association.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">2015- 2022</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">Incharge Academics of the College.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">2015- 2018</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">Member Purchase Committee of the College.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">2011</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">Participated in the 2nd meeting (NCRC, 2011) of HEC Curriculum Revision for Home Economics in Lahore. Member from Clothing and Textile Department for BS Syllabus.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">2016- 2021</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">Member Board of Studies, Department of Art and Design, Shaheed Benazir Bhutto Women University, Peshawar.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">06. 2016</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">Participated in NCRC meeting of HEC in 2016 for Home Economics in Peshawar as member from Clothing and Textiles.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">2015- 2017</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">Member Graduate Studies Committee of the College.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">2017- Jan. 2024</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">Member Graduate Studies Committee of the College.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">2017- Jan. 2024</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">Member ASRB Sub- committee Faculty of management &amp; Information Sciences, UoP.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">22.7.2022- 30th Jan. 2024</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">Principal, College of Home Economics, UoP</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">March 2024 till date</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">Member of curriculum and syllabi review committees CSRC for BS courses across HEIS of Khyber Pakhtunkhwa.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">May 2024 till date</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">Member Board of Studies, Department of Art and Design, Sarhad University of Science &amp; Technology, Peshawar.</p>
<p class="MsoNormal" style="margin-top: 20.0pt; margin-right: 0in; margin-bottom: 10.0pt; margin-left: 0in; text-align: center; line-height: 115%; mso-outline-level: 1; border: none; mso-border-bottom-alt: thin-thick-small-gap #943634 3.0pt; padding: 0in; mso-padding-alt: 0in 0in 1.0pt 0in;" align="center"><strong>formal trainings</strong></p>
</div>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">05- 22. 06.1987</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">Workshop on Textile Design and Technology: Resource person was Professor Michael Hann PhD (Leeds) School of Design, University of Leeds, UK.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">06. 1990- 05.1991</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">One-year course of in&ndash;service teachers training at STI, Staff Training Institute, University of Peshawar.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">17- 22. 04. 1993</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">Maintenance of PC hardware. National Academy of Higher Education, University Grants Commission, Pakistan.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">07.18- 08.11.2005</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: normal;">Staff Development Course, Higher Education Commission, Pakistan.&nbsp;&nbsp;</p>
</div></p><p align="right">,Participated,,Attended by: <a href="profile.php?id=9" class="text-info"><span class="text-info">Prof. Dr. Shahnaz Khattak</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Workshops</p>
<ul>
<li>Participated in the workshop on &ldquo;Spring Garment Festival 2004&rdquo; organized by an NGO &lsquo;The Laas Gul&rsquo; and the students of M.Sc. Final, Department of Textiles &amp; Clothing, College of Home Economics, University of Peshawar</li>
<li>Attended a 3-Day workshop on Exploring Opportunities For Ph.D &amp;Post Docs in Foreign Universities ,held at Frontier University, Peshawarat from 21-23 May, 2006 in collaboration with organized by Higher Education Commission.</li>
<li>Attended a 6-Day Training workshop on Project Proposal/PC-I&amp;Project Cycle Management, held at College of Home Economics, University of Peshawar form December 15-20,2008,organized by Learning Innovation, Higher Education Commission, Islamabad, Pakistan.</li>
</ul></p><p align="right">,Participated,, by: <a href="profile.php?id=12" class="text-info"><span class="text-info">Dr. Shabana Sajjad</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><ol>
<li>As Resource Person for Hand Loom Weaving organized by AHAN KPK</li>
<li></li>
</ol></p><p align="right">,Participated,, by: <a href="profile.php?id=14" class="text-info"><span class="text-info">Dr. Faiza Tauqeer</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Title:&nbsp;Where Government &amp; Academia Meet<br /> Date: 2008<br /> Venue: University Town<br /> Organization:Directorate of Science &amp; Technology, Peshawar</p>
<p class="MsoNormal" style="margin-left: 70.9pt; text-indent: -70.9pt;">&nbsp;</p></p><p align="right">,,,Attended by: <a href="profile.php?id=31" class="text-info"><span class="text-info">Ms. Faryal Yousaf</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Conferences</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p></p>
<p class="15" style="margin-left: 14.4500pt; mso-para-margin-left: 0.0000gd; text-indent: -18.0000pt; text-align: justify; text-justify: inter-ideograph; mso-list: l0 level2 lfo1;" align="justify">1.&nbsp;1st National Conference on Home Economics, organized by HEC Pakistan</p>
<p class="15" style="margin-left: 14.4500pt; mso-para-margin-left: 0.0000gd; text-indent: -18.0000pt; text-align: justify; text-justify: inter-ideograph; mso-list: l0 level2 lfo1;" align="justify">2.&nbsp;The Latest Archaeological Investigations in Pakistan, organized by HEC Pakistan</p></p><p align="right">,,,Attended by: <a href="profile.php?id=14" class="text-info"><span class="text-info">Dr. Faiza Tauqeer</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><ul>
<li>Represented the Textiles &amp; Clothing department College of Home Economics, University of Peshawar, in an International Textile Conference on &ldquo;How to survive recession&rdquo; at Avari Hotel,Lahore from 21&ndash;22 April,1995</li>
<li>Participated in First National Home Economics Conference, held on 3rd&amp; 4th June.2014 at Baragali Campus, University of Peshawar.</li>
<li>Presented a Paper on "Assessment of Pilling Characteristics of Post and Concurrent Pigment Dyed and Finiished P/C Fabrics" in 2nd iternational Home Economics conference, held in May21-24,2017, at Baragali Summer campus,University of Peshawar.</li>
<li>Member scientific committee in 2nd National Home Economics conference.</li>
</ul></p><p align="right">,Participated,, by: <a href="profile.php?id=12" class="text-info"><span class="text-info">Dr. Shabana Sajjad</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><ol>
<li>&nbsp; &nbsp;Along with other committee members organized First National Conference, &lsquo;Home Economics: Exploring New Horizon, at Baragali Campus on 3rd and 4th June,2014.</li>
<li>&nbsp;Participated and presented paper at First National Conference, &lsquo;Home Economics: Exploring New Horizon, at Baragali Campus on 3rd and 4th June,2014.</li>
<li>Participated in poster presentation at First National Conference, &lsquo;Home Economics: Exploring New Horizon, at Baragali Campus on 3rd and 4th June,2014.</li>
</ol>
<p>&nbsp;</p></p><p align="right">,Participated,Organized, by: <a href="profile.php?id=31" class="text-info"><span class="text-info">Ms. Faryal Yousaf</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Seminars</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><ul>
<li>
<p style="margin: 6pt 0.5in 6pt -4.5pt; text-align: justify;">Attended one day Seminar on &ldquo;Interfaith Women Peace Building network&rdquo; on 30-11.2015, organized by the Institute of Peace and Conflict Studies, UOP in collaboration with Peace Education and Development Foundation (PEAD).</p>
</li>
<li>Represented the College of Home Economics, University of Peshawar, as a member in a Seminar organized by PUTA in1994 at Baragali campus</li>
<li>Participated in Science&amp; Cultural Fair organized by Science &amp; Cultural Society, Edwards College, Peshawar held on 25th to 26th Jan,1995</li>
<li>
<p style="background: white; margin: 0in 0in 0pt; line-height: normal;">One day seminar on &ldquo;Humanitarianism in Pakistan&rdquo;,Tuesday ,9th jan,2018 at Teacher&rsquo;s community centre,PUTA,University of Peshawar.</p>
</li>
</ul></p><p align="right">,Participated,, by: <a href="profile.php?id=12" class="text-info"><span class="text-info">Dr. Shabana Sajjad</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Organized a lecture/presentation &nbsp;for staff and students of M.sc, dept. of Textiles &amp; Clotihng and Foods&amp; Nutritioon on "Diet, No Pills is the future"&nbsp;on 8th&nbsp;May 2017. The speakers were students of &nbsp;KMC,Peshawar.</p></p><p align="right">,,Organized, by: <a href="profile.php?id=12" class="text-info"><span class="text-info">Dr. Shabana Sajjad</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p class="MsoNormal" style="margin-left: 70.9pt; text-indent: -70.9pt;">2009&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Organized a Seminar on &ldquo;Acne and Hirsuitism&rdquo; and &ldquo;Infertility&rdquo; sponsored by Bayer Company at College of Home Economics, UOP</p>
<p>&nbsp;</p>
<p class="MsoNormal" style="margin-left: 70.9pt; text-indent: -70.9pt;">2009&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Organized a Seminar on &ldquo;Opportunities for Scholarships &amp; Higher Studies&rdquo;, sponsored by British Council&nbsp;at College of Home Economics, UOP</p>
<p>&nbsp;</p></p><p align="right">,,Organized, by: <a href="profile.php?id=31" class="text-info"><span class="text-info">Ms. Faryal Yousaf</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Extension Lectures</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>Trainings</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                           <p style="color:#333333;font-weight:normal;"><ul>
	<li>2-Day BLS and First-Aid training, organized by Capacity Building of Youth on first-aid, Rescue 1122 at CHE on May 2015.</li>
</ul></p><p align="right">Attended by: <a href="profile.php?id=12" class="text-info"><span class="text-info">Dr. Shabana Sajjad</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Exhibitions</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>2009&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Organized an Exhibition of Textile Designing at &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; College of Home Economics, UOP in College Hall</p>
<p class="MsoNormal" style="margin-left: 70.9pt; text-indent: -70.9pt;">2010&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Organized an Exhibition of Textile Designing at College of Home Economics, UOP&nbsp;in College Hall</p>
<p class="MsoNormal" style="margin-left: 70.9pt; text-indent: -70.9pt;">2011&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Organized an Exhibition of Textile Designing at College of Home Economics, UOP&nbsp;in College Hall</p>
<p class="MsoNormal" style="margin-left: 70.9pt; text-indent: -70.9pt;">2012&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Organized an Exhibition of Textile Designing at College of Home Economics, UOP&nbsp;in College Hall</p></p><p align="right">,,Organized, by: <a href="profile.php?id=31" class="text-info"><span class="text-info">Ms. Faryal Yousaf</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Competitions</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>Editorships</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>Research Publications</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p style="margin: 0in 0in 8pt -4.5pt; text-align: justify; line-height: normal;"><strong style="mso-bidi-font-weight: normal;">Publications : National/International</strong></p>
<p style="margin: 0in 0in 8pt -4.5pt; text-align: justify; line-height: normal;">1. Analysis Study of Pakistan and Foreign Made Wool and Wool Blended Fabrics-I, <strong style="mso-bidi-font-weight: normal;">Shabana Rafique,</strong>Shahnaz Parveen Khattak, Amir Muhammad Khan. <em style="mso-bidi-font-style: normal;">Journal of Engineering and Applied Sc.</em> Vol 13 (1994) No. 2:109 -112.</p>
<p style="margin: 0in 0in 8pt -4.5pt; text-align: justify; line-height: normal;">2. Analysis Study of Pakistan and foreign Made Woolen and Wool Blended Fabrics-II. Quality Characteristics of Yarns,<strong style="mso-bidi-font-weight: normal;"> Shabana Rafique</strong>, Shahnaz Parveen Khattak, Amir Muhammad Khan. <em style="mso-bidi-font-style: normal;">Journal of Engineering &amp; Applied Science.</em> Vol, 14.No.59 (1995)141-145.</p>
<p style="margin: 0in 0in 8pt -4.5pt; text-align: justify; line-height: normal;">3. A Comparative Study on the Abrasion resistance of Selected Upholstery Fabrics. Khalida Perveen, <strong style="mso-bidi-font-weight: normal;">Shabana Rafique</strong>. PUTAJ. Vol 10(2003) 99-106</p>
<p style="margin: 0in 0in 8pt -4.5pt; text-align: justify; line-height: normal;">4.&nbsp; A Comparative Study on the Durability of Pakistan &amp; Foreign made Wool and Wool Blended Fabrics.<strong style="mso-bidi-font-weight: normal;"> Shabana Rafique</strong>, Shahnaz Parveen Khattak<strong style="mso-bidi-font-weight: normal;">,</strong> Sabiha Zafar,<em style="mso-bidi-font-style: normal;">Sarhad Journal of Agriculture</em>, Vol, 14, No. 5(1998) 501-507.</p>
<p style="margin: 0in 0in 8pt -4.5pt; text-align: justify; line-height: normal;">5. A Comparative Study on the Effects of Various Washing Powders on the Dimensional&nbsp; Stability of Cotton Fabrics-I, Hina Shiraz,<strong style="mso-bidi-font-weight: normal;"> Shabana Sajjad</strong>, Shahnaz Parveen Khattak, PUTAJ Science, UOP, Vol 13(2006)103-109</p>
<p style="margin: 0in 0in 8pt -4.5pt; text-align: justify; line-height: normal;">6. A Comparative Study on the Effects of Various Washing Powders on the Abrasion Resistance of Polyester/Cotton Blends, Faryal Yousaf, Shahnaz Parveen Khattak, <strong style="mso-bidi-font-weight: normal;">Shabana Sajjad</strong> PUTAJ Science, UOP. Vol 13(2006) 95-101</p>
<p style="margin: 0in 0in 8pt -4.5pt; text-align: justify; line-height: normal; tab-stops: 391.5pt 5.5in 409.5pt;">7. Impact of Functional Finishes on the Tensile and Tear Strength Properties of Pigment Dyed P/C Fabrics by Post and Meta-Finishing Modes of Application. <strong style="mso-bidi-font-weight: normal;">Shabana Rafique</strong>, Shahnaz Parveen Khattak, Bashir Ahmad and Tanveer Hussain, Faiza Tauqeer.&nbsp; <em style="mso-bidi-font-style: normal;">Journal of Science &amp; Technology</em> Vol. 37, No. 2. (2013)71-83</p>
<p style="margin: 0in 0in 8pt -4.5pt; text-align: justify; line-height: normal; tab-stops: 391.5pt 5.5in 409.5pt;">8. Usage and Symbolism of Colour Schemes: A case Study of Pottery of Gandi Umar Khan. Zil-e-Huma Mujeeb, Zakirullah Jan and <strong style="mso-bidi-font-weight: normal;">Shabana&nbsp; Rafique</strong>. <em style="mso-bidi-font-style: normal;">Pakistan Heritage</em>, Vol 5.(2013) 11-14</p>
<p style="margin: 0in 5.85pt 8pt -4.5pt; text-align: justify; line-height: normal; tab-stops: 5.05in 391.5pt 5.5in 409.5pt;">9. Pigment Dyeing and Finishing of Cotton /Polyester Fabrics with a Modified Dihydroxyethyleneurea and various Softeners.<strong style="mso-bidi-font-weight: normal;">Shabana Rafique</strong>, Shahnaz Parveen, Bashir Ahmad and Tanveer Hussain. <em style="mso-bidi-font-style: normal;">Life Science Journal</em> Vol. 11, No. 5. (2014).165-174</p>
<p style="margin: 0in 5.85pt 8pt -4.5pt; text-align: justify; line-height: normal; tab-stops: 5.05in 391.5pt 5.5in 409.5pt;">10. Optimization of Fastness and Tensile Properties of Cotton Fabric Dyed with Natural Extracts of Marigold Flower (Tagetes erecta) by Pad-Steam Method. Shahnaz Parveen Khattak, <strong>Shabana Rafique</strong>, Tanveer Hussain and Bashir Ahmad. <em style="mso-bidi-font-style: normal;">Life Science Journal</em> Vol. 11, No. 7s.(2014) 52-60.</p>
<p style="margin: 0in 5.85pt 8pt -4.5pt; text-align: justify; line-height: normal; tab-stops: 5.05in 391.5pt 5.5in 409.5pt;">11. Evaluation of fastness and tensile properties of cotton fabric dyed with root extracts of Accasia Catechu by pad-steam procedure.Shahnaz Parveen Khattak, <strong>Shabana Rafique</strong>, Tanveer Hussain and Bashir Ahmad. <em style="mso-bidi-font-style: normal;">Life Science Journal</em> Vol. 37, No.2.(2014) 59-69.</p>
<p style="margin: 0in 5.85pt 8pt -4.5pt; text-align: justify; line-height: normal; tab-stops: 5.05in 391.5pt 5.5in 409.5pt;">12. Strength analysis of one-step pigment dyeing anddurable press finishing of polyeater/cotton blended sheeting fabrics with various crosslinking agents. <strong style="mso-bidi-font-weight: normal;">Shabana Rafique</strong>,Shahnaz Parveen Khattak, Bashir Ahmadand, Tanveer Hussain,Farhat Shahzad..<em style="mso-bidi-font-style: normal;">Journal of Science &amp; Technology</em> Vol. 38, No. 1.(2014)31-39.</p>
<p style="margin: 0in 5.85pt 8pt -4.5pt; text-align: justify; line-height: normal; tab-stops: 5.05in 391.5pt 5.5in 409.5pt;">13. Colour Fastness Properties of Polyester/Cotton Fabrics Treated with Pigment Orange and Various Functional Finishes. <strong style="mso-bidi-font-weight: normal;">Shabana Rafique</strong>, Shahnaz Parveen Khattak, Tanveer Hussain, Bashir Ahmad, Imrana Seemi. <em style="mso-bidi-font-style: normal;">Asian Journal of Chemistry</em> Vol. 27, No. 12. (2015). 4568-4574.</p>
<p style="margin: 0in 5.85pt 8pt -4.5pt; text-align: justify; line-height: normal; tab-stops: 5.05in 391.5pt 5.5in 409.5pt;">14.A Short Note on the Indigenous and Western Architectural Traditions In The Building of Islamia College,Peshawar. Imrana Seemi, ZakirUllah Jan,,Huma Mujeeb, Shabana Rafique , <em>Ancient Pakistan,</em> ISSN:0066-1600. Vol. XXVI: (2015) 105-108</p>
<p style="margin: 0in 5.85pt 8pt -4.5pt; text-align: justify; line-height: normal; tab-stops: 5.05in 391.5pt 5.5in 409.5pt;">15.Evaluating the Tensile Strength and K/S Value of Cotton Fabric Dyed with Natural Extracts of Madder Root (<em style="mso-bidi-font-style: normal;">Rubia tinctorum) </em>by Pad-Steam Process. Shahnaz Parveen Khattak, <strong style="mso-bidi-font-weight: normal;">Shabana Rafique</strong>, Bashir Ahmadand Tanveer Hussain.<em style="mso-bidi-font-style: normal;">Journal of Science &amp; Technology</em> Vol. 39, No. 1.(2015)</p>
<p style="margin: 0in 5.85pt 8pt -4.5pt; text-align: justify; line-height: normal; tab-stops: 5.05in 391.5pt 5.5in 409.5pt;">16. Colour Fastness and Tensile Strength of Cotton Fabric Dyed with Natural Extracts of&nbsp;<em>Alkanna tinctoria</em>&nbsp;by Continuous Dyeing Technique.Shahnaz Parveen Khattak<strong>, Shabana Rafique</strong>, Tanveer Hussain, Faiza Inayat and Bashir Ahmad..<em style="mso-bidi-font-style: normal;">Journal of the Chemical Society of Pakistan</em> Vol. 37, No. 5 ( 2015).</p>
<p style="margin: 0in 5.85pt 8pt -4.5pt; text-align: justify; line-height: normal; tab-stops: 5.05in 391.5pt 5.5in 409.5pt;">17. Optimization of selected binder systems for pigment colouration of PES/CO fabrics with respect to flexural rigidity and colourfastnes characteristics.Shahnaz Parveen Khattak<strong>, Shabana Rafique</strong>, Tanveer Hussain,Bashir Ahmad. and ZileHuma Mujeeb. <em style="mso-bidi-font-style: normal;">Journal of the Chemical Society of Pakistan</em> Vol. 37, No.&nbsp;6. (2015)1112-1122.</p>
<p style="margin: 0in 5.85pt 8pt -4.5pt; text-align: justify; line-height: normal; tab-stops: 5.05in 391.5pt 5.5in 409.5pt;">18.Evaluation of Flexural Rigidity and Abrasion Resistance of Post and Meta-Finished Pigment Dyed P/C Fabrics. <strong>Shabana Rafique</strong>, Shahnaz Parveen Khattak, Tanveer Hussain, Faiza Tauqeer and Bashir Ahmad. <em style="mso-bidi-font-style: normal;">Journal of Engineering and Applied </em>Science. Vol.35, no. 2.(2015) 63-72</p>
<p style="margin: 0in 5.85pt 8pt -4.5pt; text-align: justify; line-height: normal; tab-stops: 5.05in 391.5pt 5.5in 409.5pt;">19.Textiles of Ancient Gandharan Civilization with Special Reference to Bed Linens, &nbsp;Faiza Inayat, <strong>Shabana Rafique.</strong> PUTAJ-<em>Humanities and Social Sciences </em>(ISSN 1608-7925).Vol.24, No. 2, (2019) 71-95</p>
<p style="margin: 0in 5.85pt 8pt -4.5pt; text-align: justify; line-height: normal; tab-stops: 5.05in 391.5pt 5.5in 409.5pt;">20.Colour gamut of pad-steam dyed cotton fabric from natural extracts of Rubia tinctorum and Rubia cordifolia, Shahnaz Parveen Khattak, <strong>Shabana Rafique</strong>, Tanveer Hussain, Faiza Inayat <em>Journal of Textile Engineering &amp; Fashion Technology,</em> Vol.5, No.3 (2019) 148-152</p>
<p style="margin: 0in 5.85pt 8pt -4.5pt; text-align: justify; line-height: normal; tab-stops: 5.05in 391.5pt 5.5in 409.5pt;">21.Innovative Textile Desiging for Ladies Apparels from Architectural Motifs of Sethi House. Saraj ul Saba, Shabana Rafique, Faiza Tauqeer, Imrana Seemi.<em> Pakistan Journal of Humanities and Social Sciences.</em>Vol. 11, No 2 (2023) 1712&ndash;1721</p>
<p style="margin: 0in 5.85pt 8pt -4.5pt; text-align: justify; line-height: normal; tab-stops: 5.05in 391.5pt 5.5in 409.5pt;">22.&nbsp;From Recognition to Purchase: Understanding the Role of Brand Awareness in Driving Consumer Behavior in Pakistan. Neelam Akbar, Imran Rafiq, Kausar Takrim, Faiza Tauqeer, Shabana Sajjad. &nbsp;<em>International Journal of Special Education</em> Vol.38, No.1 (2023).308 -319</p>
<p style="margin: 0in 5.85pt 8pt -4.5pt; text-align: justify; line-height: normal; tab-stops: 5.05in 391.5pt 5.5in 409.5pt;">23.&nbsp;Body Shape Perception in Relation to the Apparel Choices of the Young and Late Adult Women of Peshawar , Areej Khan1,Shahnaz, Khattak, Faryal Yousaf, <strong>Shabana Rafique,</strong><em> Pakistan Journal of Humanities and Social ScienceseISSN: 2415-007X</em> ,Vol 11, No. 02, 2023, P.2128-2136 (2023)</p>
<p style="margin: 0in 5.85pt 8pt -4.5pt; text-align: justify; line-height: normal; tab-stops: 5.05in 391.5pt 5.5in 409.5pt;">24.Use of digital marketing:A Study of Converting kashikari&rsquo;s motifs in textile designs, Urooje khizran, Imrana Seem, Faiza Tauqeer,<strong>Shabana Rafique</strong><em>,,Journal of Business and Management Research, </em><em>ISSN:2958-5074 pISSN:2958-5066</em> Vol 2 no 2 (2023)</p>
<p style="margin: 0in 5.85pt 8pt -4.5pt; text-align: justify; line-height: normal; tab-stops: 5.05in 391.5pt 5.5in 409.5pt;">25.Impact of Concurrent Pigment-Dyeing &amp; Resin Treatments on the Abrasion and Pilling Resistance of Polyester/Cotton Fabrics<strong>, Shabana Rafique,</strong><strong>, </strong>Faiza Tauqeer,Shahnaz Khattak, Imrana Seemi,<em> Shnakht</em>I, Vol. 2 No. 3 SSN 2709-7633 (Print) |ISSN 2709-7641 (2023)</p>
<p class="MsoNormal" style="mso-margin-top-alt: auto; line-height: 106%;">26.The Role of Various Auxiliaries in The Fastness Characteristics of Cotton Coloured With Various Natural Dyes Through Pad-Steam Method (Part-I) Shahnaz Parveen, <strong>Shabana Rafique</strong>, Faiza Inayat, Imrana Seemi <em>Guman</em> Vol&nbsp; 6 No.4 (2023)</p>
<p class="MsoNormal" style="mso-margin-top-alt: auto; line-height: 106%;">27.Costumes of Bodhisattva Depicted in Gandhara Art, FaizaTauqeer, <strong>ShabanaRafique</strong>,Imrana Seemi, Faryal Yousaf<em> Shnakhat</em>Vol. 2 No. 3,ISSN 27097633(Online) |ISSN 2709-7641(Print) 146-158(2023)</p>
<p class="MsoNormal" style="mso-margin-top-alt: auto; line-height: 106%;">28.From Recognition to Purchase: Understanding the Role of Brand Awareness in Driving Consumer Behavior in Pakistan Neelam Akbar1, Dr. Imran Rafique, Kausar Takrim, Faiza Tauqeer,<strong> Shabana Sajjad</strong> International Journal of Special Education Vol.38, No.1, <strong>308-319 </strong>(2023)</p>
<p class="MsoNormal" style="mso-margin-top-alt: auto; margin-bottom: .0001pt; line-height: 106%;">29.Woven fabric selection and grading for ladies&rsquo; winter shawls using multicriteria decision-making approach, Faryal Yousaf, <strong>Shabana Sajjad, </strong>FaizaTauqeer,ShahnazKhattak,Tanveer Hussain, Fatima Iftikhar&nbsp; <em>Research Journal of Textile and Apparel</em>,ISSN 1560-6074 (2024)</p>
<p>&nbsp;</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; text-align: justify; line-height: 150%;">&nbsp;</p>
<p class="MsoNormal" style="margin-bottom: .0001pt; line-height: normal;">&nbsp;</p>
<p style="margin: 0in 5.85pt 8pt -4.5pt; text-align: justify; line-height: normal; tab-stops: 5.05in 391.5pt 5.5in 409.5pt;">&nbsp;</p>
<p style="margin: 0in 5.85pt 8pt -4.5pt; text-align: justify; line-height: normal; tab-stops: 5.05in 391.5pt 5.5in 409.5pt;">&nbsp;</p>
<p style="margin: 0in 5.85pt 8pt -4.5pt; text-align: justify; line-height: normal; tab-stops: 5.05in 391.5pt 5.5in 409.5pt;">&nbsp;</p></p><p align="right">,National,International, by: <a href="profile.php?id=12" class="text-info"><span class="text-info">Dr. Shabana Sajjad</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p></p>
<p class="15" style="margin-left: 0.0000pt; text-indent: 0.0000pt; text-align: justify; text-justify: inter-ideograph; mso-list: l0 level1 lfo1;" align="justify">1.&nbsp;Identification &amp; spectrophotometric quantification of dyes in the selected confectionery items available in the local markets of Peshawar, Pakistan. Pure and Applied Biology (PAB) (ISSN: 2304-2478),&nbsp;(2020), Vol.9 No.3, 1690-1700, Fazia Ghaffar,<br />&nbsp;<strong>Faiza Tauqeer</strong>, Rozina Rauf </p>
<p class="15" style="margin-left: 0.0000pt; text-align: justify; text-justify: inter-ideograph;" align="justify">&nbsp;</p>
<p class="15" style="margin-top: 6.0000pt; margin-bottom: 6.0000pt; margin-left: 0.0000pt; text-indent: 0.0000pt; text-align: justify; text-justify: inter-ideograph; background: #ffffff; mso-list: l0 level1 lfo1;" align="justify">2.&nbsp;The role of various dyeing auxiliaries in the fastness characteristics of cotton coloured with various natural dyes through Pad-steam method (Part-I), Research Journal GUMAN, (ISSN Online:2079-4162) (ISSN Print:2709-4154), (2023), Vol.6, No.4, Shahnaz Parveen Khattak, Shabana Rafique, <strong>Faiza Inayat</strong>, Imrana Seemi. </p>
<p class="15" style="margin-top: 6.0000pt; margin-bottom: 6.0000pt; margin-left: 0.0000pt; text-align: justify; text-justify: inter-ideograph; background: #ffffff;" align="justify">&nbsp;</p>
<p class="15" style="margin-top: 6.0000pt; margin-bottom: 6.0000pt; margin-left: 0.0000pt; text-indent: 0.0000pt; text-align: justify; text-justify: inter-ideograph; background: #ffffff; mso-list: l0 level1 lfo1;" align="justify">3.&nbsp;&ldquo;Connecting the dots: unravelling the relationship between brand attitude, loyalty, and purchase intentions in the textile and fashion industry&rdquo;, Journal of positive school psychology, (2023), Vol. 7 No.4, 523-536, Neelam Akbar, Dr. Najwa Mordhah, Dr. Kausar Takreem, Dr. Imran Rafique, <strong>Faiza Tauqeer</strong>. </p>
<p class="15" style="margin-left: 0.0000pt; text-align: justify; text-justify: inter-ideograph;" align="justify">&nbsp;</p>
<p class="15" style="margin-top: 6.0000pt; margin-bottom: 6.0000pt; margin-left: 0.0000pt; text-indent: 0.0000pt; text-align: justify; text-justify: inter-ideograph; background: #ffffff; mso-list: l0 level1 lfo1;" align="justify">4.&nbsp;Preliminary note on some Gandharan sculptures depicting warriors in their native costumes-study based on the museum collections, The Journal of Humanities and Social Scineces (ISSN 1024-0829), (2018), Vol.XXVI, No.2, <strong>Faiza Tauqeer. </strong></p>
<p class="15" style="margin-left: 0.0000pt; text-align: justify; text-justify: inter-ideograph;" align="justify">&nbsp;</p>
<p class="15" style="margin-top: 6.0000pt; margin-bottom: 6.0000pt; margin-left: 0.0000pt; text-indent: 0.0000pt; text-align: justify; text-justify: inter-ideograph; background: #ffffff; mso-list: l0 level1 lfo1;" align="justify">5.&nbsp;From recognition to purchase: understanding the role of brand awareness in driving consumer behavior in Pakistan, International Journal of Special Education, (2023), Vol. 38, No. 1, 308-319, Neelam Akbar, Dr. Imran Rafique, Kausar Takreem, <strong>Faiza Tauqeer</strong>, Shabana Sajjad. </p>
<p class="15" style="margin-left: 0.0000pt; text-align: justify; text-justify: inter-ideograph;" align="justify">&nbsp;</p>
<p class="15" style="margin-top: 6.0000pt; margin-bottom: 6.0000pt; margin-left: 0.0000pt; text-indent: 0.0000pt; text-align: justify; text-justify: inter-ideograph; background: #ffffff; mso-list: l0 level1 lfo1;" align="justify">6.&nbsp;Innovative Textile designing for ladies apparels from architectural motifs of Sethi house, Pakistan Journal of Humanities (ISSN:2415-007X), (2023), Vol.11, No.2, 1712-1721, Saraj ul Saba, Shabana Rafique, <strong>Faiza Tauqeer</strong>, Imrana Seemi. </p>
<p class="15" style="margin-left: 0.0000pt; text-align: justify; text-justify: inter-ideograph;" align="justify">&nbsp;</p>
<p class="15" style="margin-top: 6.0000pt; margin-bottom: 6.0000pt; margin-left: 0.0000pt; text-indent: 0.0000pt; text-align: justify; text-justify: inter-ideograph; background: #ffffff; mso-list: l0 level1 lfo1;" align="justify">7.&nbsp;Impact Of Concurrent Pigment-Dyeing &amp; Resin Treatments On The Abrasion And Pilling Resistance Of Polyester/Cotton Fabrics, SHNAKHAT, (ISSN Online:2079-7641), (ISSN Print:2709-7633), (2023), Vol.2 No.3209-221, Shabana Rafique, <strong>Faiza Tauqeer</strong>, Shahnaz Khattak, Imrana Seemi. </p>
<p class="15" style="margin-left: 0.0000pt; text-align: justify; text-justify: inter-ideograph;" align="justify">&nbsp;</p>
<p class="15" style="margin-top: 6.0000pt; margin-bottom: 6.0000pt; margin-left: 0.0000pt; text-indent: 0.0000pt; text-align: justify; text-justify: inter-ideograph; background: #ffffff; mso-list: l0 level1 lfo1;" align="justify">8.&nbsp;Costumes of Bodhisattva Depicted in Gandhara Art, SHNAKHAT, (ISSN Online:2079-7641), (ISSNPrint:2709-7633), (2023), Vol.2No.3,146-158, <strong>Faiza Tauqeer</strong>, Shabana Rafique, Imrana Seemi, Faryal Yousaf.</p>
9.&nbsp;Use of digital marketing: A study of converting Kashi Kari motifs in textile designs, International Journal of Human and Society, (ISSN Print: 2710-4966), (ISSN Online: 2710-4958), (2023), Vol.2 No.2, Dr. Imrana Seemi, Miss Uroj-e-Khizra, Dr. Faiza Tauqeer, Shabana Rafique.
<p class="MsoNormal" style="text-align: justify; text-justify: inter-ideograph;" align="justify">&nbsp;</p>
<p class="15" style="margin-left: 0.0000pt; text-indent: 0.0000pt; text-align: justify; text-justify: inter-ideograph; mso-list: l0 level1 lfo1;" align="justify">10.&nbsp;Threads of Swat: Rediscovering the Beauty of Islampuri Shawls, International Journal of Human and Society, (ISSN Print: 2710-4966), (ISSN Online: 2710-4958), (2024), Vol.4No.1, Ms.Nida Andaleeb Khattak, Dr.Shahnaz Khattak, <strong>Dr. Faiza Tauqeer</strong>, Dr. Imrana Seemi. </p>
<p class="MsoNormal" style="margin-left: 0.0000pt; text-indent: 0.0000pt; text-align: justify; text-justify: inter-ideograph; mso-list: l1 level1 lfo2;" align="justify">11.&nbsp;Color gamut of pad-steam dyed cotton fabric from natural extracts of Rubia Tinetorum and Rubia Cordifolia. Journal of Textile Engineering and Fashion Technology (2019) Vol.5, No.3: 148-152.<strong>&nbsp;</strong>Shahnaz Parveen Khattak, Shabana Rafique, Tanveer Hussain<strong>&nbsp;</strong>and<strong>&nbsp;Faiza Inayat.</strong></p>
<p class="MsoNormal" style="margin-left: 0.0000pt; text-indent: 0.0000pt; text-align: justify; text-justify: inter-ideograph; mso-list: l1 level1 lfo2;" align="justify">12.&nbsp;Pheran Through the Mists of Centuries. PUTAJ &ndash; Humanities and Social Sciences (ISSN: 2219-245X) (2017) Vol.24, No.2, 107-113.<strong>&nbsp;</strong>Shaban Rafique,<strong>&nbsp;Faiza Inayat </strong>and Shahnaz Khattak.</p>
<p class="MsoNormal" style="margin-left: 0.0000pt; text-indent: 0.0000pt; text-align: justify; text-justify: inter-ideograph; mso-list: l1 level1 lfo2;" align="justify">13.&nbsp;Textiles of Ancient Gandhara Civilization with special reference to Bed Linens. PUTAJ &ndash; Humanities and Social Sciences (ISSN: 2219-245X) (2017) Vol.24, No.2, 71-95. <strong>Faiza Inayat </strong>and Shabana Rafique.</p>
<p class="MsoNormal" style="margin-left: 0.0000pt; text-indent: 0.0000pt; text-align: justify; text-justify: inter-ideograph; mso-list: l1 level1 lfo2;" align="justify">14.&nbsp;Shape and Forms of Vessels: A Detailed Study on Pottery of Gandi Umar Khan. PUTAJ &ndash; Humanities and Social Sciences (ISSN: 2219-245X) (2015) Vol: 22, No. 2, 221-223. Zil-e-Huma Mujeeb, Zakirullah Jan, <strong>Faiza Tauqeer</strong>&nbsp;and Imrana Seemi.</p>
<p class="MsoNormal" style="margin-left: 0.0000pt; text-indent: 0.0000pt; text-align: justify; text-justify: inter-ideograph; mso-list: l1 level1 lfo2;" align="justify">15.&nbsp;Color Fastness and Tensile Strength of Cotton Fabrics Dyed with Natural Extracts of Alkannatinctoria by Continuous Dyeing Technique,&nbsp;Journal of the Chemical Society of Pakistan&nbsp;(2015), Vol. 37, No.5. Shahnaz Parveen Khattak, Shabana Rafique, Tanveer Hussain, <strong>Faiza Tauqeer</strong>&nbsp;and Bashir Ahmad.</p>
<p class="MsoNormal" style="margin-left: 0.0000pt; text-indent: 0.0000pt; text-align: justify; text-justify: inter-ideograph; mso-list: l1 level1 lfo2;" align="justify">16.&nbsp;Impact of Functional Finishes on the Tensile and Tear Strength Properties of Pigment Dyed P/C Fabrics by Post and Meta-Finishing Modes of Application,&nbsp;Journal of Science &amp; Technology&nbsp;(2013),&nbsp;Vol. 37, No. 2 :71-83. Shabana Rafique, Shahnaz Parveen Khattak, Tanveer Hussain, Bashir Ahmad and<strong>&nbsp;Faiza Tauqeer.</strong></p>
<p class="MsoNormal" style="margin-left: 0.0000pt; text-indent: 0.0000pt; text-align: justify; text-justify: inter-ideograph; mso-list: l1 level1 lfo2;" align="justify">17.&nbsp;Evaluation of Flexural Rigidity and Abrasion Resistance of Post and Meta-Finished Pigment Dyed P/C Fabrics,&nbsp;Journal of Engineering and Applied Science, (2016), Vol. 35, No.2: 63-72.&nbsp;Shabana Rafique, Shahnaz Parveen Khattak, Tanveer Hussain, <br /><strong>Faiza Tauqeer</strong>&nbsp;and Bashir Ahmad</p>
<p class="MsoNormal" style="margin-left: 0.0000pt; text-indent: 0.0000pt; text-align: justify; text-justify: inter-ideograph; mso-list: l1 level1 lfo2;" align="justify">18.&nbsp;A Comparative Study on the Application of Basic Dye on Nylon and Wool with Special Reference to their Strength and Colourfulness. Sarhad Journal of Agriculture, (1994) Vol. 10, No. 6: 106-112. <strong>Faiza Tauqeer </strong>and Shahnaz Parveen Khattak.</p>
<p class="MsoNormal" style="margin-left: 0.0000pt; text-indent: 0.0000pt; text-align: justify; text-justify: inter-ideograph; mso-list: l1 level1 lfo2;" align="justify">19.&nbsp;A comparative Study on the Application of Acid Dye on Nylon and Wool with Special Reference to their Strength and Colourfastness. Sarhad Journal of Agriculture&nbsp;(1993), Vol. 9, No.6: 663-638. <strong>Faiza Tauqeer </strong>and Shahnaz Parveen Khattak.</p></p><p align="right">,National,International, by: <a href="profile.php?id=14" class="text-info"><span class="text-info">Dr. Faiza Tauqeer</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><div style="mso-element: para-border-div; border: none; border-bottom: double #943634 3.0pt; mso-border-bottom-alt: thin-thick-small-gap #943634 3.0pt; padding: 0in 0in 1.0pt 0in;">
<p class="MsoNormal" style="margin-top: 20.0pt; margin-right: 0in; margin-bottom: 10.0pt; margin-left: 0in; text-align: center; line-height: 105%; mso-outline-level: 1; border: none; mso-border-bottom-alt: thin-thick-small-gap #943634 3.0pt; padding: 0in; mso-padding-alt: 0in 0in 1.0pt 0in;" align="center"><strong style="mso-bidi-font-weight: normal;">List of Research articles</strong></p>
</div>
<p class="MsoNormal" style="margin-top: 0in; margin-right: 0in; margin-bottom: 0in; margin-left: .5in; mso-add-space: auto; line-height: normal;">&nbsp;</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2024</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Woven fabric selection and grading for ladies&rsquo; winter shawls using multicriteria decision-making approach</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">F Yousaf, S Sajjad, F Tauqeer, T Hussain, S Khattak, F Iftikhar</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Research Journal of Textile and Apparel</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2024</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Threads of Swat: Rediscovering the Beauty of Islampuri Shawls</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">MNA Khattak, S Khattak, F Tauqeer, I Seemi</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">International Journal Of Human And Society 4 (1), 224-231</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2023</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">The role of various dyeing auxiliaries in the fastness characteristics of cotton coloured with various natural dyes through Pad-steam method (Part-I)</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">IS Khattak, Shahnaz Parveen, Shabana Rafique, Faiza Inayat</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Guman 6 (4), 147-159</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2023</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Design and Implementation of an Open-Source and Internet-of-Things-Based Health Monitoring System</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">S Ashraf, SP Khattak, MT Iqbal</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Journal of Low Power Electronics and Applications 13 (4), 57</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2023</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Impact Of Concurrent Pigment-Dyeing &amp; Resin Treatments On The Abrasion And Pilling Resistance Of Polyester/Cotton Fabrics</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">S Rafique, F Tauqeer, S Khattak, I Seemi</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Shnakhat 2 (3), 209-221</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2023</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Green application of isolated colorant from neem bark for mordant-coated wool: optimization of dyeing and mordanting for shade development</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">S Adeel, M Zuber, M Kınık, A Zor, S B&uuml;y&uuml;kkol, AD Kahraman, M Ozomay, SP Khattak</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Coatings 13 (9), 1639</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2023</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Anar Phali (<em>Opuntia ficus</em>) juice extract as a novel pollution-free source of natural betalain dye for wool yarn</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Y Riaz, S Barkaat, S Adeel, M Ibrahim, M Zuber, M Ozomay, SP Khattak</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Environmental Science and Pollution Research 30 (40), 92084-92094</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2023</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Body Shape Perception in Relation to the Apparel Choices of the Young and Late Adult Women of Peshawar</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">A Khan, S Khattak, F Yousaf, S Rafique</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Pakistan Journal of Humanities and Social Sciences 11 (2), 2069-2077</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2023</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Microwave-assisted sustainable coloration of wool fabric using&nbsp;<em>Rheum emodi</em>-based natural dye</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">S Adeel, A Mumtaz, R Mia, M Aftab, M Hussaan, N Amin, SR Khan, ...</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Surface Innovations 12 (3-4), 147-158</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2023</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Eco-friendly sustainable dyeing of cotton fabric using reactive violet 05 and direct violet 09 dyes</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">TH Bokhari, S Bano, S Adeel, B Ahmed, MA Al Mahmud, MA Qayyum, ...</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Coatings 13 (4), 677</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2019</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Colour gamut of pad-steam dyed cotton fabric from natural extracts of Rubia tinctorum and Rubia cordifolia</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Shahnaz Parveen Khattak, Shabana Rafique, Tanveer Hussain</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Journal of Textile Engineering &amp; Fashion Technology 5 (3), 148-152</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2018</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Pheran through the mists of centuries.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">S Rafique, F Inayat, SP Khattak</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Putaj Humanities &amp; Social Sciences 25 (2)</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2017</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Evaluation Of Flexural Rigidity And Abrasion Resistance Of Post And Meta-Finished Pigment Dyed P/C Fabrics</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">S Rafique, SP Khattak, T Hussain, F Tauqeer, B Ahmad</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Journal of Engineering and Applied Sciences (JEAS) 35 (2)</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2015</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Colour Fastness Properties of Polyester/Cotton Fabrics Treated with Pigment Orange and Various Functional Finishes.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">S Rafique, SP Khattak, T Hussain, B Ahmad, M SEEMI</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Asian Journal of Chemistry 27 (12)</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2015</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Colour Fastness and Tensile Strength of Cotton Fabric Dyed with Natural Extracts of Alkanna tinctoria by Continuous Dyeing Technique.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">SP Khattak, S Rafique, T Hussain, F Inayat, B Ahmad</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Journal of the Chemical Society of Pakistan 37 (5)</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2015</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Optimization of Selected Binder Systems for Pigment Colouration of PES/CO Fabrics with Respect of Flexural Rigidity and Colorfastness Characteristics</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">SR , Shahnaz Parveen Khattak , Tanveer Hussain, Bashir Ahmad And Zil E Mujeeb</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Journal of Chemical Society of Pakistan 37 (6), 1112-1122.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2015</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Structure Decoration on the Pottery of Gandi Umar khan</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">ZHM , Zakir Ullah Jan, Imrana Seemi, Shahnaz Parveen Khattak</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">PUTAJ (humanities and social sciences) 22 (1), 153-164</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2014</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Strength analysis of one-step pigment dyeing and durable press finishing of polyester/cotton blended sheeting fabrics with various crosslinking agents</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">S Rafique, SP Khattak, T Hussain, B Ahmad, F Shahzad</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">J Sci Technol Uni Peshawar 38, 31-39</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2014</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Pigment dyeing and finishing of cotton/polyester fabrics with a modified dihydroxyethyleneurea and various softener treatment</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">S Rafique, S Parveen, B Ahmad, T Hussain</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Life Science Journal 11 (5), 165-174</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2014</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Appraisal Of Fastness And Tensile Properties Of Cotton Fabric Dyed With Natural Colourants By Pad-Steam Method</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">SP Khattak</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">University Of Peshawar</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2014</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Optimization of fastness and tensile properties of cotton fabric dyed with natural extracts of Marigold flower (Tagetes erecta) by pad-steam method</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">SP Khattak, S Rafique, T Hussain, B Ahmad</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Life Sci. J 11 (7), 52-60</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2014</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Strength Analysis Of One-Step Pigment Dyeing And Durable Press Finishing Of Polyester/Cotton Blended Sheeting Fabrics With Various Crosslinking Agents</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Sr , Shahnaz Parveen Khattak, Tanveer Hussain, Bashir Ahmad, Farhat Shahzad</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Journal of Science and Technology 38 (1), 31-39</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2014</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Evaluating the tensile strength and K/S value of cotton fabric dyed with natural extracts of madder root (Rubia Tinctorum) by pad-steam process</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">SPK , Shabana Rafique, Bashir Ahmad, Tanveer Hussain and Farhat-Un-Nisa Shehzad</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Journal of Sciences &amp; Technology 38 (1), 1-11</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2014</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Pigment Dyeing and Finishing of Cotton /Polyester Fabrics with a Modified Dihydroxyethyleneurea and various Softeners</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">SR Shahnaz Parveen Khattak, Bashir Ahmad, Tanveer Hussain</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Life Science Journal 11 (5), 165-174.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2013</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Impact of functional finishes on the tensile and tear strength properties of pigment dyed P/C fabrics by post &amp; meta finishing modes of application</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">S Rafique, SP Khattak, T Hussain, B Ahmad, F Tauqeer</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Journal of Science and Technology University Peshawar 37 (2)</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2013</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Evaluation of fastness and tensile properties of cotton fabric dyed with root extracts of Acacia Catechu by pad-steam procedure</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">SP Khattak, S Rafique, B Ahmad, T Hussain, ZE Mujeeb</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Journal of Science and Technology 2 (1), 59-69</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2013</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Impact Of Functional Finishes On The Tensile And Tear Strength Properties Of Pigment Dyed P/C Fabrics By Post &amp; Meta Finishing Modes Of Application</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Shabana Rafique, Shahnaz Parveen Khattak, Tanveer Hussain</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Journal of Science &amp; Technology University of Peshawar 37 (2), 71-83</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2006</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">A Comparative Study on the Effects of Various Washing Powders on the Abrasion Resistance of Polyester/Cotton Blends.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Faryal Yousaf, Shahnaz Parveen Khattak, Shabana Sajjad</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">PUTAJ Science, Peshawar University Teachers Association Journal 13 (-), 95-101</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">2006</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">A Comparative Study on the Effects of Various Washing Powders on the Dimensional Stability of Cotton fabrics-I.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Hina Sheraz, Shahnaz Parveen Khattak, Shabana Sajjad</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">PUTAJ Science, Peshawar University Teachers Association Journal 13 (-), 103-109</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">1999</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Effect of Bleaching and Stripping Agents on the Strength of Acid Dyed Carpet Woolen Yarn</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Shahnaz Parveen Khattak, Tasneem Hameed, Amir Muhammad Khan</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Journal of Engineering and Applied Sciences 8 (2), 61-67</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">1998</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">The role of various auxiliaries in the dyeing of polyester with disperse dyes</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">SP Khattak, S Naz, S Zafar</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Sarhad Journal of Agriculture (Pakistan) 14 (4)</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">1998</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">A comparative study on the durability of Pakistan and foreign made woolen and wool blended fabrics</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">S Rafique, S Khattak, S Zafar</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Sarhad Journal of Agriculture (Pakistan) 14 (5)</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">1995</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Analysis Study of Pakistan and Foreign Made Woolen and Wool Blended Fabrics-II</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">SR , Shahnaz Parveen Khattak, Amir Muhammad Khan</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Journal of Engineering and Applied Sciences 14 (1), 141-145</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">1995</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Effects of Twist Factor on the Air Permeability of Fabrics</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">SG , Shahnaz Parveen Khattak, Amir Muhammad Khan</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Journal of Engineering and Applied Sciences 14 (1), 147-149.</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">1995</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Studies on Abrasion Resistance of Some Winter and Tropical Fabrics</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Shahnaz Parveen Khattak, Mushtaq Ahmad</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Journal of Engineering and Applied Sciences 14 (2), 97-102</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">1994</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">A Comparative Study on the Application of Basic Dye on Nylon and Wool with Special Reference to their Strength and Colorfastness</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">FI , Shahnaz Parveen Khattak, Amir Muhammad Khan</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Sarhad Journal of Agriculture 10 (6), 106-112</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">1994</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Analysis Study on Pakistan and Foreign Made Wool and Wool Blended Fabrics- I</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">SR , Shahnaz Parveen Khattak and Amir Muhammad Khan</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Journal of Engineering and Applied Science 13 (2), 102-104</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">1994</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Effect of Cloth Cover on Air Permeability of Fabrics</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">SG , Shahnaz Parveen Khattak, Amir Muhammad Khan</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Journal of Engineering and Applied Science 13 (2), 105-108</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">1993</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">A Comparative Study on the Application of Acid Dye on Nylon and Wool with Special Reference to their Strength and Colorfastness</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">FT , Shahnaz Parveen Khattak and Amir Muhammad Khan</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Sarhad Journal of Agriculture 11 (6), 633-638</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">1993</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">The Use of Bee's Wax in Batik Printing</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Shahnaz Parveen Khattak, Fakhira Naheed, Sabiha Zafar</p>
<p class="MsoNormal" style="margin-bottom: 0in; line-height: 115%;">Journal: Peshawar University Teacher Association, PUTA 1 (1), 202-205</p></p><p align="right">,National,International, by: <a href="profile.php?id=9" class="text-info"><span class="text-info">Prof. Dr. Shahnaz Khattak</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Memberships</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>HEC recognized supervisors</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>Visits organized</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Date: 17th Dec, 2013<br /> Venue: Islamabad&nbsp;<br /> Organization:Kohinoor Textile mill and Lok Virsa. &nbsp;</p>
<p>Date: 20th Nov, 2011<br />Venue: Islamabad &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Organization:Lawrencepur Textile mill and Lok Virsa. &nbsp;</p>
<p>Date: 15th Oct, 2010<br />Venue: Islamabad &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Organization:Lawrencepur Textile mill and Lok Virsa.&nbsp;</p>
<p>Date: 5th Jan, 2009<br />Venue: Islamabad &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Organization:Lawrencepur Textile mill and Lok Virsa.&nbsp;</p>
<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</p></p><p align="right">,,For College by: <a href="profile.php?id=31" class="text-info"><span class="text-info">Ms. Faryal Yousaf</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Achievements</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><ul>
<li>Certificate awarded by the Staff Training Institute, University of Peshawar on the completion of In Service Teachers Training Program of one academic year duration, in 1996.</li>
<li>Certificate awarded for the computer course for executives arranged by Computer Training Centre, College of Home Economics University of Peshawar of three month duration from Oct 1995 to Dec.1995 in Grade A+</li>
<li>
<p style="margin: 0in 0in 8pt; text-align: justify; line-height: normal;">Moderator, panel discussion in second National Home Economics Conference may 21-24,2017</p>
</li>
<li>
<p style="margin: 0in 0in 8pt; text-align: justify; line-height: normal;">Member Scientific Committeein second National Home Economics Conference may 21-24,2017</p>
</li>
<li></li>
</ul></p><p align="right">,,Personal by: <a href="profile.php?id=12" class="text-info"><span class="text-info">Dr. Shabana Sajjad</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p class="MsoNormal" style="margin-left: 70.9pt; text-align: justify; text-indent: -70.9pt;">1991&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;First Prize in English Hand Writing Competition, Beaconhouse Public School,&nbsp;&nbsp; Peshawar.</p>
<p class="MsoNormal" style="margin-left: 70.9pt; text-align: justify; text-indent: -70.9pt;">1992-1993&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; First Prize in Naat Competition, Beaconhouse Public School, Peshawar.</p>
<p class="MsoNormal" style="margin-left: 70.9pt; text-align: justify; text-indent: -70.9pt;">1998-1999&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; First Prize in National Song Competition, College of Home Economics, UOP</p>
<p class="MsoNormal" style="margin-left: 70.9pt; text-align: justify; text-indent: -70.9pt;">1997-2000&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Class Proctor at College of Home Economics, UOP &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</p>
<p class="MsoNormal" style="margin-left: 70.9pt; text-align: justify; text-indent: -70.9pt;">1998 &nbsp; &nbsp; &nbsp;Table Drill Commander, Women Guard Training at College of Home Economics, UOP</p>
<p class="MsoNormal" style="margin-left: 70.9pt; text-align: justify; text-indent: -70.9pt;">1999-2000&nbsp;&nbsp;&nbsp;&nbsp;President, Students Association at College of Home Economics, UOP</p>
<p class="MsoNormal" style="margin-left: 70.9pt; text-align: justify; text-indent: -70.9pt;">&nbsp;</p>
<p class="MsoNormal" style="text-align: justify;">2000-2003&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; University Proctor at College of Home Economics, &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; UOP</p>
<p class="MsoNormal" style="margin-left: 70.9pt; text-align: justify; text-indent: -70.9pt;">1999-2000&nbsp; &nbsp; &nbsp; &nbsp;Second Prize in Naat Competition, College of Home &nbsp;Economics, UOP</p>
<p class="MsoNormal" style="margin-left: 70.9pt; text-align: justify; text-indent: -70.9pt;">2001 &nbsp; &nbsp; &nbsp; Third Prize in Declamation Contest, Independance Day Celebrations,University of Peshawar</p>
<p class="MsoNormal" style="margin-left: 70.9pt; text-align: justify; text-indent: -70.9pt;">2003 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Second Prize in Declamation Contest, Paradise Environmental &amp; Community Welfare Society, Peshawar</p>
<p class="MsoNormal" style="margin-left: 70.9pt; text-align: justify; text-indent: -70.9pt;">&nbsp;</p>
<p class="MsoNormal" style="margin-left: 78pt; text-indent: -70.9pt;">&nbsp;</p></p><p align="right">,,Personal by: <a href="profile.php?id=31" class="text-info"><span class="text-info">Ms. Faryal Yousaf</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Certificate courses offered</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>Social events</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p class="MsoListParagraphCxSpFirst" style="text-indent: -.25in; mso-list: l0 level1 lfo1;">1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Organized a tablo, &lsquo;bint-e-hayat, on Women&rsquo;s Day, 8th March,2014 at Convocation Hall, UOP</p>
<p class="MsoListParagraphCxSpLast" style="text-indent: -.25in; mso-list: l0 level1 lfo1;">2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Participated as being Stage Secretary on women&rsquo;s day, 8th March,2014 at Convocation Hall, UOP</p>
<p>Organized Annual Day 2014, on 20th Feb,2014 at CHE,UOP</p></p><p align="right">,Participated,Organized, by: <a href="profile.php?id=31" class="text-info"><span class="text-info">Ms. Faryal Yousaf</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Educational trips</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><ol>
<li>&nbsp; Title:&nbsp;</li>
</ol></p><p align="right"> by: <a href="profile.php?id=31" class="text-info"><span class="text-info">Ms. Faryal Yousaf</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Awards</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><ol>
<li>&nbsp;Awarded a shield for being the best president student's association at college in October, 2002</li>
<li>Awarded a shield for best presentation at First National Conference, &nbsp;at Baragali Campus on 3rd&nbsp;and 4th&nbsp;June,2014</li>
<li>Awarded a shield for active participation on&nbsp;International Women&rsquo;s Day at convocation hall on&nbsp;8th March, 2014</li>
</ol></p><p align="right"> by: <a href="profile.php?id=31" class="text-info"><span class="text-info">Ms. Faryal Yousaf</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Talks</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>Book reviews</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Co-author for the Home Economics Book ( chapters of Clothing&nbsp;&amp; Textiles) in text book board, Peshawar,KPK.</p></p><p align="right"> by: <a href="profile.php?id=12" class="text-info"><span class="text-info">Dr. Shabana Sajjad</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><ol>
<li>Member of Select Committee of Grade 10th of Home Economics at DCTE, Abbotabad, dated:10-12 October 2013</li>
<li>Reviewed textbook of Grade 8th at DCTE, Abbotabad dated, 29th Oct - 1st Nov 2013</li>
<li>&nbsp;Member Select Committee meeting of Grade 8th at DCTE, Abbotabad dated, 30th Jan &ndash; 1st Feb 2014</li>
</ol>
<p>&nbsp;</p></p><p align="right"> by: <a href="profile.php?id=31" class="text-info"><span class="text-info">Ms. Faryal Yousaf</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Promotions</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>Study Leaves</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>Higher qualifications</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><ul>
<li><strong>Enrolled in Mphil in November 2012</strong></li>
</ul></p><p align="right"> by: <a href="profile.php?id=31" class="text-info"><span class="text-info">Ms. Faryal Yousaf</span></a>
                                </p>
                                </div>
                                                                </div>
                                
                            </div>

                        </div>
                        <div class="span3">
                            <h3>Announcements <a href="announcements.php" style="font-size:12px;">View All</a></h3>
                            <div id="news-container">
                            <ul class="list4 support-box">
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=209"><time datetime="2024-10-30">October 30, 2024</time></a>
                                        <div>Science Department, College of Home Econ...</div>
                                        <div><a href="show-event.php?id=209" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=208"><time datetime="2024-10-06">October 06, 2024</time></a>
                                        <div>Ms. Sidra Ali defended her research unde...</div>
                                        <div><a href="show-event.php?id=208" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=207"><time datetime="2024-09-11">September 11, 2024</time></a>
                                        <div>The entry test for MPhil/PhD programs in...</div>
                                        <div><a href="show-event.php?id=207" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                            </ul>
                            </div>
                            <h3>Upcoming Events <a href="upcoming-events.php" style="font-size:12px;">View All</a></h3>
                            <div id="news-container2">
                            <ul class="list4 support-box">
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=202"><time datetime="2024-03-03">March 03, 2024</time></a>
                                        <div>SPRING FIESTA, TUESDAY 5TH MARCH 2024....</div>
                                        <div><a href="show-event.php?id=202" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=201"><time datetime="2024-02-21">February 21, 2024</time></a>
                                        <div>A two day book fair was organized in col...</div>
                                        <div><a href="show-event.php?id=201" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=193"><time datetime="2023-10-04">October 04, 2023</time></a>
                                        <div>Newly admitted FSc students Orientation ...</div>
                                        <div><a href="show-event.php?id=193" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                            </ul>
                            </div>
                            
                        </div>                    </div>
                 </article>
            </div>
        </section>
    </div>
</div>
</div>
<!--footer-->
<footer>
    <div class="main">
        <div class="container">
            <div class="row">
                <article class="span12">
                    <p style="margin-top:20px;">College of Home Economics &copy; 2024. <a href="privacy-policy.php" title="Learn how we use your information">Privacy Policy</a></p>
                    <p align="right"><a style="display:none;" target="_blank" title="Site designed by SuperWebz.com" href="http://www.superwebz.com"><img src="img/superwebz_logo.jpg" alt="SuperWebz.com" /></a></p>
                </article>
            </div>
            <!-- {%FOOTER_LINK} -->
        </div>  
    </div> 
</footer><script type="text/javascript" src="js/bootstrap.js"></script>
<script>
    $('.list3 li a').hover(function(){
        $(this).stop().css({color:'#fc6f22'});	
        $(this).stop().parent().siblings('em').css({'background-position':'0 bottom'});	 
            }, function(){
        $(this).stop().css({color:'#1295d4'});	
        $(this).stop().parent().siblings('em').css({'background-position':'0 top'});						 
    })
    $('#search a').hover(function(){
        $(this).stop().animate({opacity:'0.5'});	
            }, function(){
       $(this).stop().animate({opacity:'1'});						 
    })
</script>

</body>
</html>
