<!DOCTYPE html>
<html lang="en">
<head>
<title>Human Development and Family Studies - College of Home Economics, University of Peshawar</title>
<meta charset="utf-8">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
<meta name = "format-detection" content = "telephone=no" />
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<!--CSS-->
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/camera.css">
<!--JS-->
<script src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery.vticker-min.js"></script>
<script src="js/jquery-migrate-1.1.1.js"></script>
<script src="js/superfish.js"></script>
<script src="js/jquery.mobilemenu.js"></script>
<script src="js/jquery.cookie.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.ui.totop.js"></script>
<script>	
	$(function(){
	$('#news-container').vTicker({ 
		speed: 500,
		pause: 5000,
		animation: 'fade',
		mousePause: true,
		showItems: 3
		});
	});
	
	$(function(){
	$('#news-container2').vTicker({ 
		speed: 500,
		pause: 5000,
		animation: 'fade',
		mousePause: true,
		showItems: 2
		});
	});
</script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
<script src="//code.jquery.com/ui/1.11.2/jquery-ui.js"></script>
<script>
$(function() {
$( "#accordion" ).accordion({
collapsible: true,
active: false,
heightStyle: "content"
});
});
</script>
<!--[if lt IE 8]>
		<div style='text-align:center'><a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/img/upgrade.jpg"border="0"alt=""/></a></div>  
<![endif]-->
<!--[if lt IE 9]>
  <link rel="stylesheet" href="css/ie.css">
  <link rel="stylesheet" href="css/docs.css">
  <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body>
<div class="global">
<!--header-->
<header>
    <div class="main">
        <div class="gradient">
        <div class="container">
             <article>
                <div class="navbar navbar_ clearfix">
                    <div class="navbar-inner">      
                          <div class="clearfix">
                                <div class="nav-collapse nav-collapse_">
                                	<ul class="nav sf-menu clearfix">
                                	  <li><a href="index.php">Home</a></li>
                                      <li class="sub-menu"><a href="#">About</a>
                                        <ul>
                                            <li><a href="che-history.php">Brief History</a></li>
                                            <li><a href="leadership.php">Leadership</a></li>
                                            <li><a href="foundation-faculty.php">Foundation Faculty</a></li>
                                            <li><a href="contact-us.php">Contact Us</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Programs</a>
                                        <ul>
                                            <li><a href="art-design-introduction.php">Art & Design</a></li>
                                            <li><a href="food-nutrition-sciences-introduction.php">Food & Nutrition Sciences</a></li>
                                            <li><a href="human-development-family-studies-introduction.php">Human Development &amp; Family Studies</a></li>
                                            <li><a href="resource-facility-management-introduction.php">Resource &amp; Facility Management</a></li>
                                            <li><a href="textile-clothing-introduction.php">Textile & Clothing</a></li>
                                            <li><a href="#">Mandatory Supportive<span></span></a>
                                              <ul>
                                             <li><a href="computer-science-introduction.php">Computer Science</a></li>
                                              <li><a href="english-introduction.php">English</a></li>
                                              <li><a href="pak-studies-introduction.php">Pak. Studies</a></li>

                                              <li><a href="science-introduction.php">Science Department</a></li>
                                              <li><a href="urdu-islamiyat-introduction.php">Urdu / Islamiyat</a></li>
                                              </ul>
                                            </li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Admissions</a>
                                        <ul>
                                          <li><a href="bsc.php">BS Public Health<span></span></a>
                                        	<ul>
                                              <li><a href="bsc-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="bsc-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="bsc-uniform.php">Uniform</a></li>
                                              <li><a href="bsc-merit-list.php">Merit List</a></li>
                                              <li><a href="bsc-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="fsc.php">F.A/ F.Sc.<span></span></a>
                                        	<ul>
                                              <li><a href="fsc-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="fsc-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="fsc-uniform.php">Uniform</a></li>
                                              <li><a href="fsc-merit-list.php">Merit List</a></li>
                                              <li><a href="fsc-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="bs-hons.php">B.S Home Economics<span></span></a>
                                        	<ul>
                                              <li><a href="bs-hons-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="bs-hons-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="bs-hons-uniform.php">Uniform</a></li>
                                              <li><a href="bs-hons-merit-list.php">Merit List</a></li>
                                              <li><a href="bs-hons-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="msc.php">BS Human Nutrition & Dietetics<span></span></a>
                                        	<ul>
                                              <li><a href="msc-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="msc-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="msc-uniform.php">Uniform</a></li>
                                              <li><a href="msc-merit-list.php">Merit List</a></li>
                                              <li><a href="msc-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="mphil.php">M.Phil<span></span></a>
                                        	<ul>
                                              <li><a href="mphil-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="mphil-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="mphil-uniform.php">Uniform</a></li>
                                              <li><a href="mphil-merit-list.php">Merit List</a></li>
                                              <li><a href="mphil-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                          <li><a href="phd.php">Ph.D<span></span></a>
                                        	<ul>
                                              <li><a href="phd-fee-structure.php">Fee Structure</a></li>
                                              <li><a href="phd-eligibility-rules.php">Eligibility / Rules</a></li>
                                              <li><a href="phd-uniform.php">Uniform</a></li>
                                              <li><a href="phd-merit-list.php">Merit List</a></li>
                                              <li><a href="phd-waiting-list.php">Waiting List</a></li>
                                            </ul>
                                          </li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Examination</a>
                                        <ul>
                                          <li><a href="examination-rules.php">Rules</a></li>
                                          <li><a href="datesheet.php">Date Sheet</a></li>
                                          <li><a href="results.php">Results</a></li>
                                          <li><a href="convocation.php">Convocation</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="college-faculty.php">Faculty</a>
                                        <ul>
                                          <li><a href="faculty-art-and-design.php">Art & Design</a></li>
                                          <li><a href="faculty-food-and-nutrition-sciences.php">Food & Nutrition Sciences</a></li>
                                          <li><a href="faculty-human-development-and-family-studies.php">Human Development and Family Studies</a></li>
                                          <li><a href="faculty-resource-and-facility-management.php">Resource and Facility Management</a></li>
                                          <li><a href="faculty-textile-and-clothing.php">Textile & Clothing</a></li>
                                          <li><a href="faculty-science.php">Science</a></li>
                                          <li><a href="faculty-computer-studies.php">Computer Studies</a></li>
                                          <li><a href="faculty-english.php">English</a></li>
                                          <li><a href="faculty-pak-studies.php">Pak. Studies</a></li>
                                          <li><a href="faculty-urdu.php">Urdu</a></li>
                                          <li><a href="faculty-islamiyat.php">Islamiyat</a></li>
                                          <li><a href="faculty-login.php">Faculty Login</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Student's Life</a>
                                        <ul>
                                          <li><a href="students-societies.php">Student Societies</a></li>
                                          <li><a href="students-society-members.php">Society Members</a></li>
                                          <li><a href="students-academic-visits.php">Academic Visits</a></li>
                                          <li><a href="students-recreational-trips.php">Recreational Trips</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Facilities</a>
                                        <ul>
                                  <li><a href="facilities-bookshop.php">Bookshop</a></li>                                          <li><a href="facilities-canteen.php">Canteen</a></li>

                                          <li><a href="facilities-daycare.php">Day Care</a></li>                                          <li><a href="facilities-first-aid-room.php">First Aid Room</a></li>

                                          <li><a href="facilities-generators.php">Generators</a></li>
                                                                                                                   <li><a href="facilities-home-management-residence.php">Home Management Residence</a></li>
        <li><a href="facilities-hostel.php">Hostel</a></li>
   <li><a href="facilities-internet.php">Internet</a></li>

                                          <li><a href="facilities-library.php">Library</a></li>
                                                                              <li><a href="facilities-mosque.php">Mosque</a></li>
                                          <li><a href="facilities-nursery.php">Nursery</a></li>
                                        <li><a href="facilities-photocopier.php">Photocopier</a></li>

                                          <li><a href="facilities-playgroup.php">Play Group</a></li>
                                            <li><a href="facilities-preplaygroup.php">Pre Play Group</a></li>      
                                          <li><a href="facilities-transport.php">Transport</a></li>
                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="alumni-list.php">PFHE</a>
                                        <ul>
                                          <li><a href="pfhe.php">Introduction</a></li>
                                          <li><a href="alumni-profile.php">Members Profile</a></li>
                                          <li><a href="alumni-list.php">Federation & Alumni Members</a></li>
                                        </ul>
  </li>
                                      <li class="sub-menu"><a href="#">JHEBS</a>
                                        <ul><li><a href="jhebs-call-for-papers.php">Call for Papers</a></li>
                                          <li><a href="jhebs-published-versions.php">Published Versions</a></li>
                                          <li><a href="jhebs-research.php">Research</a></li>
                                          <li><a href="jhebs-rules.php">Rules</a></li>
                                                                                    <li><a href="jhebs-updates.php">Updates</a></li>

                                        </ul>
                                      </li>
                                      <li class="sub-menu"><a href="#">Conference</a>
                                        <ul>
                                          <li><a href="conference-call-for-papers.php">Call For Papers</a></li>
										  <li><a href="conference-accepted-papers.php">Accepted Papers</a></li>
										  <li><a href="conference-registration-and-payment.php">Registration and Payment</a></li>
										  <li><a href="conference-important-dates.php">Important Dates</a></li>
										  <li><a href="conference-keynote-speaker.php">Keynote Speaker</a></li>
										  <li><a href="conference-committee.php">Committee</a></li>
										  <li><a href="conference-abstract-submission.php">Abstract Submission</a></li>
										  <li><a href="conference-topics.php">Conference Topics</a></li>
										  <li><a href="conference-presentation-instructions.php">Presentation Instructions</a></li>
										  <li><a href="conference-who-should-attend.php">Who should Attend</a></li>
										  <li><a href="conference-tentative-programme.php">Tentative Programme</a></li>
										  <li><a href="conference-venue.php">Venue</a></li>
										  <li><a href="conference-final-paper-submission.php">Final Paper Submission</a></li>
										  <li><a href="conference-paper-templates.php">Paper Templates</a></li>
										  <li><a href="conference-accommodation-and-travel.php">Accommodation & Travel</a></li>
										  <li><a href="conference-conference-poster.php">Conference Poster</a></li>
										  <li><a href="contact-us.php">Contact Us</a></li>
                                        </ul>
                                      </li>
									  <li class="sub-menu"><a href="#">Activities</a>
                                        <ul>                                          <li><a href="college-magazine.php">College Magazine</a></li>
                                          <li><a href="activities-exhibitions.php">Exhibitions</a></li>
                                          <li><a href="activities-internships.php">Internships</a></li>
                                          <li><a href="activities-lectures.php">Lectures</a></li>
                                          <li><a href="newsletter.php">Newsletter</a></li>                                          <li><a href="activities-seminars.php">Seminars</a></li>

                                          <li><a href="activities-sports.php">Sports</a></li>
                                                                                 <li><a href="activities-tutorials.php">Tutorials</a></li>
   <li><a href="activities-workshops.php">Workshops</a></li>
                                        </ul>
                                      </li>
                                    </ul>
                                 </div>
                                 <ul class="follow_icon">
                                    <li><a href="https://www.facebook.com/CHEUOP/"><img src="img/follow_icon2.png" alt=""></a></li>                                                                    </ul>                          </div>
                    </div>
                </div>
                <h1 class="brand"><a href="index.php"><img src="img/logo.png" alt=""></a></h1>
                <form id="search" class="search" action="search-results.php" method="GET" accept-charset="utf-8">
                	 <input type="text" onFocus="if(this.value =='Search for...' ) this.value=''" onBlur="if(this.value=='') this.value='Search for...'" value="Search for..." name="q">
                     <a href="#" onClick="document.getElementById('search').submit()"><img src="img/magnify.png" alt=""></a>
                </form>             </article>
        </div>
        </div>
    </div>
</header>

<div class="main">
    <div class="gradient1">
        <section class="container">
            <div class="row">
                <article class="span12 margBot6">
                    <div class="row">
                        <div class="span3 support-box">
                            <h3>Program Links</h3>
                            <ul class="list3">
                                <li><em></em><p><a href="human-development-family-studies-introduction.php">Introduction</a></p></li>
                                <li><em></em><p><a href="human-development-family-studies.php">Department Highlights</a></p></li>
                                <li><em></em><p><a href="human-development-family-studies-faculty.php">Faculty</a></p></li>
                                <li><em></em><p><a href="human-development-family-studies-department-pictures.php">Department Pictures</a></p></li>
                                <li><em></em><p><a href="human-development-family-studies-scheme-of-study.php">Scheme of Study</a></p></li>
                                <li><em></em><p><a href="human-development-family-studies-research-publications.php">Research Publications</a></p></li>
                                
                            </ul>
                        </div>
                        <div class="span6 support-box">
                            <h3>Human Development and Family Studies > Department Highlights</h3>

                            <div id="accordion">
							
                                <h3>Workshops</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>xyz</p></p><p align="right">,Participated,, by: <a href="profile.php?id=44" class="text-info"><span class="text-info">Ms. Sidra Ali Khan</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p class="MsoBodyText" style="margin-left: .5in; text-indent: -.25in; mso-list: l0 level1 lfo1; tab-stops: list .5in;">&middot; &nbsp; &nbsp; One week <strong>Research methodology</strong> <strong>workshop </strong>by HEC, Co-organizer. May 2011</p>
<p class="MsoBodyText" style="margin-left: .5in; text-indent: -.25in; mso-list: l0 level1 lfo1; tab-stops: list .5in;">&middot; &nbsp; &nbsp; Capacity building training workshop on Active citizen by British council. Nov 2011.</p>
<p class="MsoBodyText" style="margin-left: .5in; text-indent: -.25in; mso-list: l0 level1 lfo1; tab-stops: list .5in;">&middot; &nbsp; &nbsp; One day workshop on <strong>Gender based Violence</strong> sponsored by UNHCR, Facilitator. 29th November 2012.</p>
<p class="MsoBodyText" style="margin-left: .5in; text-indent: -.25in; mso-list: l0 level1 lfo1; tab-stops: list .5in;">&middot; &nbsp; &nbsp; One day orientation workshop on <strong>Senior Citizens</strong> by M.phil scholars, College Of Home Economics, Organizer, Presenter. 6th April. 2013.</p>
<p class="MsoBodyText" style="margin-left: .5in; text-indent: -.25in; mso-list: l0 level1 lfo1; tab-stops: list .5in;">&middot; &nbsp; &nbsp; Two days <strong>early childhood education training</strong> workshop by Department of Human Development Studies, College of Home Economics, Resource person. April 2013.</p>
<p class="MsoBodyText" style="margin-left: .5in; text-indent: -.25in; mso-list: l0 level1 lfo1; tab-stops: list .5in;">&middot; &nbsp; &nbsp; One week statistics workshop by CHRCD. Jan 2014. Participated.</p>
<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Participation on One day &ldquo;youth leadership&rdquo; workshop by National youth &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; assembly.</p></p><p align="right">,Participated,, by: <a href="profile.php?id=54" class="text-info"><span class="text-info">Ayesha Ijaz</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p class="MsoNormal">2014</p>
<p class="MsoNormal">Principal Organizer Counseling and Rehabilitation for physical disabled Peshawar arranged Department of Human Development and Family Studies. College of Home Economics ,University of Peshawar16th &amp;17th December 2014</p>
<p class="MsoNormal">2014</p>
<p class="MsoNormal">Principal Organizer Trained workers in a workshop on &ldquo;Workplace Ethics&rdquo; to class-1V&nbsp; peons of university of Peshawar arranged by&nbsp; College of Home Economics ,university of Peshawar</p>
<p class="MsoNormal">2014</p>
<p class="MsoNormal">Principal Organizer Trained&nbsp; students in a workshop on &ldquo;Self-Grooming&rdquo; College of Home Economics, University of Peshawar arranged by&nbsp; College of Home Economics ,University of Peshawar17th oct 2014</p>
<p class="MsoNormal">2014</p>
<p class="MsoNormal">Principal Organizer Lab assistant workshop</p>
<p class="MsoNormal">2014</p>
<p class="MsoNormal">Principal Organizer Photoshop with fine arts department</p>
<p class="MsoNormal">2013</p>
<p class="MsoNormal">Principal Organizer one day youth leadership training workshop. Title: &ldquo;Qadam&rdquo; in collaboration with members of National Youth assembly on 27th of September 2013</p>
<p class="MsoNormal">2013</p>
<p class="MsoNormal">Principal Organizer Teacher training workshop for ECCE Unit</p>
<p class="MsoNormal">2013</p>
<p class="MsoNormal">Principal Organizer, Two days training workshop&nbsp; on Early Childhood Education ,from 17th -18th April 2013.College of Home Economic. University of Peshawar</p>
<p class="MsoNormal">2013</p>
<p class="MsoNormal">Principal Organizer, one week training workshop&nbsp; on College Rules of Fine for Uniform Irregularities , from 05th -11th&nbsp; October 2013.College of Home Economic. University of Peshawar</p>
<p class="MsoNormal">2013</p>
<p class="MsoNormal">Principal Organizer, Orientation for Senior Citizen in Pakistan, on 6th April 2013.College of Home Economic. University of Peshawar</p>
<p class="MsoNormal">2013</p>
<p class="MsoNormal">Principal Organizer, Capacity Building Training Workshop for womenfolk in charsada district, on 12th May 2013.Organized by Department of Human Development and Family Studies. College of Home Economic. University of Peshawar. University of Peshawar.</p>
<p class="MsoNormal">2011</p>
<p class="MsoNormal">Principal Organizer of one week training of Salam Week, from 12th -17th December 2011.College of Home Economic. University of Peshawar</p>
<p class="MsoNormal">2011</p>
<p class="MsoNormal">Principal Organizer, Cleanliness Awareness: Planning and Implementing, from&nbsp; 18th -24th December 2011.College Of Home Economic. University of Peshawar</p>
<p class="MsoNormal">2011</p>
<p class="MsoNormal">Principal Organizer, One Week training workshop&nbsp; on Clutch making, from 12th -18th May 2011.College of Home Economic. University of Peshawar</p>
<p class="MsoNormal">2010</p>
<p class="MsoNormal">Principal Organizer, Recycling for School Going Children,&nbsp; from 21st -26th June&nbsp; 2010.Department of Human Development and Family Studies. College of Home Economics, University of Peshawar</p>
<p class="MsoNormal">2010</p>
<p class="MsoNormal">Principal Organizer, Introduction to BS Home Economics. Orientation lecture, on April 8th 2010.College of Home Economic. University of Peshawar</p>
<p class="MsoNormal">2007</p>
<p class="MsoNormal">Principal Organizer, Head Injury Prevention and Rehabilitation Programme for School Going Children, from 1st -10th March 2007. Organized by College Of Home Economics and Neuro Trauma and Head Injury Society. Affiliated with W.H.O</p>
<p class="MsoNormal">2006</p>
<p class="MsoNormal">&nbsp;Principal Organizer, Summer Camp for Children, from 2nd -8th June. Organized by Department of Human Development and Family Studies .College Of Home Economic, University of Peshawar.</p>
<p class="MsoNormal">2006</p>
<p class="MsoNormal">Principal Organizer, Head Injury Prevention and Rehabilitation Programme for School Going Children, from 12th -18th May 2006. Organized by College Of Home Economics. Sponsored by Neuro Trauma and Head Injury Society. Affiliated with W.H.O</p>
<p class="MsoNormal">2002</p>
<p class="MsoNormal">&nbsp;</p>
<p class="MsoNormal">Principal Organizer, Welfare and Awareness of the Female Folk about Child Health and Care, from 2nd -7th&nbsp; June 2002.Organized by&nbsp; College Of Home Economic, University of Peshawar and&nbsp; Hashim Kham Memorial School. &ldquo;Kaliyas&rsquo; Charsada</p></p><p align="right">,,Organized, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal">Two Days Training Workshop On The Khyber Pakhtunkhuwa Public Procurement Regulatory Authority Act, 2012 And The Khyber Pakhtunkhuwa Procurement Of Goods, Works And Services Rules,2014,.At Kyber&nbsp; Pakhtunkhuwa Public Procurement Regulatory Authority.20 and 21 may 2015</p>




<p class="MsoNormal">One week training on &ldquo;Leadership&rdquo;.CHRADC,UoP.30th ,31,1st ,2nd 3rd ,and 6th April 2015</p>




<p class="MsoNormal">One week training on &ldquo;Finance and Audit&rdquo; .CHRADC,UoP.10th to 17th Feb 2015</p>




<p class="MsoNormal">One day training workshop on &ldquo;Breast Cancer Awareness Campaign&rdquo; organized by College of Home Economics and IRUM Hospital Peshawar. November 2014</p>




<p class="MsoNormal">One Day Training On &ldquo;Protection against the Harassment of Women at Workplace Act-2010&rdquo; on 24th /04/2014.organized by University Of Peshawar at Sir Sahibzada Abdul Qayyum Museum of Archeology and Ethnology.24th April 2014.</p>




<p class="MsoNormal">&nbsp;One day workshop on &ldquo;Youth Leadership&rdquo; organized by National youth assembly.at College of Home Economics, University of Peshawar.</p>




<p class="MsoNormal">One day Awareness Session on &ldquo;service Rules (with/without pay leave)&rdquo; for teaching faculty of UOP. Organized by CHRCD. Centre For Human Resource And Career Development, 18th April 2014.at Law College. University of Peshawar.</p>




<p class="MsoNormal">One day Awareness Session Pension Rules Organized by PUTA resource person Dr. Uried treasurer University of Peshawar</p>




<p class="MsoNormal">One day workshop on Preparation Of Budget And Bills Under Self-Support Rules. 0n 29th 04 2014 organized by CHRCD</p>




<p class="MsoNormal">Four days Training On Entrepreneurship for Rural Women, from 20th -23rd September 2011.Organized by&nbsp; Pakistan Academy for Rural Development Peshawar</p>




<p class="MsoNormal">Capacity Building Training Workshop On &ldquo;Active Citizen&rdquo;, from 28th November 2011 to 1st December 2011.Organized by British Council Pakistan and Institute Of Social Work, Sociology and Gender Studies, University Of Peshawar.</p>




<p class="MsoNormal">Two days&rsquo; workshop for college teachers<em> &ldquo;Behavior </em>Therapy and Rational Emotive Therapy (REBT)&rdquo;, from 12th &ndash; 13th March, 2010. Organized by The Frontier Women University Peshawar<em> in</em> collaboration with HEC.</p>




<p class="MsoNormal">Resource Person in &ldquo;Controlling Cheating and Class Bunking In School Children&rdquo;, on 12th June 2010.Organized by Peshawar Model School for girls&rsquo; Warsak Road. Peshawar.</p>




<p style="margin-bottom: 12.0pt; tab-stops: 205.55pt;">One day Training workshop on Statistical package SAS (Statistical Analysis System) on 3rd June 2009.Organized by Department of Statistics, Frontier Women University and HEC. Pakistan.</p>




<p class="MsoNormal">&nbsp;One day Training workshop on Inspiring Entrepreneur Ship, on13th Feb 2008.Organized by College Of Home Economic. University of Peshawar.</p>




<p style="margin-bottom: 12.0pt; tab-stops: 205.55pt;"><em>One day Training workshop on&nbsp; &ldquo; Effective Evaluation &amp; Measurement Techniques, on&nbsp; </em>23rd February 2008.Organized by Frontier Women University and Higher Education Commission Pakistan&nbsp; in collaboration with Oxford University Press.</p>




<p class="MsoNormal">One day Training workshop. Semester System, on 14th June 2008. Organized by Frontier Women University in Collaboration with&nbsp; HEC Pakistan</p>




<p class="MsoNormal">One day Training workshop on Identification and Prevention Programs for Rehabilitation and Awareness of Drug Addiction, on 3rd March 2000.Organized by&nbsp;&nbsp; Dost Foundation and College Of Home Economic, University of Peshawar.</p>



</p><p align="right">,,,Attended by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal">Keynote speaker in, One day training workshop on <strong>Stress during Marriage</strong>.College of Home Economic. University of Peshawar.</p>




<p class="MsoNormal">Keynote speaker in,One day training workshop on <strong>Helping children and adoloscents</strong>College of Home Economic. University of Peshawar.</p>




<p class="MsoNormal">Keynote speaker in,One day training workshop on <strong>Importance of Guidance and counseling for university students.</strong> College of Home Economic. University of Peshawar.</p>




<p class="MsoNormal">Keynote speaker in, <strong>Orientation for Senior Citizen in Pakistan</strong>, on 6th April 2013.College of Home Economic. University of Peshawar.</p>




<p class="MsoNormal">Keynote speaker in Two days training workshop on <strong>Early Childhood Education,</strong> from 17th -18th April 2013.College of Home Economic. University of Peshawar.</p>




<p class="MsoNormal">Keynote speaker in <strong>Recycling for School Going Children</strong>,&nbsp; from 21st -26th June&nbsp; 2010.Department of Human Development and Family Studies. College of Home Economics, University of Peshawar.</p>




<p class="MsoNormal">Keynote speaker in <strong>Welfare and Awareness of the Female Folk about Child Health and Care</strong>, from 2nd -7th June 2002.Organized by&nbsp; College Of Home Economic, University of Peshawar and&nbsp; Hashim Kham Memorial School. &ldquo;Kaliyas&rsquo; Charsada.</p>



</p><p align="right">,Participated,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>testing</p></p><p align="right">,Participated,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Conferences</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p class="Achievement" style="margin-left: 0.5in; text-indent: -0.25in;">&middot; &nbsp; &nbsp; Two days conference of <strong>National rehabilitation</strong> <strong>(NRC)</strong> by Isra Institute of Rehabilitation Sciences. 21st and 22nd Oct 2012.</p>
<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Participated in Two days conference of National rehabilitation.4 th and 5th &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; oct 2013.&nbsp;</p>
<p class="Achievement" style="margin-left: 0.5in; text-indent: -0.25in;">&nbsp; &nbsp; &nbsp; Participated in First National Home Economics Conference : Exploring New Horizon in June 2014</p>
<p class="Achievement" style="margin-left: 0.5in; text-indent: -0.25in;">&nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</p></p><p align="right">,Participated,, by: <a href="profile.php?id=54" class="text-info"><span class="text-info">Ayesha Ijaz</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal">2014</p>


<p class="MsoNormal">First National Home Economics Conference : Exploring New Horizon</p>



</p><p align="right">,,Organized, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal">Youth conference organized by Government of Khyber Pakhtunkhwa.2014</p>




<p class="MsoNormal">Attended Conference on &ldquo;Women Empowerment&rdquo;.&nbsp; Organized by Education Ministry. Khyber Pakhtoonkhwa. Pakistan, on 2nd August 2009</p>




<p class="MsoNormal">Attended Conference on &ldquo;First National Conference on Professional Development of Teachers&rdquo; .Organized by HEC and NEHA. Islamabad, from 23rd&nbsp; -24th&nbsp; January 2007.</p>



</p><p align="right">,,,Attended by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p><strong>Poster Presented In National Conferences</strong></p>
<p><strong>&nbsp;</strong></p>




<p class="MsoNormal">Presented a Poster on Self -Image of Gender Dysphorics.1st National Conference of Home Economics. Exploring New Horizons. Baragali Campus. University of Peshawar</p>




<p class="MsoNormal">Presented a Poster on Capacity Building of Down Syndrome Children and its Impact on the Family Unit.1st&nbsp;&nbsp; National Conference of Home Economics. Exploring New Horizons. Baragali Campus. University of Peshawar</p>




<p class="MsoNormal">Presented a Poster on &ldquo;Impact Of Burns On Women In Khyber Pakhtoonkhwa&rdquo; 4th Spring Research Poster Exhibition Institute Of Chemical Science&nbsp; University of Peshawar, on 11th April 2013</p>




<p class="MsoNormal">Presented a Poster on &ldquo;Adjustment Problems of Women with Self-Inflicted Burn. &ldquo;Conference Secretariat NRC 2012 ISRA Institute of Rehabilitation Sciences (IIRS) ISRA University, Farash Town, Lehtrar Road Islamabad Pakistan with collaboration with Higher of Education Commission, Pakistan and ISRA Institute Rehabilitation Sciences Hyderabad Sindh, Karachi, from 20th -21st October 2012.</p>




<p class="MsoNormal">Presented a Poster on &ldquo;Impact of Conducive Parental Involvement on the Developmental Maturity of Four to Fifteen Years Child with Down&rsquo;s Syndrome&rdquo;. Khyber Medical University. Directorate of Research and Development, Peshawar With Collaboration with HEC on 18th Feb 2012.</p>



</p><p align="right">,Participated,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal">Consequences of Labeling on Healthy Child Development.1st Home Economics Conference: Exploring New Horizons.2014</p>




<p class="MsoNormal">Self -Image of Gender Dysphorics.1st Home Economics Conference: Exploring New Horizons.2014</p>




<p class="MsoNormal">Capacity Building of Down Syndrome Children and its Impact on the Family Unit.1st Home Economics Conference: Exploring New Horizons.2014.</p>




<p class="MsoNormal">Causes and Prevention of Head injury Among School Going Children.1st Home Economics Conference: Exploring New Horizons.2014</p>




<p class="MsoNormal">Major Stressors during Transition to Parenthood among First-Time Pregnant Mothers. Int J RehabilSci, 2013, 2(2): ISSN: 2226-7743.E-ISSN: 2308-536 volume 02, Issue 02&nbsp;&nbsp; July-December 2013p.44</p>




<p class="MsoNormal"><em>Islam maiauratkamaqam. Agahi</em> .Islamic women conference .1.(1) pp.30-32</p>




<p class="MsoNormal">Self-Concept of Male-To Female Gender Dysphorics. International Journal of Rehabilitation Sciences .ISSN:2223-7743.1 (2)p.17</p>




<p class="MsoNormal">To Study the Correlation between Body Types and Basic Neurotic Behavioral Consequences. International Journal of Rehabilitation Sciences .ISSN:2223-7743 Vol.1.(2)p.16</p>




<p class="MsoNormal">Adjustment Problems of Women with Self-Inflicted Burn. International Journal of Rehabilitation Sciences .ISSN:2223-7743.Vol.1(2)p.20</p>



</p><p align="right">,Participated,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>The Impact of Head Injury Awareness Program on the Play Behaviours of Children in Peshawar, Pakistan.2015</p></p><p align="right">,Participated,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>testing</p></p><p align="right">,Participated,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Seminars</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal">8th&nbsp; Sep 2015</p>


<p class="MsoNormal">Principal Organizer, one day seminar on Family law :Rights of women :an awareness campaign</p>




<p class="MsoNormal">2015</p>


<p class="MsoNormal">Principal Organizer, one day seminar on Intoduction to<strong> BS semester system</strong> .Guest Speaker Dr Mohammad Ibrar. Dept Of Social Work. UOP</p>




<p class="MsoNormal">8th Sep&nbsp; 2015</p>


<p class="MsoNormal">Principal Organizer, one day seminar on Message of Holy Prophet for Humanity .Guest Speaker.Dr.Taj Muharam.HOD deptt of Histroy Uop</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Principal Organizer, World Home Economics Day, on 21st March 2014, at College of Home Economics. University of Peshawar.</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Organized one day lecture on Revival of Spiritual values and modern sciences,</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Principal Organizer, Awareness about Head Injuries, on 21st March 2014, at College of Home Economics. University of Peshawar.</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Gerontology</p>




<p class="MsoNormal">2007</p>


<p class="MsoNormal">Principal Organizer, Awareness about Head Injuries, on 15th March 2007, at College of Home Economics. University of Peshawar.</p>




<p class="MsoNormal">2006</p>


<p class="MsoNormal">Principal Organizer, Awareness About Head Injuries, on 20th November, Organized by Head Injury and Neuron Trauma Association. Pakistan and College of Home Economics. University of Peshawar.</p>




<p class="MsoNormal">2006</p>


<p class="MsoNormal">Principal Organizer, Legal Rights Of Muslim Women, on 25th February 2006, Organized by&nbsp; College of Home Economics&nbsp; with collaboration of Law&nbsp; College. University of Peshawar</p>




<p class="MsoNormal">2005</p>


<p class="MsoNormal">Principal Organizer, Rights of Muslim Women, on 9th March 2005, Organized by College of Home Economics and with collaboration of Law&nbsp; College, University of Peshawar</p>




<p class="MsoNormal">2004</p>


<p class="MsoNormal">Principal Organizer, Legal Rights Of Muslim Women in Pakistan, on 7th June 2004, Organized by College of Home Economics and Khyber Law&nbsp; College, University of Peshawar</p>




<p class="MsoNormal">2003</p>


<p class="MsoNormal">Principal Organizer, Abnormal Psychology and Therapeutic Measures, 2nd April 2003.Organized by College of Home Economics and&nbsp;&nbsp; Department of Psychology University of Peshawar.</p>




<p class="MsoNormal">2003</p>


<p class="MsoNormal">Principal Organizer, Legal Rights Of Muslim Women, 14th May 2003. Organized by College of Home Economics and Law&nbsp; College, University of Peshawar</p>




<p class="MsoNormal">2002</p>


<p class="MsoNormal">Principal Organizer, Abnormal Psychology and Therapeutic Measures, 5th June 2002.Organized by College of Home Economics and Department of Psychology University of Peshawar.</p>




<p class="MsoNormal">2002</p>


<p class="MsoNormal">Principal Organizer ,Legal Rights and Privileges Given To Muslim Women, on 12th may 2002 .Organized by College of Home Economics and Law&nbsp; College, University of Peshawar</p>




<p class="MsoNormal">2001</p>


<p class="MsoNormal">Principal Organizer, Abnormal Psychology and Therapeutic Measures, on 12th September 2001.Organized by College of Home Economics and&nbsp; Department of Psychology University of Peshawar.</p>




<p class="MsoNormal">2001</p>


<p class="MsoNormal">Principal Organizer, Status Of Women in Islam, on 1st March 2001. Organized by College of Home Economics and Law&nbsp; College</p>




<p class="MsoNormal">2000</p>


<p class="MsoNormal">Principal Organizer, Legal Rights of Muslim Women, on 16th April 2000. Organized by College of Home Economics and Law&nbsp; College</p>



</p><p align="right">,,Organized, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p style="margin-bottom: 12.0pt; tab-stops: 205.55pt;">Attended seminar with theme of Proper Nutrition is Natural Medicine&nbsp;&nbsp; Organized Khyber Pakhtunkhwa Society of Nutrition and Dietetics and department of Human Nutrition, at Auditorium Hall Agriculture University Peshawar.</p>




<p style="margin-bottom: 12.0pt; tab-stops: 205.55pt;">Attended seminar on World Teachers Day .On Changing role of Media and Its impact on Education.&rdquo; Organized by PUTA.at PUTA HALL5/10/2013</p>




<p class="MsoNormal">Attended seminar on &ldquo;Research Methodology, Endnotes and Statistical Software in Research&rdquo;. Organized by PUTA. University of Peshawar, on 3rd&nbsp;&nbsp;&nbsp;&nbsp; November 2011.</p>




<p class="MsoNormal">WEE. Women Empowerment through Employment. (Attended)</p>
<p class="MsoNormal">Organized by Human Resource Development. Institute Of Management Sciences. ICMS, on 25th May 2010.</p>




<p class="MsoNormal">Attended seminar on &ldquo;Islamic Spirituality in Modern Context&rdquo;. Organized by Peshawar University Teachers Association (PUTA) and Islamic Roohani Mission (IRM) at PUTA Hall Peshawar, from 4rth May 2009.</p>




<p class="MsoNormal">Attended seminar on &ldquo;Skilling Pakistan Stakeholder&rdquo;. Organized by NAVTIC Area Study Center. University of Peshawar on 3rd March 2008.</p>



</p><p align="right">,,,Attended by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal">Invited as Keynote speaker One day workshop organized by Deptt of Biotechnology 31 August 2015</p>




<p class="MsoNormal">Invited as keynote speaker Seminar Islamia College University. The power of visualization</p>




<p class="MsoNormal">Keynote speaker on &ldquo;Down Syndrome; Understanding that extra chromosome&rdquo;. Organized by department of Physical Chemistry, University of Peshawar.20th November 2014 on international child protection day.</p>




<p class="MsoNormal">Keynote speaker on gender dysphorics of Pakistan .organized by Department of Psychology. Islamia College University</p>




<p class="MsoNormal">Keynote Speaker on &ldquo;Hazart Bibi Fatima Zahra&rdquo;daughter of Holy Prophet. Organized by Iranian Cultural Centre, KhweandoKor (Ngo) and Women Welfare Department Peshawar, on 5th June 2012</p>




<p class="MsoNormal">Keynote Speaker on &ldquo;Policy Seminar on Early Childhood Care and Education&rdquo;, from 4th-5th Dec 2007. Organized by UNICEF, SPO. Pearl Continental Peshawar</p>




<p class="MsoNormal">Keynote Speaker on &ldquo;Rights of Women in Islam&rdquo;. Organized by College of Home Economics, University of Peshawar, on 5th May 2007.</p>




<p class="MsoNormal">Keynote Speaker on Women and Islam. Organized by College of Home Economics, University of Peshawar, on 14th September 2006</p>




<p class="MsoNormal">Keynote Speaker on &ldquo;Imam HussainAur Karbala&rdquo; Organized by College of Home Economics, University of Peshawar, on 12th April 2005.</p>




<p class="MsoNormal">Keynote Speaker on &ldquo;Women and Islam&rdquo; Organized by College of Home Economics, University of Peshawar, on 12th April , 2006</p>




<p class="MsoNormal">Keynote Speaker on &ldquo;Event of Karbala&rdquo;. Organized by College of Home Economics, University of Peshawar, on 20th March 2003</p>




<p class="MsoNormal">Keynote Speaker on &ldquo;Child Health and Development&rdquo;. Organized by S.P.O Shiraz Inn. Peshawar, on 15thDecember,2003</p>




<p class="MsoNormal">Keynote Speaker on &ldquo;Child Health, Care and Development&rdquo;. Organized by S.P.O. Continental Guest House. University Town, on 6th December,2000</p>



</p><p align="right">,Participated,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>testing</p>
<p>&nbsp;</p></p><p align="right">,,Organized, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Extension Lectures</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Gave lecture in Islamia College (department of psychology) on <strong>Procrastination. </strong>24th Aug 2015 to MSc stds</p></p><p align="right">,Participated,, by: <a href="profile.php?id=54" class="text-info"><span class="text-info">Ayesha Ijaz</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal">8th&nbsp; Sep 2015</p>


<p class="MsoNormal">Principal Organizer, one day seminar on Family law :Rights of women :an awareness campaign</p>




<p class="MsoNormal">2015</p>


<p class="MsoNormal">Principal Organizer, one day seminar on Intoduction to<strong> BS semester system</strong> .Guest Speaker Dr Mohammad Ibrar. Dept Of Social Work. UOP</p>




<p class="MsoNormal">8th Sep&nbsp; 2015</p>


<p class="MsoNormal">Principal Organizer, one day seminar on Message of Holy Prophet for Humanity .Guest Speaker.Dr.Taj Muharam.HOD deptt of Histroy Uop</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Principal Organizer, World Home Economics Day, on 21st March 2014, at College of Home Economics. University of Peshawar.</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Organized one day lecture on Revival of Spiritual values and modern sciences,</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Principal Organizer, Awareness about Head Injuries, on 21st March 2014, at College of Home Economics. University of Peshawar.</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Gerontology</p>




<p class="MsoNormal">2007</p>


<p class="MsoNormal">Principal Organizer, Awareness about Head Injuries, on 15th March 2007, at College of Home Economics. University of Peshawar.</p>




<p class="MsoNormal">2006</p>


<p class="MsoNormal">Principal Organizer, Awareness About Head Injuries, on 20th November, Organized by Head Injury and Neuron Trauma Association. Pakistan and College of Home Economics. University of Peshawar.</p>




<p class="MsoNormal">2006</p>


<p class="MsoNormal">Principal Organizer, Legal Rights Of Muslim Women, on 25th February 2006, Organized by&nbsp; College of Home Economics&nbsp; with collaboration of Law&nbsp; College. University of Peshawar</p>




<p class="MsoNormal">2005</p>


<p class="MsoNormal">Principal Organizer, Rights of Muslim Women, on 9th March 2005, Organized by College of Home Economics and with collaboration of Law&nbsp; College, University of Peshawar</p>




<p class="MsoNormal">2004</p>


<p class="MsoNormal">Principal Organizer, Legal Rights Of Muslim Women in Pakistan, on 7th June 2004, Organized by College of Home Economics and Khyber Law&nbsp; College, University of Peshawar</p>




<p class="MsoNormal">2003</p>


<p class="MsoNormal">Principal Organizer, Abnormal Psychology and Therapeutic Measures, 2nd April 2003.Organized by College of Home Economics and&nbsp;&nbsp; Department of Psychology University of Peshawar.</p>




<p class="MsoNormal">2003</p>


<p class="MsoNormal">Principal Organizer, Legal Rights Of Muslim Women, 14th May 2003. Organized by College of Home Economics and Law&nbsp; College, University of Peshawar</p>




<p class="MsoNormal">2002</p>


<p class="MsoNormal">Principal Organizer, Abnormal Psychology and Therapeutic Measures, 5th June 2002.Organized by College of Home Economics and Department of Psychology University of Peshawar.</p>




<p class="MsoNormal">2002</p>


<p class="MsoNormal">Principal Organizer ,Legal Rights and Privileges Given To Muslim Women, on 12th may 2002 .Organized by College of Home Economics and Law&nbsp; College, University of Peshawar</p>




<p class="MsoNormal">2001</p>


<p class="MsoNormal">Principal Organizer, Abnormal Psychology and Therapeutic Measures, on 12th September 2001.Organized by College of Home Economics and&nbsp; Department of Psychology University of Peshawar.</p>




<p class="MsoNormal">2001</p>


<p class="MsoNormal">Principal Organizer, Status Of Women in Islam, on 1st March 2001. Organized by College of Home Economics and Law&nbsp; College</p>




<p class="MsoNormal">2000</p>


<p class="MsoNormal">Principal Organizer, Legal Rights of Muslim Women, on 16th April 2000. Organized by College of Home Economics and Law&nbsp; College</p>



</p><p align="right">,Participated,Organized, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal">2014</p>


<p class="MsoNormal">Principal organizer of&nbsp; extension lecture&nbsp; on Importance of <em>Ziker E Ilahi and Tasawaf</em>&nbsp; for Youth .College Of Home Economics, UOP17th Jan 2014</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Principal organizer Nutrition Awareness lecture at University Model School Girls Section 21.11.2013</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Principal organizer Nutrition Awareness lecture at Agriculture University Public School Girls Section15th Oct 2013</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Principal organizer of extension lecture&nbsp; on gerontology .College Of Home Economics, UOP20th Nov 2013</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Principal organized a lecture and awareness walk on world literacy day (9th September 2013), resource person was Prof.AbaseenUsafzai (Incharge Khyber Union Islamia College University 9th September 2013</p>



</p><p align="right">,,Organized, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Trainings</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                           <p style="color:#333333;font-weight:normal;"><p class="MsoNormal">Two week training of <strong>Professional competency enhancement program (PCEPT)</strong> for teachers by Staff training institute and higher education commission. June, 2011</p></p><p align="right">,Participated,, by: <a href="profile.php?id=54" class="text-info"><span class="text-info">Ayesha Ijaz</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                           <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal">2014</p>


<p class="MsoNormal">Principal Organizer Counseling and Rehabilitation for physical disabled Peshawar arranged Department of Human Development and Family Studies. College of Home Economics ,University of Peshawar16th &amp;17th December 2014</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Principal Organizer Trained workers in a workshop on &ldquo;Workplace Ethics&rdquo; to class-1V&nbsp; peons of university of Peshawar arranged by&nbsp; College of Home Economics ,university of Peshawar</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Principal Organizer Trained&nbsp; students in a workshop on &ldquo;Self-Grooming&rdquo; College of Home Economics, University of Peshawar arranged by&nbsp; College of Home Economics ,University of Peshawar17th oct 2014</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Principal Organizer Lab assistant workshop</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Principal Organizer Photoshop with fine arts department</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Principal Organizer one day youth leadership training workshop. Title: &ldquo;Qadam&rdquo; in collaboration with members of National Youth assembly on 27th of September 2013</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Principal Organizer Teacher training workshop for ECCE Unit</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Principal Organizer, Two days training workshop&nbsp; on Early Childhood Education ,from 17th -18th April 2013.College of Home Economic. University of Peshawar</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Principal Organizer, one week training workshop&nbsp; on College Rules of Fine for Uniform Irregularities , from 05th -11th&nbsp; October 2013.College of Home Economic. University of Peshawar</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Principal Organizer, Orientation for Senior Citizen in Pakistan, on 6th April 2013.College of Home Economic. University of Peshawar</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Principal Organizer, Capacity Building Training Workshop for womenfolk in charsada district, on 12th May 2013.Organized by Department of Human Development and Family Studies. College of Home Economic. University of Peshawar. University of Peshawar.</p>




<p class="MsoNormal">2011</p>


<p class="MsoNormal">Principal Organizer of one week training of Salam Week, from 12th -17th December 2011.College of Home Economic. University of Peshawar</p>




<p class="MsoNormal">2011</p>


<p class="MsoNormal">Principal Organizer, Cleanliness Awareness: Planning and Implementing, from&nbsp; 18th -24th December 2011.College Of Home Economic. University of Peshawar</p>




<p class="MsoNormal">2011</p>


<p class="MsoNormal">Principal Organizer, One Week training workshop&nbsp; on Clutch making, from 12th -18th May 2011.College of Home Economic. University of Peshawar</p>




<p class="MsoNormal">2010</p>


<p class="MsoNormal">Principal Organizer, Recycling for School Going Children,&nbsp; from 21st -26th June&nbsp; 2010.Department of Human Development and Family Studies. College of Home Economics, University of Peshawar</p>




<p class="MsoNormal">2010</p>


<p class="MsoNormal">Principal Organizer, Introduction to BS Home Economics. Orientation lecture, on April 8th 2010.College of Home Economic. University of Peshawar</p>




<p class="MsoNormal">2007</p>


<p class="MsoNormal">Principal Organizer, Head Injury Prevention and Rehabilitation Programme for School Going Children, from 1st -10th March 2007. Organized by College Of Home Economics and Neuro Trauma and Head Injury Society. Affiliated with W.H.O</p>




<p class="MsoNormal">2006</p>


<p class="MsoNormal">&nbsp;Principal Organizer, Summer Camp for Children, from 2nd -8th June. Organized by Department of Human Development and Family Studies .College Of Home Economic, University of Peshawar.</p>




<p class="MsoNormal">2006</p>


<p class="MsoNormal">Principal Organizer, Head Injury Prevention and Rehabilitation Programme for School Going Children, from 12th -18th May 2006. Organized by College Of Home Economics. Sponsored by Neuro Trauma and Head Injury Society. Affiliated with W.H.O</p>




<p class="MsoNormal">2002</p>
<p class="MsoNormal">&nbsp;</p>


<p class="MsoNormal">Principal Organizer, Welfare and Awareness of the Female Folk about Child Health and Care, from 2nd -7th&nbsp; June 2002.Organized by&nbsp; College Of Home Economic, University of Peshawar and&nbsp; Hashim Kham Memorial School. &ldquo;Kaliyas&rsquo; Charsada</p>



</p><p align="right">,,Organized, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Exhibitions</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p class="MsoListParagraphCxSpFirst" style="text-indent: -.25in; mso-list: l0 level1 lfo1; tab-stops: list .5in;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Participated on 4th spring research poster exhibition by Institute of chemical sciences. U.O.P</p>
<p class="MsoListParagraphCxSpLast" style="text-indent: -.25in; mso-list: l0 level1 lfo1; tab-stops: list .5in;">&middot;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Participated in exhibition of Disaster preparedness and management in 2013</p>
<p>Facilitated students in exhibition of Disaster&nbsp; preparedness and management in 2014</p></p><p align="right">,Participated,, by: <a href="profile.php?id=54" class="text-info"><span class="text-info">Ayesha Ijaz</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal" style="margin-left: 7.1pt; tab-stops: 205.55pt;">2015</p>


<p class="MsoNormal">Organized Human Development studies exhibition at College Of Home Economic, University of Peshawar.</p>




<p class="MsoNormal" style="margin-left: 7.1pt; tab-stops: 205.55pt;">2015</p>


<p class="MsoNormal">Organize Early Childhood Care and Education&nbsp;&nbsp; Pottery Exhibition at College Of Home Economic, University of Peshawar.</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Organize Early Childhood Care and Education&nbsp;&nbsp; Drawing Exhibition at College Of Home Economic, University of Peshawar.</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Organized Early Childhood Care and Education&nbsp;&nbsp; Coloring Exhibition at College Of Home Economic, University of Peshawar.</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Principal organizer Art and Design Exhibition at PUTA Hall. University of Peshawar21&amp;22 Oct 2014</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Principal organizer Art and Design Exhibition at PUTA Hall.University of Peshawar.</p>




<p class="MsoNormal">2012</p>


<p class="MsoNormal">Principal organizer Handmade Clutches at College Of Home Economic, University of Peshawar.</p>




<p class="MsoNormal">2011</p>


<p class="MsoNormal">Principal organizer Recycling projects of Children between ages 5-14 years at College Of Home Economic, University of Peshawar.</p>




<p class="MsoNormal">2011</p>


<p class="MsoNormal">Principal organizer .Stone painting at College Of Home Economic, University of Peshawar.</p>



</p><p align="right">,,Organized, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal">Disaster Management Exhibition (DMC). Centre For Disaster Preparedness and Management, University Of Peshawar, Pakistan. In Collaboration with National Disaster Management Authority, Pakistan and UN Food Programme, from 3rd and 4th December 2014</p>




<p class="MsoNormal">Disaster Management Exhibition (DMC). Centre For Disaster Preparedness and Management, University Of Peshawar, Pakistan. In Collaboration with National Disaster Management Authority, Pakistan and United Nations Development Programme, Pakistan, from 6th -7th November 2012.</p>




<p class="MsoNormal">Disaster Management Exhibition (DMC).Centre For Disaster Preparedness And Management, University Of Peshawar, Pakistan. In Collaboration with National Disaster Management Authority, Pakistan and United Nations Development Programme, Pakistan, from 20th -21st April 2011.</p>




<p class="MsoNormal">Participated on 4th spring research poster exhibition by Institute of chemical sciences. U.O.P</p>



</p><p align="right">,Participated,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal">One day science and technology exhibition /symposium on Effective linkages of research organizations, academia and industry for national development. PCSIR Laboratories complex.12 May 2015</p>




<p class="MsoNormal">Attended Theses Exhibition Organized by Deptt of Art and Design. UOP.Venue PUTA Hall.29th May 2014</p>




<p class="MsoNormal">Attended Environment Exhibition. Organized by Deptt of Environmental Sciences. UOP. Venue PUTA Hall.</p>




<p class="MsoNormal">Attended Book exhibition. Organized by PUTA. UOP. Venue PUTA Hall.</p>




<p class="MsoNormal">Attended Tirah Valley Exhibition organized by BinteHawa an Ngo</p>


<p class="MsoNormal">&nbsp;</p>




<p class="MsoNormal">Attended&nbsp; Annual Exhibition organized by Women Development Centre and Samada at Pearl Continental Peshawar</p>


<p class="MsoNormal">&nbsp;</p>




<p class="MsoNormal">Attended Theses Exhibition.Organized by Deptt of Art and Design. UOP. Venue PUTA Hall.</p>


<p class="MsoNormal">&nbsp;</p>



</p><p align="right">,,,Attended by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Competitions</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>Editorships</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>Research Publications</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p class="MsoBodyText" style="margin-top: 0in; margin-right: 0in; margin-bottom: 11.0pt; margin-left: .5in; text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">To study the correlation between body types and basic neurotic behavioral consequences. (Abstract)</p>
<p class="MsoBodyText" style="margin-top: 0in; margin-right: 0in; margin-bottom: 11.0pt; margin-left: .5in; text-align: justify; text-justify: inter-ideograph; text-indent: -.25in; mso-list: l0 level1 lfo1;">&nbsp;Psychological healing of aged through public awareness and group discussions.&nbsp;</p></p><p align="right">,National,,Conference Paper by: <a href="profile.php?id=54" class="text-info"><span class="text-info">Ayesha Ijaz</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal">Paper presented on Consequences of Labeling on Healthy Child Development.1st National Conference of Home Economics. Exploring New Horizons. Baragali Campus. University of Peshawar3&amp;4 June 2014</p>




<p class="MsoNormal">Paper presented on Causes and Prevention of Head injury Among School Going Children. 1st National Conference of Home Economics. Exploring New Horizons. Baragali Campus. University of Peshawar&amp;4 June 2014</p>




<p class="MsoNormal">Paper presented fselectionon First Provisional Conference Of Home Economics in Khyber Pakhtoonkhwa. Organized by SHE Society of Home Economists at the Archives Library, Peshawar, on Thursday.22 May 2014</p>




<p class="MsoNormal">Paper presented on Major Stressors During Transition To Parenthood Among First-Time Pregnant Mothers (Best paper presentation award was awarded ) organized by Conference Secretariat NRC 2012 ISRA Institute of Rehabilitation Sciences (IIRS) ISRA University, Farash Town, Lehtrar Road Islamabad Pakistan ,Higher of Education Commission, Pakistan and ISRA Institute Rehabilitation Sciences Hyderabad Sindh, Karachi, from 4rth&nbsp; -5th October 2013</p>




<p class="MsoNormal">Paper presented on &ldquo;A study on psychological wellbeing and neuroticism among internally displaced people from war zones, Khyber pukhtunkhaw Pakistan&rdquo;. Conference Secretariat NRC 2012 ISRA Institute of Rehabilitation Sciences (IIRS) ISRA University, Farash Town, Lehtrar Road Islamabad Pakistan ,Higher of Education Commission, Pakistan and ISRA Institute Rehabilitation Sciences Hyderabad Sindh, Karachi, from&nbsp; 4rth-5th October 2013.</p>




<p class="MsoNormal">Paper presented on&rdquo; Psychological healing of aged through public awareness and group discussion&rdquo; Conference Secretariat NRC 2012 ISRA Institute of Rehabilitation Sciences (IIRS) ISRA University, Farash Town, Lehtrar Road Islamabad Pakistan .Higher of Education Commission, Pakistan and ISRA Institute Rehabilitation Sciences Hyderabad Sindh, Karachi,from 4rth -5th October 2013</p>




<p class="MsoNormal">Paper presented on &ldquo;Rights of women in Islam&rdquo; Islamic Women Conference Organized by Islamic Women Forum .Pearl Continental Peshawar , on 1st&nbsp; July 2013.</p>




<p class="MsoNormal">Paper presented on &ldquo;Self-Concept of Male-To Female Gender Dysphorics.&rdquo; (Best paper presentation award was awarded ) Conference Secretariat NRC 2012 ISRA Institute of Rehabilitation Sciences (IIRS) ISRA University, Farash town, Lehtrar Road Islamabad Pakistan with collaboration with Higher of Education Commission, Pakistan and ISRA Institute Rehabilitation Sciences Hyderabad Sindh, Karachi,on 20th -21st October 2012</p>




<p class="MsoNormal">Paper presented on &ldquo;To Study the Correlation between Body Types and Basic Neurotic Behavioral Consequences&rdquo; Conference Secretariat NRC 2012 ISRA Institute of Rehabilitation Sciences (IIRS) ISRA University, Farash town, Lehtrar Road Islamabad Pakistan with collaboration with Higher of Education Commission, Pakistan and ISRA Institute Rehabilitation Sciences Hyderabad Sindh, Karachi,on 20th -21st October 2012</p>




<p class="MsoNormal">Paper Presented On &ldquo;The Psychological Impact Of Burn On Married Women In Khyber Pakhtoonkhwa&rdquo;. Khyber Medical University. Annual Health Research Symposium, Directorate Of Research And Development, Peshawar With Collaboration With Hec,On18th Feb 2012</p>




<p class="MsoNormal">Paper Presented On &ldquo;Role Of Home Economics College Peshawar In Providing Awareness Among School Going Children About Head Injury And Neuro Trauma In Peshawar&rdquo;. Second National Conference Organized By Head Injury And Neuro Trauma Association, Peshawar, Khyber Pakhtoonkhwa, On 15thJune 2009.</p>




<p class="MsoNormal">Paper Presented On &lsquo;Role Of Home Economics College Peshawar In Head Injury Prevention. &ldquo;First National Neuro Trauma Conference Organized By Head Injury And Neuro Trauma Association. Peshawar, Khyber Pakhtoonkhwa, On 10thMarch 2008.</p>



</p><p align="right">,,,Conference Paper by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal">Paper presented on &ldquo;The Impact Of Head Injury Awareness Program On The Play Behavior Of Children In Peshawar.Khyber Pakhtoonkhwa.Pakistan&rdquo;. Organized by Institute Of Cognitive Sciences. Tehran. Iran.27-29 April 2015</p>




<p class="MsoNormal">Keynote speaker on Down Syndrome (Key Note Speaker) organized by Conference Secretariat NRC 2014 ISRA Institute of Rehabilitation Sciences (IIRS) ISRA University, Farash Town, Lehtrar Road Islamabad Pakistan ,Higher of Education Commission, Pakistan and ISRA Institute Rehabilitation Sciences Hyderabad Sindh, Karachi,&nbsp; -2nd November 2014</p>




<p class="MsoNormal">Paper presented on &ldquo;The Significance Of Early Childhood Education In Endorsing Healthy Child Development&rdquo; International conference on role Of Teacher Association In Higher Education. Organized by Peshawar University Teacher Association PUTA. At Baragali campus, on 06th -8th June 2013.</p>



</p><p align="right">,,,Conference Paper by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>&nbsp;Socio-Political Empowerment Of Women Through Micro Finance.<strong>The Journal of Humanities and Social Sciences</strong>.Faculty of Arts and Humanities University of Peshawar ISSN 1024-0829.Volume XXII, No 3, 2014 (December)</p></p><p align="right">,National,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>&nbsp;The Pseudo Male to Female Gender Dysphorics of Pakistan. <strong>International Journal&nbsp; of Rehabilitation&nbsp; Science</strong>s 2013, 2(2): 28-32</p></p><p align="right">,National,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>&nbsp;Positive Effects of Parental Involvement On Down&rsquo;s Syndrome Children In Khyber Pakhtoonkhaw.<strong>Isra Medical Journal</strong></p></p><p align="right">,National,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>&nbsp;Importance of scheduling advance directives for cancer patients. <strong>The Journal of Law and Society,</strong>&nbsp; ISSN 1027-4618&nbsp; University of Peshawar.42(59 &amp;60)pp 213-224</p></p><p align="right">,National,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Fallacy about Male-To Female Gender Dysphorics in December. Pakistan. <strong>Pakistan Journal of Psychology.</strong> University of Karachi. Institute of Clinical Psychology ISSB-0030-9869. 37(2) pp.45-60</p></p><p align="right">,National,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Cultural Traditions and women. <strong>PUTAJ. The Journal of Humanities and Social Sciences.</strong> University Of Peshawar. ISSN1608-7925-Vol. 15.pp55- 62</p></p><p align="right">,National,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>The Study of Prevalence of Superstitions among Educated and Uneducated People of Urban and Rural Areas <strong><em>.</em>PUTAJ. The Journal of Humanities and Social Sciences</strong>. University Of Peshawar. ISSN1608-7925-Vol. 15pp.43-53</p></p><p align="right">,National,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Adjustment Tribulations of Female Financiers. <strong>The Journal of Humanities and Social Sciences.</strong> Faculty of Arts and Humanities. University Of Peshawar. ISSN:1024-0829 Vol. 16(1)pp.148-159</p></p><p align="right">,National,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Point Of Views of University Scholars about Gender Dysphorics<em>.</em><strong>NURTURE</strong>. Research Journal For Human Civilization&rsquo;s 1994-1625. Pakistan Home Economics Association. Vol. 2(1)pp.12-16</p></p><p align="right">,National,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Gender Dysphorics in Pakistan<strong><em>.</em> Journal of the Research Society of Pakistan.</strong> University of Punjab. ISSN 0034-5431.Vol. 45(2)pp.135-146</p></p><p align="right">,National,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Diversity of Gender Dysphoria. <strong>PUTAJ. The Journal of Humanities and Social Sciences. </strong>University Of Peshawar. ISSN 1608-7925-Vol. 16 pp.97-110</p></p><p align="right">,National,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Study of Personality Difference among Identical Twins and Fraternal Twins in Pakistan. <strong>Journal of the Research Society of Pakistan. </strong>University of Punjab<strong>.</strong> ISSN 0034-5431-Vol. 46(2).pp.101-114</p></p><p align="right">,National,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Growing Practice of Child adoption among Childless Couples Pakistan. <strong>Journal of Clinical Psychology Institute of Clinical Psychology</strong>. University Of Karachi.ISSB-1019-438X. Vol. 8(2).pp.3-14</p></p><p align="right">,National,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Inadequate Identification with Parent of Similar Sex: Major Problem of Gender Dysphorics in Pakistan. <strong>PUTAJ. The Journal of Humanities and Social Sciences.</strong> University Of Peshawar. ISSN2219-245X- Vol.17.pp.213-222</p></p><p align="right">,National,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Inadequate Identification with Parent of Similar Sex: Major Problem of Gender Dysphorics in Pakistan. <strong>PUTAJ. The Journal of Humanities and Social Sciences.</strong> University Of Peshawar. ISSN2219-245X- Vol.17.pp.213-222</p></p><p align="right">,National,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>The Impact of Parental Motivation, Education and Feedback on the Learning Experiences of Down syndrome Children. <strong>PUTAJ. The Journal of Humanities and Social Sciences</strong>. University Of Peshawar. ISSN2219-245X-Vol.17.223-234</p></p><p align="right">,National,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Portrayal of Gender Dysphoria in Khyber Pakhtoonkhwa .<strong>Central Asia Journal of Area Study Centre</strong>. (Russia, China And Central Asia) University Of Peshawar.&nbsp; ISSN 1729-9802.Vol.67.pp.61-71</p></p><p align="right">,National,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p><em>Nafsi,Samaji, NazaryatiMarahil:Erikhome Erikson </em>.(urdu article) <strong>Khayaban</strong>.Biannual Research Journal. Department of Urdu. University Of Peshawar. ISSN 1993-9302.vol-23(15),pp.156-166</p></p><p align="right">,National,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Errand of Tribal Women in Peace Building and Divergence Verdict In Pukhtoon Conventional Society. Peshawar University Teachers Association <strong>The Journal, Humanities and Social Sciences.</strong> University of Peshawar.ISSN2219-245X-18,pp. 125-133</p></p><p align="right">,National,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Combined Gender Identity and Transsexuality Inventory Application, Translation and Validation in Pakistan. Peshawar University Teachers Association <strong>The Journal Humanities and Social Sciences,</strong> University of Peshawar. ISSN2219-245X-18,pp.115-124</p></p><p align="right">,National,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p><em>Nafas Insane AurMaaqam- E- Rooh. Shaouri La Shaouri Safar.</em><strong>Khayaban</strong>.Biannual Research Journal. Department of Urdu. University Of Peshawar. ISSN 1993-9302.vol- 24,pp. 137-146</p></p><p align="right">,National,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Sex Role Description Based On The Formation Of Masculinity and Femininity. <strong>The Journal of Humanities and Social Sciences. </strong>University Of Peshawar. ISSN2219-245X-19-pp.57-70</p></p><p align="right">,National,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>The Significance of Early Childhood Education in Endorsing Healthy Child Development. <strong>The Journal of Humanities and Social Sciences. </strong>University Of Peshawar. ISSN2219-245X-19- Vol- 20,pp136-145</p></p><p align="right">,National,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>The Significance of Early Childhood Education in Endorsing Healthy Child Development. <strong>The Journal of Humanities and Social Sciences. </strong>University Of Peshawar. ISSN2219-245X-19- Vol- 20,pp136-145</p></p><p align="right">,National,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Compulsive Buying Disorder: The role of Impulse Control in Consumer Culture and Associated Psychiatric Co-morbidity. <strong>PUTAJ</strong>. <strong>The Journal of Humanities and Social Sciences</strong>. University Of Peshawar. ISSN2219-245X-19- vol- 20,pp 129-135</p></p><p align="right">,National,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>Overview Of Sexual Orientation, Sex Reassignment Surgery and Legal Facets Of Khawaja Saras In Pakistan.<strong> The Journal of Law and Society,</strong>&nbsp; ISSN 1027-4618&nbsp; University of Peshawar.42(59 &amp;60)pp 213-224&nbsp;</p></p><p align="right">,National,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p class="MsoNormal">Situational Analysis Of Female Offenders In Jails:A Case Study Of Central Jails Of Dera Ismail Khan,Haripur And Peshawar. Pakistan Journal Of Criminology.Vol.7.No.3.</p>
<p>July,2015,Pp 12-21</p></p><p align="right">,National,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p class="MsoNormal">Role Of Micro-Credit to Empower Women Regarding Health and Family Issues in Pakistan.Int.J.Rehabil.Sci.Vol.04,Issue01.</p>
<p>pp11-14</p></p><p align="right">,National,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Memberships</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>HEC recognized supervisors</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>Visits organized</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal">2015</p>


<p class="MsoNormal">Organized an Educational &nbsp;trip&nbsp; with Special children for the students of BS and M.Sc</p>




<p class="MsoNormal">2015</p>


<p class="MsoNormal">Organized an Educational&nbsp; trip with Cancer patientsfor the students of BS and M.Sc</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Organized an Educational&nbsp; trip to Islamabad and Murree for the students of BS and M.Sc</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Organized an Educational&nbsp; trip to Edhi Center&nbsp; for MSc Students</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Organized an Educational&nbsp; trip to Orphanage</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Organized an Educational&nbsp; trip to Special children Physically Handicapped</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormalCxSpMiddle" style="margin-bottom: 10.0pt; mso-add-space: auto; tab-stops: 205.55pt;">Organized an Educational to Lok Virsa, Islamabad for students of Department of Textiles and Fashion Designing.6th Sep ,2013</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Organized an Educational Trip to Kohinoor Textile Mill, Islamabad for students of Department of Textiles and Fashion Designing 17th dec,2013</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Organized an Educational&nbsp; trip to Shama Ghee Industry Nowshera on for the students of M.Sc (Prev&amp; Final) and BS 5th Semester deptt of Food &amp; Nutrition. 26.11.2013.</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Organized an Educational&nbsp; trip to Edhi Center /InsarBarni Social Trust</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Organized an Educational&nbsp; trip to Orphanage /Child Trust centres</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Organized an Educational&nbsp; trip to Special children Mentally Retarded children</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Organized an Educational&nbsp; trip to NIFA .TarnabFarm.Peshawar</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Organized an Educational trip to Swat Science&nbsp; Expo&rdquo; dated June 2013.</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Organized an Educational&nbsp; trip to Edhi Center</p>




<p class="MsoNormal">2012</p>


<p class="MsoNormal">Organized an Educational&nbsp; trip to Orphanage</p>




<p class="MsoNormal">2011</p>


<p class="MsoNormal">Organized an Educational&nbsp; trip to Special children</p>



</p><p align="right">,,For College by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal">2015</p>


<p class="MsoNormal">Visit of College of Home Economics Abbottabad Khyber Pakhtoonkhwa&nbsp; at College of Home Economics University of Peshawar 16 october 2015</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Visit of Swat University Khyber Pakhtoonkhwaat College of Home Economics University of Peshawar21 Oct 2014</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Visit of University of Sains&nbsp; Malaysian Delegation at College of Home Economics University of Peshawar22 August 2014</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Visit of Swat University Khyber Pakhtoonkhwaat College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Visit of Frontier College Peshawar at College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Visit of Malaysia university Delegation at College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Organized a visit of students of Abdul Wali Khan Mardan University to college of Home Economics as a mini open house. 4rth December 2013</p>



</p><p align="right">,For Delegates, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal">2015</p>


<p class="MsoNormal">Arranged visit for F.Sc. pre Medical Students to Botanical Garden.</p>




<p class="MsoNormal">2015</p>


<p class="MsoNormal">Arranged Visit For Nursery School Children To Museum</p>




<p class="MsoNormal">2015</p>


<p class="MsoNormal">Arranged Visit For M.Sc. Previous Students To Orphanage</p>




<p class="MsoNormal">2015</p>


<p class="MsoNormal">Arranged Visit For M.Sc. Previous Students To Benchmark School</p>




<p class="MsoNormal">2015</p>


<p class="MsoNormal">Arranged Visit For M.Sc. Previous Students To Museum</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Arranged visit for M.Sc. Previous students to Biotechnology Department 26th&amp; 27th Feb,2014</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormalCxSpMiddle">Organized a trip to Lok Virsa, Islamabad for students of Department of Textiles and Fashion Designing, on 17th dec,2013</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Organized an Educational Trip to Kohinoor Textile Mill, Islamabad for students of Department of Textiles and Fashion Designing, on 17th dec,2013</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Organized visit to Peshawar Museum for Nursery School Children&nbsp;</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Organized Visit to Forest College Museum for Nursery School Children&nbsp;</p>



</p><p align="right">,,For College by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Achievements</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>Certificate courses offered</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>Social events</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p><strong>International Days Organized</strong></p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">International Women&rsquo;s day was organized and celebrated in Convocation Hall, UOP&nbsp; 8th May2014</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Principal organizer, World Home Economics Day 2014.Major&nbsp; theme was Role of Home Economics in Developing Health Care Culture Organized in&nbsp; College of Home Economics.21 March 2014</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Principal organizer of International Literacy Day 8th Sep 2013. To celebrate International Literacy Day a function was arranged on 10th Sep to highlight the importance of the cause. Speeches were delivered by the students. Certificates were distributed among the participants and Gifts (books, bags, stationary items) were distributed among deserving children to promote literacy. Prof. AbasynYousafzai was the chief guest on the occasion. A movie was shown to students.8th Sep 2013</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">World literacy day of 21st century was organized on 9th October 2013. In PUTA Hall. UOP9th October 2013</p>




<p class="MsoNormal">2012</p>


<p class="MsoNormal">International Women&rsquo;s day was organized and celebrated in PUTA Hall, UOP&nbsp; 8th May2012</p>



</p><p align="right">,,Organized, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal">2015</p>


<p class="MsoNormal">Organized Milad at College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Organized Women&rsquo;s Sports Gala&nbsp; on 6th March 2014 at College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Organized a tablo, &lsquo;bint-e-hayat, on women&rsquo;s day, 8th March,2014 at Convocation Hall, UOP</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Organized Funfair at College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Organized Milad at College of Home Economics University of Peshawar</p>



</p><p align="right">,,Organized, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p><strong>Early Childhood Care And Education Unit Events Organized</strong></p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Principal organizer of&nbsp; Quaid-e-Azam Day&nbsp; Nursery School on&nbsp; 21st December 2013 at College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Principal organizer of Annual day on 14th March 2014. at College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Principal organizer of Milad at Nursery School on&nbsp; 14 February at College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Organized Face painting day in Nursery School on 18 Marchat College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Organized Card making day in Nursery School on 18 Marchat College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Organized Cap day in Nursery School on&nbsp; 10 April 2014at College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Organized Balloons day in nursery blue on 20th&nbsp; Aprilat College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Principal organizer of Annual day on 25th March 2013 at College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Principal organizer of&nbsp; Quaid-e-Azam Day&nbsp; Nursery School on&nbsp; 23rd December 2013 at College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Organized Sports day in Nursery School on&nbsp; 12&nbsp; May 2013 at College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Organized Face painting day at Nursery School&nbsp; College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Organized Pencil Decoration day at Nursery School&nbsp; College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Organized Recycling day at Nursery School&nbsp; College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Organized Soup Activity day at Nursery School&nbsp; College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Organized Singing day&nbsp; at Nursery School College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Organized Cartoon day&nbsp; at Nursery School College of Home Economics University of Peshawar</p>



</p><p align="right">,,Organized, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p><strong>Early Childhood Care And Education Unit Events Organized</strong></p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Principal organizer of&nbsp; Quaid-e-Azam Day&nbsp; Nursery School on&nbsp; 21st December 2013 at College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Principal organizer of Annual day on 14th March 2014. at College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Principal organizer of Milad at Nursery School on&nbsp; 14 February at College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Organized Face painting day in Nursery School on 18 Marchat College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Organized Card making day in Nursery School on 18 Marchat College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Organized Cap day in Nursery School on&nbsp; 10 April 2014at College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2014</p>


<p class="MsoNormal">Organized Balloons day in nursery blue on 20th&nbsp; Aprilat College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Principal organizer of Annual day on 25th March 2013 at College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Principal organizer of&nbsp; Quaid-e-Azam Day&nbsp; Nursery School on&nbsp; 23rd December 2013 at College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Organized Sports day in Nursery School on&nbsp; 12&nbsp; May 2013 at College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Organized Face painting day at Nursery School&nbsp; College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Organized Pencil Decoration day at Nursery School&nbsp; College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Organized Recycling day at Nursery School&nbsp; College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Organized Soup Activity day at Nursery School&nbsp; College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Organized Singing day&nbsp; at Nursery School College of Home Economics University of Peshawar</p>




<p class="MsoNormal">2013</p>


<p class="MsoNormal">Organized Cartoon day&nbsp; at Nursery School College of Home Economics University of Peshawar</p>



</p><p align="right">,,Organized, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal">Served, Judge for declamation context on sustainable peace. Democracy or Dictatorship.28th October 2015, Organized by Institute of Peace and Conflict ,University of Peshawar.</p>




<p class="MsoNormal">Served, Judge for Head Injury Poster Presentation at North West and Research Hospital .Khyber Pakhtoonkhwa.</p>




<p class="MsoNormal">Served, Judge for the 16 days of Violence Against Women Poster Exhibition Agha Khan Auditorium ,UOP</p>




<p class="MsoNormal">Donation of toys for Day Care Centre College of Home Economics, UOP</p>




<p class="MsoNormal">Served, Judge for the Naat Competition organized by College of Home Economics UOP.</p>




<p class="MsoNormal">Served, Judge for the Naat Competition organized by College&nbsp; ofHome Economics UOP.</p>




<p class="MsoNormal">Served, Judge for the Home Economics Exhibition, organized by Frontier Women College March</p>




<p class="MsoNormal">Served, Judge for the Business Women Exhibition, organized by women business Centre</p>




<p class="MsoNormal">Served, Packaging food for distribution for IDPs of SWAT,</p>




<p class="MsoNormal">Served, Packaging food for distribution IDPs of Nowshera Flood .</p>




<p class="MsoNormal">Served, Packaging food for distribution for IDPs of Earthquake.</p>




<p class="MsoNormal">Served, Judge for the Naat Competition organized by College ofHome Economics UOP.</p>




<p class="MsoNormal">Served, Judge for the Naat Competition organized by College of Home Economics UOP.</p>




<p class="MsoNormal">Served, Judge for the Naat Competition organized by College of&nbsp; Home Economics UOP</p>




<p class="MsoNormal">Served, Judge for the Naat Competition organized by College of Home Economics UOP.</p>




<p class="MsoNormal">Served, Judge for the Naat Competition organized by Collegeof &nbsp;Home Economics UOP.</p>




<p class="MsoNormal">Served, Judge for the Naat Competition organized by College of Home Economics UOP.</p>




<p class="MsoNormal">Served, Judge for the singing&nbsp; Competition organized by College of &nbsp;Home Economics</p>




<p class="MsoNormal">Served, Judge for the Naat Competition organized by College of Home Economics UOP.</p>




<p class="MsoNormal">Served, Judge for the singing&nbsp; Competition organized by College of &nbsp;&nbsp;Home Economics,Uop</p>




<p class="MsoNormal">Served, Judge for the Naat Competition organized by College of Home Economics UOP.</p>




<p class="MsoNormal">Served, Judge for the singing&nbsp; Competition organized by College of&nbsp; Home Economics UOP</p>




<p class="MsoNormal">Served, Judge for the Naat Competition organized by College of Home Economics UOP.</p>




<p class="MsoNormal">Served, Judge for the Naat Competition organized by College of&nbsp; Home Economics UOP.</p>




<p class="MsoNormal">Served, Judge for the Naat Competition organized by College of Home EconomicsUOP.</p>




<p class="MsoNormal">Served, Judge for the Naat Competition organized by College of&nbsp; Home Economics UOP</p>




<p class="MsoNormal">Served, Judge for the Naat Competition organized by College of Home Economics UOP</p>



</p><p align="right">,Participated,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal">Invited as Chief guest to Benchmark school system on Annual Day 26th March 2015</p>




<p class="MsoNormal">Invited as Chief guest to University Model School, Installation ceremony 2014</p>




<p class="MsoNormal">BentyHawa Peace and Development Organization .Fata/Tribal Valley IDPs Exhibition</p>




<p class="MsoNormal">Invited as Chief guest to Benchmark school system science exhibition</p>




<p class="MsoNormal">Invited as Chief guest to Women Writers Forum on book inauguration of MsZubaidaZulfiqar. 8th May 2014&nbsp;</p>




<p class="MsoNormal">Invited Chief guest on exhibition arranged by Department of Textiles and Clothing 2014</p>




<p class="MsoNormal">Invited Chief guest to Early childhood Care and Education unit on Annual Day 2014</p>




<p class="MsoNormal">Invited as Chief guest to Frontier Model School and College for Girls. Peshawar, 18th January 2014</p>




<p class="MsoNormal">Invited as Chief guest to Benchmark school system on International Mother Day8th May 2012</p>




<p class="MsoNormal">Invited as Chief guest to Qadeem school system on Annual Day 2011</p>



</p><p align="right">,Participated,, by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Educational trips</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>Awards</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal">Best Poster Presentation Award was awarded by College of Home Economics, University Of Peshawar&nbsp; on 3rd June 2014</p>




<p class="MsoNormal">Distinguished Mother Award was awarded by University of Peshawar. On 11, May, 2014. Convocation Hall.</p>




<p class="MsoNormal">Plaque of Appreciation&nbsp; was awarded in January 2014 by Hyungtae Kim, President of Hannam University</p>




<p class="MsoNormal">Award of Excellence was awarded by PUTA ,on9th October 2013 University of Peshawar. Pakistan</p>




<p class="MsoNormal">Best Presentation Award was awarded by ISRA University, on 5th October 2013, Islamabad. Pakistan</p>




<p class="MsoNormal">Awarded by Nida Pakistan on 8th May International Women Day 2012</p>




<p class="MsoNormal">Best Presentation Award was awarded by ISRA University 0n 20th December 2012, University, Islamabad. Pakistan</p>



</p><p align="right"> by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Talks</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p><strong>T.V Programmes&nbsp; Participated</strong></p>
<p><strong>&nbsp;</strong></p>




<p class="MsoNormal">Guest speaker. Home Economics Education. AVT Khyber ,Peshawar Khyber Pakhtoonkhwa, 9th&nbsp; April 2014</p>




<p class="MsoNormal" style="text-align: justify; tab-stops: 205.55pt;">Guest. Home Economics Education. AVT Khyber ,Peshawar ,Khyber Pakhtoonkhwa, 9th &nbsp;April 2014</p>




<p class="MsoNormal" style="text-align: justify; tab-stops: 205.55pt;">Guest speaker. Home Economics Education. AVT ,Peshawar ,Khyber Pakhtoonkhwa, 9th &nbsp;June 2013</p>




<p class="MsoNormal" style="text-align: justify; tab-stops: 205.55pt;">Guest speaker. F.Sc Program in Home Economics&rdquo;. Khyber TVPeshawar ,Khyber Pakhtoonkhwa, July 16th, 2010.</p>




<p class="MsoNormal" style="text-align: justify; tab-stops: 205.55pt;">Guest speaker. Kids Fun Camp in Home Economics College, Khyber speaker TV Peshawar ,Khyber Pakhtoonkhaw,16th June, 2010.</p>




<p class="MsoNormal" style="text-align: justify; tab-stops: 205.55pt;">Guest speaker. &ldquo;Highly Educated Pukhtoon Women&rdquo;. Khyber TV Peshawar Khyber Pakhtoonkhwa, 5th Jan, 2008</p>



</p><p align="right"> by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal" style="text-align: justify; tab-stops: 205.55pt;">2014</p>


<p class="MsoNormal">Resource person in programme on Women Education, Voice of America, Live Talk. </p>




<p class="MsoNormal" style="text-align: justify; tab-stops: 205.55pt;">2012</p>


<p class="MsoNormal">Resource person in programme on &ldquo;Importance Of Home Economics Education&rdquo; at April, 1st&nbsp; 2012 .Radio Broadcast, University of Peshawar</p>




<p class="MsoNormal" style="text-align: justify; tab-stops: 205.55pt;">2010</p>


<p class="MsoNormal">Resource person in programme on Women Education, Voice of America, Live Talk, 4rth June, 2010</p>




<p class="MsoNormal" style="text-align: justify; tab-stops: 205.55pt;">2007</p>


<p class="MsoNormal">Resource person in programme on Gender Dysphorics Of Pakistan, Radio Broadcast University of Peshawar, 7th September, 2007</p>




<p class="MsoNormal" style="text-align: justify; tab-stops: 205.55pt;">2006</p>


<p class="MsoNormal">Resource person in discussion of Gender Dysphorics Of Pakistan, Voice of America, Live Talk University of Peshawar, 16th September, 2006</p>



</p><p align="right"> by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p><strong>Paper Presented On International Day</strong></p>




<p class="MsoNormal">Presented a Paper on <strong>World Autism Day</strong> organized by Shaheed Benazir Bhutto Women University2nd April 2015</p>




<p class="MsoNormal">Presented a Paper on <strong>World Home Economics Day</strong>organized&nbsp; by College of Home Economics. UOP 21 March 2014</p>




<p class="MsoNormal">Key note speaker on <strong>International Women&rsquo;s Day</strong> organized and celebrated in Convocation Hall, UOP&nbsp; 8th May2014</p>




<p class="MsoNormal">Presented a Paper on <strong>World Head Injury and Neuro Trauma Day</strong> was organized with collaboration of North West Frontier Hospital and Research Centre.20th March 2014</p>




<p class="MsoNormal">Presented a Paper on&nbsp; &ldquo;<strong>Role of Home economics in head injury prevention among school going children</strong> &ldquo;Head Injury and Neuro Trauma Day Was Organized With Collaboration Of North West Frontier Hospital and Research Centre20th March 2014</p>




<p class="MsoNormal">Keynote Speaker on &ldquo;<strong>Break Barriers, Open Doors: for an Inclusive Societyand Development for All&rdquo;</strong> organized by Habib Physiotherapy and Hayatabad Medical Complex, on 3rd December, Celebrating International Disability Day.3rd December 2013</p>



</p><p align="right"> by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Book reviews</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal">Home Economics Book For Class 6th .Khyber PakhtoonkhwaText Book Board. Hayatabad Peshawar New Course Book Of Text Book Board</p>




<p class="MsoNormal">Home Economics Book For Class 7th .Khyber PakhtoonkhwaText Book Board. Hayatabad Peshawar. New Course Book Of Text Book Board</p>



</p><p align="right"> by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal">Home Economics Book For Class 6th .Khyber PakhtoonkhwaText Book Board. Hayatabad Peshawar New Course Book Of Text Book Board</p>




<p class="MsoNormal">Home Economics Book For Class 7th .Khyber PakhtoonkhwaText Book Board. Hayatabad Peshawar. New Course Book Of Text Book Board</p>



</p><p align="right"> by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal">Proceedings of the 1st National Home Economics Conference (NHEC&ndash; 2014), on &ldquo;Home Economics: Exploring New Horizons.&rdquo; from June 3 - 4, 2014, at Baragali &ndash; Summer Campus, University of Peshawar.</p>




<p class="MsoNormal">Growing Child. B.Sc 1.College of Home Economics. University of Peshawar.</p>




<p class="MsoNormal">Practical Handbook of Adolescence. Reference Book. B.Sc Home Economics. College of Home Economics. University of Peshawar, Published by HB Printer. Peshawar City. </p>




<p class="MsoNormal">Text Manual Of Early Childhood Education.Published By Youth Resource Centre And Unicef. Peshawar, Pakistan. Khyber Pakhtoonkhwa</p>




<p class="MsoNormal">Theories Of Adolescence. Reference Book. B.Sc Home Economics. College Of Home Economics. University Of Peshawar.Published By Printman. Printers And Publishers. Saddar Road Peshawar. Khyber Pakhtoonkhwa</p>



</p><p align="right"> by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal">Proceedings of the 1st National Home Economics Conference (NHEC&ndash; 2014), on &ldquo;Home Economics: Exploring New Horizons.&rdquo; from June 3 - 4, 2014, at Baragali &ndash; Summer Campus, University of Peshawar.</p>




<p class="MsoNormal">Growing Child. B.Sc 1.College of Home Economics. University of Peshawar.</p>




<p class="MsoNormal">Practical Handbook of Adolescence. Reference Book. B.Sc Home Economics. College of Home Economics. University of Peshawar, Published by HB Printer. Peshawar City. </p>




<p class="MsoNormal">Text Manual Of Early Childhood Education.Published By Youth Resource Centre And Unicef. Peshawar, Pakistan. Khyber Pakhtoonkhwa</p>




<p class="MsoNormal">Theories Of Adolescence. Reference Book. B.Sc Home Economics. College Of Home Economics. University Of Peshawar.Published By Printman. Printers And Publishers. Saddar Road Peshawar. Khyber Pakhtoonkhwa</p>



</p><p align="right"> by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Promotions</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal">2007</p>


<p class="MsoNormal">Visiting Faculty, BS. Benazir Women University. Khyber Pakhtunkhuwa.</p>




<p class="MsoNormal">2011-12</p>


<p class="MsoNormal">Visiting Faculty, BS. Institute of Bio Technology University of Peshawar. Khyber Pakhtunkhuwa.</p>



</p><p align="right"> by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;">



<p class="MsoNormal">2013 till date</p>


<p class="MsoNormal">Professor, College of Home Economics University of Peshawar.Khyber Pakhtunkhuwa.. Pakistan</p>




<p class="MsoNormal">2012 -2013&nbsp;&nbsp;&nbsp;</p>


<p class="MsoNormal">Associate Prof. College of Home Economics University of Peshawar.Khyber Pakhtunkhuwa .Pakistan</p>




<p class="MsoNormal">2007&nbsp; -2011&nbsp;&nbsp;&nbsp;&nbsp;</p>


<p class="MsoNormal">Assistant Prof. College of Home Economics. University of Peshawar. Khyber Pakhtunkhuwa. Pakistan</p>




<p class="MsoNormal">1999 -2006</p>


<p class="MsoNormal">Lecturer. College of Home Economics University of Peshawar.Khyber Pakhtunkhuwa. Pakistan</p>




<p class="MsoNormal">1991-1998</p>


<p class="MsoNormal">Contract Lecturer. College of Home Economics .University of Peshawar.Khyber Pakhtunkhuwa. Pakistan</p>



</p><p align="right"> by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                                                </div>
								
								<h3>Study Leaves</h3>
                                <div>
                                                                <p class="text-error">Record not found.
                                </p>
                                                                </div>
								
								<h3>Higher qualifications</h3>
                                <div>
                                							<div style="padding:10px;background-color:#F7F7F7;margin-bottom:10px;border-radius:4px;border:#999999 1px solid;">
                            <p style="color:#333333;font-weight:normal;"><p>PhD Psychology</p></p><p align="right"> by: <a href="profile.php?id=5" class="text-info"><span class="text-info">Prof. Dr. Syeda Kaniz Fatima Haider</span></a>
                                </p>
                                </div>
                                                                </div>
                                
                            </div>

                        </div>
                        <div class="span3">
                            <h3>Announcements <a href="announcements.php" style="font-size:12px;">View All</a></h3>
                            <div id="news-container">
                            <ul class="list4 support-box">
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=209"><time datetime="2024-10-30">October 30, 2024</time></a>
                                        <div>Science Department, College of Home Econ...</div>
                                        <div><a href="show-event.php?id=209" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=208"><time datetime="2024-10-06">October 06, 2024</time></a>
                                        <div>Ms. Sidra Ali defended her research unde...</div>
                                        <div><a href="show-event.php?id=208" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=207"><time datetime="2024-09-11">September 11, 2024</time></a>
                                        <div>The entry test for MPhil/PhD programs in...</div>
                                        <div><a href="show-event.php?id=207" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                            </ul>
                            </div>
                            <h3>Upcoming Events <a href="upcoming-events.php" style="font-size:12px;">View All</a></h3>
                            <div id="news-container2">
                            <ul class="list4 support-box">
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=202"><time datetime="2024-03-03">March 03, 2024</time></a>
                                        <div>SPRING FIESTA, TUESDAY 5TH MARCH 2024....</div>
                                        <div><a href="show-event.php?id=202" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=201"><time datetime="2024-02-21">February 21, 2024</time></a>
                                        <div>A two day book fair was organized in col...</div>
                                        <div><a href="show-event.php?id=201" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                                <li>
                                    <div class="extra-wrap">
                                        <img src="img/calendar.png" alt="">
                                        <a href="show-event.php?id=193"><time datetime="2023-10-04">October 04, 2023</time></a>
                                        <div>Newly admitted FSc students Orientation ...</div>
                                        <div><a href="show-event.php?id=193" class="text">Click here for details</a></div>
                                    </div>
                                </li>
                                                            </ul>
                            </div>
                            
                        </div>                    </div>
                 </article>
            </div>
        </section>
    </div>
</div>
</div>
<!--footer-->
<footer>
    <div class="main">
        <div class="container">
            <div class="row">
                <article class="span12">
                    <p style="margin-top:20px;">College of Home Economics &copy; 2024. <a href="privacy-policy.php" title="Learn how we use your information">Privacy Policy</a></p>
                    <p align="right"><a style="display:none;" target="_blank" title="Site designed by SuperWebz.com" href="http://www.superwebz.com"><img src="img/superwebz_logo.jpg" alt="SuperWebz.com" /></a></p>
                </article>
            </div>
            <!-- {%FOOTER_LINK} -->
        </div>  
    </div> 
</footer><script type="text/javascript" src="js/bootstrap.js"></script>
<script>
    $('.list3 li a').hover(function(){
        $(this).stop().css({color:'#fc6f22'});	
        $(this).stop().parent().siblings('em').css({'background-position':'0 bottom'});	 
            }, function(){
        $(this).stop().css({color:'#1295d4'});	
        $(this).stop().parent().siblings('em').css({'background-position':'0 top'});						 
    })
    $('#search a').hover(function(){
        $(this).stop().animate({opacity:'0.5'});	
            }, function(){
       $(this).stop().animate({opacity:'1'});						 
    })
</script>

</body>
</html>
